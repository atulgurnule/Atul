﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

using System.IO;
using System.Text;
using System.Security.Cryptography;
using Taskon_MVCJquery.Models;
namespace Taskon_MVCJquery.Controllers
{
    public class HospitalController : Controller
    {
        HospitalDB hosDB = new HospitalDB();
        // GET: Hospital
        public ActionResult Hospital_Master()
        {
            return View();
        }

        //[HttpPost]
        //public JsonResult Add(Hospital obj)
        ////string userid, string password)
        //{
        //    Session["HospitalId"] = obj.HospitalId;
        //    return Json(hosDB.SaveHospitalData(obj), JsonRequestBehavior.AllowGet);
        //}
        public ActionResult Add(Hospital obj)
        {
            

            string response = string.Empty;
            //if (Request.Files.Count > 0)
            //{
            HttpPostedFileBase postedFiles = obj.postedFiles;
          

            if (postedFiles != null)
            {


                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/Photo/");
                string Shortpath1 = "../UploadFiles/Photo/";

                HttpPostedFileBase file = postedFiles;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }

                string FileType = Path.GetExtension(postedFiles.FileName).ToLower().Trim();
                if (FileType != ".jpg" && FileType != ".jpeg" && FileType != ".png")
                {
                    obj.AlertPopupMsg = "File Format Not Supported. Only .jpg, .jpeg, .png file formats are allowed while uploading profile picture.";

                }
                else
                {

                    file.SaveAs(Path.Combine(folderPath1, file.FileName.ToLower()));
                    //emp.AlertPopupMsg = folderPath1;
                    //file.SaveAs(folderPath1 + file.FileName.ToLower());
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    obj.t_imag = fileName1;
                    obj.t_path = downloadpath1;
                    //}
                }
            }
            else
            {
                obj.AlertPopupMsg = "Please select profile picture.";
                //return Json(empDB.Add(emp), JsonRequestBehavior.AllowGet);
            }
            

            return Json(hosDB.SaveHospitalData(obj), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Update(Hospital obj)
        {
            
            string response = string.Empty;
            HttpPostedFileBase postedFiles = obj.postedFiles;
            
            if (postedFiles != null)
            {


                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/Photo/");
                string Shortpath1 = "../UploadFiles/Photo/";

                HttpPostedFileBase file = postedFiles;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }

                string FileType = Path.GetExtension(postedFiles.FileName).ToLower().Trim();
                if (FileType != ".jpg" && FileType != ".jpeg" && FileType != ".png")
                {
                    obj.AlertPopupMsg = "File Format Not Supported. Only .jpg, .jpeg, .png file formats are allowed while uploading profile picture.";

                }
                else
                {

                    file.SaveAs(Path.Combine(folderPath1, file.FileName.ToLower()));
                    //emp.AlertPopupMsg = folderPath1;
                    //file.SaveAs(folderPath1 + file.FileName.ToLower());
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    obj.t_imag = fileName1;
                    obj.t_path = downloadpath1;
                    //}
                }
            }
            


            return Json(hosDB.UpdateHospitalData(obj), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int HospitalId)
        {
            return Json(hosDB.HospitalDelete(HospitalId), JsonRequestBehavior.AllowGet);

        }

        public JsonResult GetHosDetail(int HospitalId)
        {

            return Json(hosDB.GetHospitalDetails(HospitalId), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Hospital_List()
        {
            return View();
        }
        [HttpPost]
        public ActionResult BindHospitalList()
        {
            return Json(hosDB.BindHospital(), JsonRequestBehavior.AllowGet);

        }

    }
}