﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Taskon_MVCJquery.Models
{
    public class Hospital
    {
        public int HospitalId { get; set; }
        public string HospitalName { get; set; }
        public string Mobile { get; set; }
        public string Email { get; set; }
        public string City { get; set; }
        public string Description { get; set; }
        public HttpPostedFileBase postedFiles { get; set; }
        public string t_imag { get; set; }
        public string t_path { get; set; }
        public string AlertPopupMsg { get; set; }
    }
}