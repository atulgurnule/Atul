﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using Taskon_MVCJquery.Models;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Web.UI;
using System.Text;
using context = System.Web.HttpContext;


using System.Collections;
using System.Globalization;

namespace Taskon_MVCJquery.Models
{
    
    public class HospitalDB
    {
        string cs = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
        private string message = string.Empty;
        public string SaveHospitalData(Hospital obj)
        {
            int i;
            string response = string.Empty;
           
            try
            {
                //string EmpNo = emp.t_emno;
                if (obj.AlertPopupMsg != null)
                {
                    response = obj.AlertPopupMsg;
                    return response;
                }
                else
                {
                 
                    string DOMToday=string.Empty;
                   

                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        con.Open();

                        SqlCommand comm = new SqlCommand("[Proc_HospitalMaster]", con);

                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@HospitalName", obj.HospitalName);
                        comm.Parameters.AddWithValue("@Mobile", obj.Mobile);
                        comm.Parameters.AddWithValue("@Email", obj.Email);
                        comm.Parameters.AddWithValue("@City", obj.City.ToUpper());
                        comm.Parameters.AddWithValue("@Description", obj.Description.ToUpper());
                        comm.Parameters.AddWithValue("@t_imag", String.IsNullOrEmpty(obj.t_imag) ? "" : (object)obj.t_imag);
                        comm.Parameters.AddWithValue("@t_path", String.IsNullOrEmpty(obj.t_path) ? "" : (object)obj.t_path);
                       
                        comm.Parameters.AddWithValue("@t_flag", "I");
                        comm.Parameters.Add("@error", SqlDbType.VarChar, 500);

                        comm.Parameters["@error"].Direction = ParameterDirection.Output;
                        i = comm.ExecuteNonQuery();
                        con.Close();
                        message = (string)comm.Parameters["@error"].Value.ToString();
                        response = message;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                message = (ex.ToString());
                response = message;
                return response;

            }
            
        }

        public string UpdateHospitalData(Hospital obj)
        {
            int i;
            string response = string.Empty;

            try
            {
                //string EmpNo = emp.t_emno;
                if (obj.AlertPopupMsg != null)
                {
                    response = obj.AlertPopupMsg;
                    return response;
                }
                else
                {
                    
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        con.Open();

                        SqlCommand comm = new SqlCommand("[Proc_HospitalMaster]", con);

                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@HospitalId", obj.HospitalId);
                        comm.Parameters.AddWithValue("@HospitalName", obj.HospitalName);
                        comm.Parameters.AddWithValue("@Mobile", obj.Mobile);
                        comm.Parameters.AddWithValue("@Email", obj.Email);
                        comm.Parameters.AddWithValue("@City", obj.City.ToUpper());
                        comm.Parameters.AddWithValue("@Description", obj.Description.ToUpper());
                        comm.Parameters.AddWithValue("@t_imag", String.IsNullOrEmpty(obj.t_imag) ? "" : (object)obj.t_imag);
                        comm.Parameters.AddWithValue("@t_path", String.IsNullOrEmpty(obj.t_path) ? "" : (object)obj.t_path);

                        comm.Parameters.AddWithValue("@t_flag", "U");
                        comm.Parameters.Add("@error", SqlDbType.VarChar, 500);

                        comm.Parameters["@error"].Direction = ParameterDirection.Output;
                        i = comm.ExecuteNonQuery();
                        con.Close();
                        message = (string)comm.Parameters["@error"].Value.ToString();
                        response = message;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                message = (ex.ToString());
                response = message;
                return response;

            }

        }

        public string HospitalDelete(int HospitalId)
        {
            string response = string.Empty;
            try
            {
                int i;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand com = new SqlCommand("[Proc_HospitalMaster]", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@HospitalId", HospitalId);
                    com.Parameters.AddWithValue("@t_flag", "D");
                    com.Parameters.Add("@error", SqlDbType.VarChar, 500);
                    com.Parameters["@error"].Direction = ParameterDirection.Output;

                    i = com.ExecuteNonQuery();
                    message = (string)com.Parameters["@error"].Value.ToString();
                    con.Close();

                    response = message;

                }
                return response;
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return response;
        }

        public List<Hospital> BindHospital()
        {
            string response = string.Empty;
            //string dobOfFamMem=string.Empty;
            try
            {
                List<Hospital> lst = new List<Hospital>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("[Proc_HospitalMaster]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_flag", "S");
                    //comm.Parameters.Add(new SqlParameter("@HospitalId", HospitalId));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        
                        lst.Add(new Hospital
                        {
                            HospitalId = Convert.ToInt32(rdr["HospitalId"].ToString()),
                            HospitalName = rdr["HospitalName"].ToString(),
                            Mobile = rdr["Mobile"].ToString(),
                            Email = rdr["Email"].ToString(),
                            City = rdr["City"].ToString(),
                            Description = rdr["Description"].ToString(),
                            t_imag = rdr["PhotoName"].ToString(),
                            t_path = rdr["Path"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@error"].Value.ToString();
                    response = message;
                    return lst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Hospital> GetHospitalDetails(int HospitalId)
        {
            string response = string.Empty;
            //string dobOfFamMem=string.Empty;
            try
            {
                List<Hospital> lst = new List<Hospital>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("[Proc_HospitalMaster]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_flag", "S");
                    comm.Parameters.Add(new SqlParameter("@HospitalId", HospitalId));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@error"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {

                        lst.Add(new Hospital
                        {
                            HospitalId = Convert.ToInt32(rdr["HospitalId"].ToString()),
                            HospitalName = rdr["HospitalName"].ToString(),
                            Mobile = rdr["Mobile"].ToString(),
                            Email = rdr["Email"].ToString(),
                            City = rdr["City"].ToString(),
                            Description = rdr["Description"].ToString(),
                            t_imag = rdr["PhotoName"].ToString(),
                            t_path = rdr["Path"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@error"].Value.ToString();
                    response = message;
                    return lst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
    }
}