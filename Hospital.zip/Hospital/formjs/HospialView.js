﻿$(document).ready(function () {

    BindHospitalDetails();
});



function BindHospitalDetails() {

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Hospital/BindHospitalList",
        //data: '{t_emno :"' + detailempid + '"}',
        success: function (data) {


            var datatableVariable = $('#tblHospitalList').DataTable({

                "responsive": true, "lengthChange": false, "autoWidth": true,
                "buttons": ["excel", "pdf", "print"],
                "bDestroy": true,

                data: data,
                columns: [

               
                    {
                        data: null, "title": "#", render: function (data, type, row, meta) {
                            return '<a href="Hospital/Hospital_Master?HospitalId=' + row.HospitalId + '"><i class="far fa-plus-square"></i></a>';
                        }
                    },
                    {

                        "title": "Image", data: null, render: function (data, type, row, meta) {

                            return '<a href="#"><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_path + '" width="120" height="120"></li ></a>'
                            //onclick = "return ViewImg(\'' + row.t_path + '\')" 
                        }
                    },
                    {
                        data: null, "title": "Hospital Name", render: function (data, type, row, meta) {
                            return '<a href="Hospital/Hospital_Master?HospitalId=' + row.HospitalId + '">' + row.HospitalName + '</a>';
                        }
                    },
                    //{ "data": "HospitalName", "title": "Hospital Name" },
                    { "data": "Mobile", "title": "Mobile" },
                    //{ "data": "t_cbrn", "title": "LOB Line" },

                    { "data": "Email", "title": "Email" },
                    { "data": "City", "title": "City" },
                    { "data": "Description", "title": "Description" },
                    { 'data': null, "title": 'Delete', wrap: true, "render": function (item) { return '<div class="btn-group"><button type="button" onclick="delete_row(' + "" + item.HospitalId + "" + ')" value="0" class="btn btn-danger btn-sm"> <i class="far fa-trash-alt"></i></button></div>' } }

                ]

            }).buttons().container().appendTo('#tblHospitalList_wrapper .col-md-6:eq(0)');

        }
    });

};

function delete_row(HospitalId) {
    
    Swal.fire({
        title: 'Do you want to delete the record?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        denyButtonText: `Don't delete`,
    }).then((result) => {
        if (result.isConfirmed) {
            
            $.ajax({
                url: "../Hospital/Delete",
                //data: {HospitalId: "+ HospitalId +"},
                data: '{HospitalId:' + HospitalId + '}',
                type: "POST",
                contentType: "application/json;charset=UTF-8",
                dataType: "json",
                success: function (result) {
                    var output = result;
                    if (output === "success") {
                        BindHospitalDetails();
                        toastr.success('Record deleted successfully.');
                    }
                },
                error: function (errormessage) {
                    alert(errormessage.responseText);
                }
            });
            Swal.fire('Deleted!', '', 'success')
        } else if (result.isDenied) {
            Swal.fire('Records are not deleted', '', 'info')
        }
    })
}
//function ViewImg(ImgPath) {

//    //document.getElementById("preview").src = ImgPath.substring(1, 50);
//    //var NewImagePath = ImgPath.substring(1, 50);
//    document.getElementById("preview").src = ImgPath;
//    var NewImagePath = ImgPath;
//    // jQuery to archive this,
//    $("#preview").attr("src", ('' + NewImagePath + ''));
//    document.getElementById('preview').style.display = 'block'
//    $('#myModalImage').modal('show');

//}