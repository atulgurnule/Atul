﻿//Load Data in Table when documents is ready  
var HospitalId;
$(document).ready(function () {

    
    const urlParams = new URLSearchParams(window.location.search);
    const HospitalId = urlParams.get('HospitalId');
    
    if (HospitalId != null) {
        $("#lblHospitalId").html(HospitalId);
        $("#btnAdd").css('display', 'none');
        $("#btnUpdate").css('display', 'block');
        getbyHospitalDetails(HospitalId);
    }
    else {
        $("#btnAdd").css('display', 'block');
        $("#btnUpdate").css('display', 'none');
    }
});


$("#txtemail").change(function () {

    var mailid = $("#txtemail").val();

    
    var EmailCheck = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (mailid != '') {
        if (mailid.match(EmailCheck)) {
            return true;
        }

        else {
            toastr.error('Enter valid mail address.');
            $("#txtemail").val('');
            return false;
        }
    }

});




function formatJSONDate(jsonDate) {
    //var newDate = dateFormat(jsonDate, "mm/dd/yyyy");
    var newDate = new Date(parseInt(jsonDate.substr(6)));
    return newDate;
}

$("#txtmobnumber").change(function () {
    var txtmembermobileno = $("#txtmobnumber").val();
    if (txtmembermobileno != "") {
        var MemberMobileNo = /^(\+\d{1,3}[- ]?)?\d{10}$/;
        if (txtmembermobileno.match(MemberMobileNo)) {
            return true;
        }
        else {
            toastr.error('Enter valid 10 digit emergency mobile Number.');
            $("#txtmobnumber").val('');
            $("#txtmobnumber").focus();
            return false;
        }
    }
});

//function ShowImagePreview(input) {
//    if (input.files && input.files[0]) {
//        var reader = new FileReader();
//        reader.onload = function (e) {
//            $('#imgprofilepic').prop('src', e.target.result);
//        };
//        reader.readAsDataURL(input.files[0]);
//    }
//}



function getbyHospitalDetails(HospitalId) {
    
    $('#txthosname').css('border-color', 'lightgrey');
    $('#txtmobnumber').css('border-color', 'lightgrey');
    $('#txtemail').css('border-color', 'lightgrey');
    $('#txtCity').css('border-color', 'lightgrey');
    $('#txtdesc').css('border-color', 'lightgrey');
   
    $.ajax({
        url: "../Hospital/GetHosDetail",
        //data: '{t_emno :"' + detailempid + '"}',
        data: { HospitalId: HospitalId },
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {
         
            var result = data;
            if (result.length != 0) {
                debugger
                $('#txthosname').val(result[0].HospitalName);
                $('#txtmobnumber').val(result[0].Mobile);
                $('#txtemail').val(result[0].Email);
                $('#txtCity').val(result[0].City);
                $('#txtdesc').val(result[0].Description);
               
                //var NewImagePath = result[0].Path;
                //$("#imgprofilepic").attr("src", ('' + NewImagePath + ''));
                $('#lbluploadprofile').html(result[0].t_imag);
                $('#txtprofileimagname').val(result[0].t_imag);
                $('#txtprofileimgpath').val(result[0].t_path);
                //$('#txtprofileimagname').val(result[0].t_imag);
                

            }
            else {
                // toastr.warning('Record not found...!!!');
            }
            
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
            $("#divLoader").hide();
        }
    });
    return false;
}

//Add Data Function   

$("#btnAdd").click(function () {

    
    var res = validateDetails();
    if (res == false) {
        return false;
    }

    var profilephotofiles = $("#postedFiles").get(0).files;
    var data = new FormData();

    for (var i = 0; i < profilephotofiles.length; i++) {
        data.append("postedFiles", profilephotofiles[i]);
    }

    

    //Add the input element values
    data.append("HospitalId", detailempid);
    data.append("HospitalName", $('#txthosname').val());
    data.append("Mobile", $('#txtmobnumber').val());
    data.append("Email", $('#txtemail').val());
    data.append("City", $('#txtCity').val());
    data.append("Description", $('#txtdesc').val());
    
   
    $.ajax({
        type: "POST",
        url: "../Hospital/Add",
        contentType: false,
        processData: false,
        data: data,
        success: function (result) {

            var output = result;
         
            if (output === "success") {
                ClearTextbox();
                toastr.success('Record inserted successfully.');
            }

            else {
                toastr.warning(result);
                $("#divLoader").hide();
            }

        },
        error: function (xhr, status, error) {
            var err = eval(xhr.responseText);
            alert(err);
            alert("There was error while inserting data!");
           
        }
    });

});

$("#btnUpdate").click(function () {
    
    const urlParams = new URLSearchParams(window.location.search);
    const HospitalId = urlParams.get('HospitalId');
    var res = validateDetails();
    if (res == false) {
        return false;
    }

    var profilephotofiles = $("#postedFiles").get(0).files;
    var data = new FormData();

    for (var i = 0; i < profilephotofiles.length; i++) {
        data.append("postedFiles", profilephotofiles[i]);
    }



    //Add the input element values
    data.append("HospitalId", HospitalId);
    data.append("HospitalName", $('#txthosname').val());
    data.append("Mobile", $('#txtmobnumber').val());
    data.append("Email", $('#txtemail').val());
    data.append("City", $('#txtCity').val());
    data.append("Description", $('#txtdesc').val());
    data.append("t_imag", $('#txtprofileimagname').val());
    data.append("t_path", $('#txtprofileimgpath').val());

    $.ajax({
        type: "POST",
        url: "../Hospital/Update",
        contentType: false,
        processData: false,
        data: data,
        success: function (result) {

            var output = result;

            if (output === "success") {
                ClearTextbox();
                toastr.success('Record updated successfully.');
            }

            else {
                toastr.warning(result);
               
            }

        },
        error: function (xhr, status, error) {
            var err = eval(xhr.responseText);
            alert(err);
            alert("There was error while inserting data!");

        }
    });

});


function ClearTextbox() {

    $("#btnAdd").css('display', 'block');
    $("#btnUpdate").css('display', 'none');
    $('#lblHospitalId').html('');
    $('#lbluploadprofile').html('');
    document.getElementById("txthosname").value = "";
    document.getElementById("txtmobnumber").value = "";
    document.getElementById("txtemail").value = "";
    document.getElementById("txtCity").value = "";
    document.getElementById("txtdesc").value = "";
   
 
}

function validateDetails() {
    var isValid = true;
    if ($('#txthosname').val().trim() == "") {
        $('#txthosname').css('border-color', 'Red');
        isValid = false;
       
    }
    else {
        $('#txthosname').css('border-color', 'lightgrey');
    }
    if ($('#txtmobnumber').val().trim() == "") {
        $('#txtmobnumber').css('border-color', 'Red');
        isValid = false;
       
    }
    else {
        $('#txtmobnumber').css('border-color', 'lightgrey');
    }
    if ($('#txtemail').val().trim() == "") {
        $('#txtemail').css('border-color', 'Red');
        isValid = false;
  
    }
    else {
        $('#txtemail').css('border-color', 'lightgrey');
    }
    if ($('#txtCity').val().trim() == "") {
        $('#txtCity').css('border-color', 'Red');
        isValid = false;
       
    }
    else {
        $('#txtCity').css('border-color', 'lightgrey');
    }

   
    if ($('#txtdesc').val().trim() == "") {
        $('#txtdesc').css('border-color', 'Red');
        isValid = false;
       
    }
    else {
        $('#txtdesc').css('border-color', 'lightgrey');
    }
   
    return isValid;
}




     
