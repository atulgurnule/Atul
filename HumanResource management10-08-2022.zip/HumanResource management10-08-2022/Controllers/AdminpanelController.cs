﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using HumanResourceManagement.Models;

namespace HumanResourceManagement.Controllers
{
    public class AdminpanelController : Controller
    {
        UserDataDB userDB = new UserDataDB();
        string AlertPopupMsg = string.Empty;
        AdminDB adminDB = new AdminDB();
        // GET: AdminPanel
        public ActionResult AdminRegister()
        {
            return View();
        }
        public ActionResult ViewApplicationForm(string EmpId, string EmployeeName)
        {
            ViewData["empid"] = EmpId;
            ViewData["empname"] = EmployeeName;

            TempData["Enabled"] = "0";
            TempData["Disabled"] = "1,2,3,4,5,6,7";
            return View();
        }
        public ActionResult AdminLogin()
        {
            return View();
        }
        //[HttpPost]
        public ActionResult HRAdminPanel(string EmpId)
        {
            ViewData["empid"] = EmpId;
            //ViewData["empname"] = EmployeeName;
            return View();
        }
        public ActionResult BindRegistrationCompleted()
        {
            return View();
        }

        [HttpPost]
        public ActionResult BindRegistrationDetails()
        {
            return Json(adminDB.BindRegistrationDet(), JsonRequestBehavior.AllowGet);

        }
        public ActionResult AdminRegistrationDetails()
        {
            return View();

        }
        [HttpPost]
        public ActionResult AdminRegistrationBind()
        {
            return Json(adminDB.BindRegistrationAdmin(), JsonRequestBehavior.AllowGet);

        }

        public JsonResult GetAdminDetails(string t_emno)
        {

            return Json(adminDB.GetDetails(t_emno), JsonRequestBehavior.AllowGet);
        }
        public ActionResult AdminDelete(string t_emno)
        {
            return Json(adminDB.AdminDelete(t_emno), JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public ActionResult BindBasicInfoDetails(string t_emno)
        {
            return Json(adminDB.BindBasicDet(t_emno), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult BindRegistration()
        {
            return Json(adminDB.BindRegistrationCom(), JsonRequestBehavior.AllowGet);

        }
        [HttpPost]
        public JsonResult AddAdmin(AdminRegistration admin)
        {
            //_salOrd.t_logn = Convert.ToString(Session["uname"]);
            return Json(adminDB.AddAdminDet(admin), JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        public JsonResult ValidateAdmin(AdminRegistration admin)
        //string userid, string password)
        {
            Session["t_emno"] = admin.t_emno;
            return Json(adminDB.GetLoginDataAdmin(admin), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        //[Authorize]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
            return RedirectToAction("AdminLogin", "Adminpanel");
        }

        [HttpPost]
        public ActionResult BindFamilyInfo(string t_emno)
        {
            return Json(adminDB.BindFamilyDet(t_emno), JsonRequestBehavior.AllowGet);

        }
        //Bind Family Details in datatable
        [HttpPost]
        public ActionResult BindEducationDetails(string t_emno)
        {
            return Json(adminDB.BindEducationDet(t_emno), JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public ActionResult BindDocumentDetails(string t_emno)
        {
            return Json(adminDB.BindDocumenmtDet(t_emno), JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public ActionResult BindCompanyDetails(string t_emno)
        {
            return Json(adminDB.BindCompanyDet(t_emno), JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public ActionResult BindPayslipDetails(string t_emno)
        {
            return Json(adminDB.BindPayslipDet(t_emno), JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public ActionResult BindReferenceDetails(string t_emno)
        {
            return Json(adminDB.BindReferenceDet(t_emno), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult BindCertificationDetails(string t_emno)
        {
            return Json(adminDB.BindCertificationDet(t_emno), JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult GetEmployeeName(string t_emno)
        {
            return Json(adminDB.GetEmpName(t_emno), JsonRequestBehavior.AllowGet);

        }
        public ActionResult BusinessPartner()
        {
            return View();
        }
        [HttpPost]
        public JsonResult BindBusinessPartner()
        {
            //var jsonResult = Json(new { data = userDB.BindPartner() }, JsonRequestBehavior.AllowGet);
            //jsonResult.MaxJsonLength = int.MaxValue;
            //return jsonResult;
            //return Json(userDB.BindPartner(), JsonRequestBehavior.AllowGet);
            var jsonResult= Json(userDB.BindPartner(), JsonRequestBehavior.AllowGet);
            jsonResult.MaxJsonLength = int.MaxValue;
            return jsonResult;

        }
        
    }
}