﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using Microsoft.AspNetCore.Hosting;
//using Microsoft.AspNetCore.Hosting.Internal;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
using HumanResourceManagement.Models;
//using System.Threading;

namespace HumanResourceManagement.Controllers
{
    public class EmployeeController : Controller
    {
        string AlertPopupMsg = string.Empty;
        EmployeeDB empDB = new EmployeeDB();
        // GET: Employee
        //[HttpGet]
        [HttpGet]
        public ActionResult Index()
        {
           
            return View();
        }


        //[HttpPost]
        //public ActionResult EmployeeDetailsManagement()
        //{

        //    return View();
        //}
        [HttpGet]
        public ActionResult CheckNotExistForTab(Employee employee)
        {
            if (!string.IsNullOrEmpty(Session["empid"] as string))
            {
                employee.t_emno = Session["empid"].ToString();
            }
            return Json(empDB.CheckNotExistTabStatus(employee), JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult CheckExistForTab(Employee employee)
        {
            if (!string.IsNullOrEmpty(Session["empid"] as string))
            {
                employee.t_emno = Session["empid"].ToString();
            }
            return Json(empDB.CheckExistTabStatus(employee), JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        public ActionResult Index(List<HttpPostedFileBase> postedFiles)
        {
            string path = Server.MapPath("~/Uploads/");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            foreach (HttpPostedFileBase postedFile in postedFiles)
            {
                if (postedFile != null)
                {
                    string fileName = Path.GetFileName(postedFile.FileName);
                    postedFile.SaveAs(path + fileName);
                    ViewBag.Message += string.Format("<b>{0}</b> uploaded.<br />", fileName);
                }
            }

            return View();
        }
        //Check On method empid null or not
        public ActionResult EmployeeDetailsManagement(string empid)
        {
            //Session.Timeout = 1;
            ViewData["empid"] = empid;
            TempData["Selected"] = "0";
            TempData["Enabled"] = "0";
            TempData["Disabled"] = "1,2,3,4,5,6,7";
            if (empid == null)
            {
                return RedirectToAction("Index", "Home");
            }

            else
            {
                ViewData["empid"] = empid;
            }

            return View();
        }

        //[HttpPost]
        public ActionResult UploadFiles(HttpPostedFileBase file)
        //IEnumerable<HttpPostedFileBase> files
        {
            //foreach (var file in files)
            //{
            if (file.ContentLength > 0)
            {
                var fileName = Path.GetFileName(file.FileName);
                var path = Path.Combine(Server.MapPath("~/UploadFiles/Resume/"), fileName);
                file.SaveAs(path);
            }
            //}
            //string response;
            //HttpFileCollectionBase files = Request.Files;
            //if (Request.Files.Count > 0)
            //{

            //    for (int i = 0; i < files.Count; i++)
            //    {
            //        //string resume = new System.Linq.SystemCore_EnumerableDebugView(Request.Files).Items[0].ToString();
            //        if (i == 0)
            //        {
            //            string path = Server.MapPath("~/UploadFiles/Resume/");
            //            HttpPostedFileBase file = files[i];
            //            file.SaveAs(path + file.FileName);
            //        }
            //        else if(i==1)
            //        {
            //            string path1 = Server.MapPath("~/UploadFiles/ProfilePhoto/");
            //            HttpPostedFileBase file1 = files[i];
            //            file1.SaveAs(path1 + file1.FileName);
            //        }
            //        else
            //        {
            //            response = "Image Not Upload";
            //        }

            //    }

            //}


            //return Json(files.Count + " Files Uploaded!");
            return Json(" Files Uploaded!");
        }

        //Add Basic details of employee
        //[HttpPost]
        public ActionResult Add(Employee emp)
        {
            //TempData.Clear();
            //TempData["Selected"] = "1";
            //TempData["Enabled"] = "0,1";
            //TempData["Disabled"] = "2,3";

            //emp.Selected= "1";
            //emp.Enabled= "1";
            //emp.Disabled= "0, 2, 3";

            if (!string.IsNullOrEmpty(Session["empid"] as string))
            {
                emp.t_emno = Session["empid"].ToString();
               
            }

            string response = string.Empty;
            //if (Request.Files.Count > 0)
            //{
            HttpPostedFileBase postedFiles = emp.postedFiles;
            HttpPostedFileBase uploadresume = emp.uploadresume;

            if (postedFiles != null)
            {


                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/ProfilePhoto/" + "/" + emp.t_emno.Trim() + "/");
                string Shortpath1 = "../UploadFiles/ProfilePhoto/" + emp.t_emno.Trim() + "/";

                HttpPostedFileBase file = postedFiles;
                if (!Directory.Exists(folderPath1))
                {
                   Directory.CreateDirectory(folderPath1);
                }

                string FileType = Path.GetExtension(postedFiles.FileName).ToLower().Trim();
                if (FileType != ".jpg" && FileType != ".jpeg" && FileType != ".png")
                {
                    emp.AlertPopupMsg = "File Format Not Supported. Only .jpg, .jpeg, .png file formats are allowed while uploading profile picture.";

                }
                else
                {
                    
                    file.SaveAs(Path.Combine(folderPath1, file.FileName.ToLower()));
                    //emp.AlertPopupMsg = folderPath1;
                    //file.SaveAs(folderPath1 + file.FileName.ToLower());
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    emp.t_imag = fileName1;
                    emp.t_path = downloadpath1;
                    //}
                }
            }
            else
            {
                emp.AlertPopupMsg = "Please select profile picture.";
                //return Json(empDB.Add(emp), JsonRequestBehavior.AllowGet);
            }
            if (uploadresume != null)
            {
                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/Resume/" + "/" + emp.t_emno.Trim() + "/");
                string Shortpath1 = "../UploadFiles/Resume/" + emp.t_emno.Trim() + "/";
                HttpPostedFileBase file1 = uploadresume;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }
                string FileType = Path.GetExtension(uploadresume.FileName).ToLower().Trim();
                if (FileType != ".doc" && FileType != ".docx" && FileType != ".pdf")
                {
                    emp.AlertPopupMsg = "File Format Not Supported. Only .doc, .docs, .pdf file formats are allowed while uploading resume.";

                }
                else
                {
                    //if (System.IO.File.Exists(Path.Combine(folderPath1, file1.FileName.ToLower())))
                    //{
                    //    System.IO.File.Delete(Path.Combine(folderPath1, file1.FileName.ToLower()));
                    //}
                    file1.SaveAs(Path.Combine(folderPath1, file1.FileName.ToLower()));
                    //file1.SaveAs(folderPath1 + file1.FileName);
                    downloadpath1 = Shortpath1 + file1.FileName.Trim();
                    string fileName1 = Path.GetFileName(file1.FileName);
                    emp.t_filn = fileName1;
                    emp.t_rpat = downloadpath1;
                }
            }
            else
            {
                emp.AlertPopupMsg = "Please upload resume.";
                //return Json(empDB.Add(emp), JsonRequestBehavior.AllowGet);
            }

            return Json(empDB.Add(emp), JsonRequestBehavior.AllowGet);
        }

        //[HttpGet]
        public ActionResult UpdateBasic(Employee emp)
        {
            //TempData.Clear();
            //TempData["Selected"] = "1";
            //TempData["Enabled"] = "0,1";
            //TempData["Disabled"] = "2,3";

            //emp.Selected= "1";
            //emp.Enabled= "1";
            //emp.Disabled= "0, 2, 3";

            if (!string.IsNullOrEmpty(Session["empid"] as string))
            {

                emp.t_emno = Session["empid"].ToString();
            }

            string response = string.Empty;
            //if (Request.Files.Count > 0)
            //{
            HttpPostedFileBase postedFiles = emp.postedFiles;
            HttpPostedFileBase uploadresume = emp.uploadresume;

            if (postedFiles != null)
            {
                string downloadpath1;
                //string FolderPath = ConfigurationManager.AppSettings["FolderPath"];
                string folderPath1 = Server.MapPath("/UploadFiles/ProfilePhoto/" + "/" + emp.t_emno.Trim() + "/");

                string Shortpath1 = "../UploadFiles/ProfilePhoto/" + emp.t_emno.Trim() + "/";

                HttpPostedFileBase file = postedFiles;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }
                string FileType = Path.GetExtension(postedFiles.FileName).ToLower().Trim();
                if (FileType != ".jpg" && FileType != ".jpeg" && FileType != ".png")
                {
                    emp.AlertPopupMsg = "File Format Not Supported. Only .jpg, .jpeg, .png file formats are allowed while uploading profile picture.";

                }
                else
                {
                    //file.SaveAs(folderPath1 + file.FileName.ToLower());
                    //string path = Path.Combine((folderPath1), Path.GetFileName(file.FileName));
                    //if (System.IO.File.Exists(Path.Combine(folderPath1, file.FileName.ToLower())))
                    //{
                    //    System.IO.File.Delete(Path.Combine(folderPath1, file.FileName.ToLower()));
                    //}
                    file.SaveAs(Path.Combine(folderPath1 + file.FileName.ToLower()));
                    //emp.AlertPopupMsg= "Uploaded";
                    // file.SaveAs(Path.Combine(folderPath1, file.FileName.ToLower()));
                    //Path.Combine(Server.MapPath(folderPath1 + file.FileName.ToLower())));
                    //Path.Combine(uploadPath, fileOne.FileName);
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    emp.t_imag = fileName1;
                    emp.t_path = downloadpath1;
                    //}
                }
            }
            if (uploadresume != null)
            {
                string downloadpath1;
                string folderPath1 = Server.MapPath("/UploadFiles/Resume/" + "/" + emp.t_emno.Trim() + "/");
                string Shortpath1 = "../UploadFiles/Resume/" + emp.t_emno.Trim() + "/";
                HttpPostedFileBase file1 = uploadresume;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }
                string FileType = Path.GetExtension(uploadresume.FileName).ToLower().Trim();
                if (FileType != ".doc" && FileType != ".docx" && FileType != ".pdf")
                {
                    emp.AlertPopupMsg = "File Format Not Supported. Only .doc, .docs, .pdf file formats are allowed while uploading resume.";

                }
                else
                {
                    //if (System.IO.File.Exists(Path.Combine(folderPath1, file1.FileName.ToLower())))
                    //{
                    //    System.IO.File.Delete(Path.Combine(folderPath1, file1.FileName.ToLower()));
                    //}
                    //string FolderPath = ConfigurationManager.AppSettings["FolderPath"];
                    file1.SaveAs(Path.Combine(folderPath1 + file1.FileName.ToLower()));
                    downloadpath1 = Shortpath1 + file1.FileName.Trim();
                    string fileName1 = Path.GetFileName(file1.FileName);
                    emp.t_filn = fileName1;
                    emp.t_rpat = downloadpath1;
                    //return Json(empDB.UpdateBasicDet(emp), JsonRequestBehavior.AllowGet);
                }
            }
            return Json(empDB.UpdateBasicDet(emp), JsonRequestBehavior.AllowGet);
        }

        //Basic details retrive
        //[HttpGet]
        public JsonResult GetBasicDetail(string t_emno)
        {
            //Thread.Sleep(750);
            return Json(empDB.GetBasicDetails(t_emno), JsonRequestBehavior.AllowGet);
        }

        //Add and save Employee Family
        //[HttpPost]
        public ActionResult AddEmployeeFamily(Family family)
        {
            return Json(empDB.AddFamily(family), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult UpdateEmployeeFamily(Family family)
        {
            return Json(empDB.UpdateFamily(family), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult familyInsertConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{
            //    family.t_emno = Session["empid"].ToString();
            //}
            return Json(empDB.AddFamilyInsertConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult familyUpdateConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{
            //     family.t_emno = Session["empid"].ToString();
            //}
            return Json(empDB.AddFamilyUpdateConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }

        //Add Insert employee education
        //[HttpPost]
        public ActionResult AddEmployeeEducation(Education education)
        {
            HttpPostedFileBase postedFiles = education.uploadEduCertificate;
            if (postedFiles != null)
            {

                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/EducationDetails/" + "/" + education.t_emno.Trim() + "/");
                string Shortpath1 = "../UploadFiles/EducationDetails/" + education.t_emno.Trim() + "/";

                HttpPostedFileBase file = postedFiles;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }
                string FileType = Path.GetExtension(postedFiles.FileName).ToLower().Trim();
                if (FileType != ".pdf")
                {
                    education.AlertPopupMsg = "File Format Not Supported. Only .pdf file formats are allowed while uploading education certificate.";

                }
                else
                {
                    //file.SaveAs(folderPath1 + file.FileName);
                    file.SaveAs(Path.Combine(folderPath1 + file.FileName.ToLower()));
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    education.t_cena = fileName1;
                    education.t_ecpa = downloadpath1;
                }
            }
            else
            {
                education.AlertPopupMsg = "Please select education certificate.";
                //return Json(empDB.AddEducation(education), JsonRequestBehavior.AllowGet);
            }
            return Json(empDB.AddEducation(education), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult AddEmployeeDocument(Document document)
        {
            HttpPostedFileBase uploadDocuments = document.uploadDocument;

            if (uploadDocuments != null)
            {
                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/DocumentDetails/" + "/" + document.t_emno.Trim() + "/");
                string Shortpath1 = "../UploadFiles/DocumentDetails/" + document.t_emno.Trim() + "/";

                HttpPostedFileBase file = uploadDocuments;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }
                string FileType = Path.GetExtension(uploadDocuments.FileName).ToLower().Trim();
                if (FileType != ".pdf")
                {
                    document.AlertPopupMsg = "File Format Not Supported. Only .pdf file formats are allowed while uploading document.";

                }
                else
                {
                    //file.SaveAs(folderPath1 + file.FileName);
                    file.SaveAs(Path.Combine(folderPath1 + file.FileName.ToLower()));
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    document.t_imag = fileName1;
                    document.t_dpat = downloadpath1;
                }
            }
            else
            {
                document.AlertPopupMsg = "Please select document certificate.";
                //return Json(empDB.AddDocument(document), JsonRequestBehavior.AllowGet);
            }
            return Json(empDB.AddDocument(document), JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        public ActionResult EductionInsertConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{
            //    education.t_emno = Session["empid"].ToString();

            //}
            return Json(empDB.AddEducationInsertConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult EductionUpdateConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{
            //    education.t_emno = Session["empid"].ToString();

            //}
            return Json(empDB.AddEducationUpdateConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult DocumentInsertConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{

            //    document.t_emno = Session["empid"].ToString();
            //}
            return Json(empDB.AddDocumentInsertConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult DocumentUpdateConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{

            //    document.t_emno = Session["empid"].ToString();
            //}
            return Json(empDB.AddDocumentUpdateConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        public ActionResult CompanyInsertConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{
            //    company.t_emno = Session["empid"].ToString();

            //}
            return Json(empDB.AddCompanyInsertConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        public ActionResult CompanyUpdateConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{
            //    company.t_emno = Session["empid"].ToString();
            //}
            return Json(empDB.AddCompanyUpdateConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult PayslipInsertConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{
            //    payslip.t_emno = Session["empid"].ToString();
            //}
            return Json(empDB.AddPayslipInsertConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult PayslipUpdateConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{
            //    payslip.t_emno = Session["empid"].ToString();
            //}
            return Json(empDB.AddPayslipUpdateConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult ReferenceInsertConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{
            //    reference.t_emno = Session["empid"].ToString();
            //}
            return Json(empDB.AddReferenceInsertConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult ReferenceUpdateConfirm(string t_emno)
        {
            //if (!string.IsNullOrEmpty(Session["empid"] as string))
            //{
            //    reference.t_emno = Session["empid"].ToString();
            //}
            return Json(empDB.AddReferenceUpdateConfirm(t_emno), JsonRequestBehavior.AllowGet);
        }

        public ActionResult CertificationInsertConfirm(Certification certification, UserRegistration userRegistration, Employee employee)
        {
            if (!string.IsNullOrEmpty(Session["empid"] as string))
            {
                certification.t_emno = Session["empid"].ToString();
                userRegistration.t_emno = Session["empid"].ToString();
            }
            return Json(empDB.AddCertificationInsertConfirm(certification, userRegistration, employee), JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        public ActionResult CertificationUpdateConfirm(Certification certification, UserRegistration userRegistration, Employee employee)
        {
            if (!string.IsNullOrEmpty(Session["empid"] as string))
            {
                certification.t_emno = Session["empid"].ToString();
                userRegistration.t_emno = Session["empid"].ToString();
            }
            return Json(empDB.AddCertificationUpdateConfirm(certification, userRegistration, employee), JsonRequestBehavior.AllowGet);
        }


        //[HttpPost]
        public ActionResult AddEmployeeCompany(Company company)
        {
            HttpPostedFileBase uploadExpCertificate = company.uploadExpCertificate;
            if (uploadExpCertificate != null)
            {

                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/CompanyDetails/" + "/" + company.t_emno.Trim() + "/");
                string Shortpath1 = "../UploadFiles/CompanyDetails/" + company.t_emno.Trim() + "/";

                HttpPostedFileBase file = uploadExpCertificate;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }
                string FileType = Path.GetExtension(uploadExpCertificate.FileName).ToLower().Trim();
                if (FileType != ".pdf")
                {
                    company.AlertPopupMsg = "File Format Not Supported. Only .pdf file formats are allowed while uploading company experience certificate.";

                }
                else
                {
                    //file.SaveAs(folderPath1 + file.FileName);
                    file.SaveAs(Path.Combine(folderPath1 + file.FileName.ToLower()));
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    company.t_cena = fileName1;
                    company.t_epat = downloadpath1;
                }
            }
            else
            {
                company.AlertPopupMsg = "Please select company certificate.";
                //return Json(empDB.AddCompany(company), JsonRequestBehavior.AllowGet);
            }
            return Json(empDB.AddCompany(company), JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        public ActionResult AddEmployeePayslip(Payslip payslip)
        {
            HttpPostedFileBase uploadPayslip = payslip.uploadPayslip;
            if (uploadPayslip != null)
            {
                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/PaySlipDetails/" + "/" + payslip.t_emno.Trim() + "/");
                string Shortpath1 = "../UploadFiles/PaySlipDetails/" + payslip.t_emno.Trim() + "/";

                HttpPostedFileBase file = uploadPayslip;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }
                string FileType = Path.GetExtension(uploadPayslip.FileName).ToLower().Trim();
                if (FileType != ".pdf")
                {
                    payslip.AlertPopupMsg = "File Format Not Supported. Only .pdf file formats are allowed while uploading payslip.";

                }
                else
                {
                    //file.SaveAs(folderPath1 + file.FileName);
                    file.SaveAs(Path.Combine(folderPath1 + file.FileName.ToLower()));
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    payslip.t_psna = fileName1;
                    payslip.t_ppat = downloadpath1;
                }
            }
            else
            {
                payslip.AlertPopupMsg = "Please select payslip.";
                //return Json(empDB.AddPayslip(payslip), JsonRequestBehavior.AllowGet);
            }
            return Json(empDB.AddPayslip(payslip), JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        public ActionResult AddEmployeeReference(Reference reference)
        {
            return Json(empDB.AddReference(reference), JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        public ActionResult AddEmployeeCertification(Certification certification)
        {
            HttpPostedFileBase uploadCertification = certification.uploadCertification;
            if (uploadCertification != null)
            {
                if (uploadCertification != null)
                {
                    string downloadpath1;
                    string folderPath1 = Server.MapPath("../UploadFiles/CertificationDetails/" + "/" + certification.t_emno.Trim() + "/");
                    string Shortpath1 = "../UploadFiles/CertificationDetails/" + certification.t_emno.Trim() + "/";

                    HttpPostedFileBase file = uploadCertification;
                    if (!Directory.Exists(folderPath1))
                    {
                        Directory.CreateDirectory(folderPath1);
                    }
                    string FileType = Path.GetExtension(uploadCertification.FileName).ToLower().Trim();
                    if (FileType != ".pdf")
                    {
                        certification.AlertPopupMsg = "File Format Not Supported. Only .pdf file formats are allowed while uploading certification.";

                    }
                    else
                    {
                        //file.SaveAs(folderPath1 + file.FileName);
                        file.SaveAs(Path.Combine(folderPath1 + file.FileName.ToLower()));
                        downloadpath1 = Shortpath1 + file.FileName.Trim();
                        string fileName1 = Path.GetFileName(file.FileName);
                        certification.t_cena = fileName1;
                        certification.t_cpat = downloadpath1;
                    }
                }
            }
            else
            {
                certification.AlertPopupMsg = "Please select certification certificate.";
                //return Json(empDB.AddCertification(certification), JsonRequestBehavior.AllowGet);
            }
            return Json(empDB.AddCertification(certification), JsonRequestBehavior.AllowGet);
        }

        //Add Insert employee education
        //[HttpPost]
        public ActionResult UpdateEmployeeEducation(Education education)
        {
            HttpPostedFileBase postedFiles = education.uploadEduCertificate;

            if (postedFiles != null)
            {

                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/EducationDetails/" + "/" + education.t_emno.Trim() + "/");
                string Shortpath1 = "../UploadFiles/EducationDetails/" + education.t_emno.Trim() + "/";

                HttpPostedFileBase file = postedFiles;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }
                string FileType = Path.GetExtension(postedFiles.FileName).ToLower().Trim();
                if (FileType != ".pdf")
                {
                    education.AlertPopupMsg = "File Format Not Supported. Only .pdf file formats are allowed while uploading education certificate.";

                }
                else
                {
                    //file.SaveAs(folderPath1 + file.FileName);
                    file.SaveAs(Path.Combine(folderPath1 + file.FileName.ToLower()));
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    education.t_cena = fileName1;
                    education.t_ecpa = downloadpath1;
                }
            }
            return Json(empDB.UpdateEducation(education), JsonRequestBehavior.AllowGet);
        }
        //Update document details
        //[HttpPost]
        public ActionResult UpdateEmployeeDocument(Document document)
        {
            HttpPostedFileBase uploadDocuments = document.uploadDocument;
            if (uploadDocuments != null)
            {
                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/DocumentDetails/" + "/" + document.t_emno.Trim() + "/");
                string Shortpath1 = "../UploadFiles/DocumentDetails/" + document.t_emno.Trim() + "/";

                HttpPostedFileBase file = uploadDocuments;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }
                string FileType = Path.GetExtension(uploadDocuments.FileName).ToLower().Trim();
                if (FileType != ".pdf")
                {
                    document.AlertPopupMsg = "File Format Not Supported. Only .pdf file formats are allowed while uploading document.";

                }
                else
                {
                    //file.SaveAs(folderPath1 + file.FileName);
                    file.SaveAs(Path.Combine(folderPath1 + file.FileName.ToLower()));
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    document.t_imag = fileName1;
                    document.t_dpat = downloadpath1;
                }
            }
            return Json(empDB.UpdateDocument(document), JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        public ActionResult UpdateEmployeeCompany(Company company)
        {
            HttpPostedFileBase uploadExpCertificate = company.uploadExpCertificate;
            if (uploadExpCertificate != null)
            {

                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/CompanyDetails/" + "/" + company.t_emno.Trim() + "/");
                string Shortpath1 = "../UploadFiles/CompanyDetails/" + company.t_emno.Trim() + "/";

                HttpPostedFileBase file = uploadExpCertificate;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }
                string FileType = Path.GetExtension(uploadExpCertificate.FileName).ToLower().Trim();
                if (FileType != ".pdf")
                {
                    company.AlertPopupMsg = "File Format Not Supported. Only .pdf file formats are allowed while uploading company experience certificate.";

                }
                else
                {
                    //file.SaveAs(folderPath1 + file.FileName);
                    file.SaveAs(Path.Combine(folderPath1 + file.FileName.ToLower()));
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    company.t_cena = fileName1;
                    company.t_epat = downloadpath1;
                }

            }
            return Json(empDB.UpdateCompany(company), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult UpdateEmployeePayslip(Payslip payslip)
        {
            HttpPostedFileBase uploadPayslip = payslip.uploadPayslip;
            if (uploadPayslip != null)
            {
                string downloadpath1;
                string folderPath1 = Server.MapPath("../UploadFiles/PaySlipDetails/" + "/" + payslip.t_emno.Trim() + "/");
                string Shortpath1 = "../UploadFiles/PaySlipDetails/" + payslip.t_emno.Trim() + "/";

                HttpPostedFileBase file = uploadPayslip;
                if (!Directory.Exists(folderPath1))
                {
                    Directory.CreateDirectory(folderPath1);
                }
                string FileType = Path.GetExtension(uploadPayslip.FileName).ToLower().Trim();
                if (FileType != ".pdf")
                {
                    payslip.AlertPopupMsg = "File Format Not Supported. Only .pdf file formats are allowed while uploading payslip.";

                }
                else
                {
                    //file.SaveAs(folderPath1 + file.FileName);
                    file.SaveAs(Path.Combine(folderPath1 + file.FileName.ToLower()));
                    downloadpath1 = Shortpath1 + file.FileName.Trim();
                    string fileName1 = Path.GetFileName(file.FileName);
                    payslip.t_psna = fileName1;
                    payslip.t_ppat = downloadpath1;
                }
            }
            return Json(empDB.UpdatePayslip(payslip), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult UpdateEmployeeReference(Reference reference)
        {
            return Json(empDB.UpdateReference(reference), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult UpdateEmployeeCertification(Certification certification)
        {
            HttpPostedFileBase uploadCertification = certification.uploadCertification;
            if (uploadCertification != null)
            {
                if (uploadCertification != null)
                {
                    string downloadpath1;
                    string folderPath1 = Server.MapPath("../UploadFiles/CertificationDetails/" + "/" + certification.t_emno.Trim() + "/");
                    string Shortpath1 = "../UploadFiles/CertificationDetails/" + certification.t_emno.Trim() + "/";

                    HttpPostedFileBase file = uploadCertification;
                    if (!Directory.Exists(folderPath1))
                    {
                        Directory.CreateDirectory(folderPath1);
                    }
                    string FileType = Path.GetExtension(uploadCertification.FileName).ToLower().Trim();
                    if (FileType != ".pdf")
                    {
                        certification.AlertPopupMsg = "File Format Not Supported. Only .pdf file formats are allowed while uploading certification.";

                    }
                    else
                    {
                        file.SaveAs(folderPath1 + file.FileName);
                        downloadpath1 = Shortpath1 + file.FileName.Trim();
                        string fileName1 = Path.GetFileName(file.FileName);
                        certification.t_cena = fileName1;
                        certification.t_cpat = downloadpath1;
                    }
                }
            }
            return Json(empDB.UpdateCertification(certification), JsonRequestBehavior.AllowGet);
        }

        //Bind Family Details in datatable
        //[HttpPost]
        public ActionResult BindFamily(string t_emno)
        {
            return Json(empDB.BindFamilyDet(t_emno), JsonRequestBehavior.AllowGet);

        }
        //Bind Family Details in datatable
        //[HttpPost]
        public ActionResult BindEducationDetails(string t_emno)
        {
            return Json(empDB.BindEducationDet(t_emno), JsonRequestBehavior.AllowGet);

        }

        //[HttpPost]
        public ActionResult BindDocumentDetails(string t_emno)
        {
            return Json(empDB.BindDocumenmtDet(t_emno), JsonRequestBehavior.AllowGet);

        }

        //[HttpPost]
        public ActionResult BindCompanyDetails(string t_emno)
        {
            return Json(empDB.BindCompanyDet(t_emno), JsonRequestBehavior.AllowGet);

        }

        //[HttpPost]
        public ActionResult BindPayslipDetails(string t_emno)
        {
            return Json(empDB.BindPayslipDet(t_emno), JsonRequestBehavior.AllowGet);

        }

        //[HttpPost]
        public ActionResult BindReferenceDetails(string t_emno)
        {
            return Json(empDB.BindReferenceDet(t_emno), JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindCertificationDetails(string t_emno)
        {
            return Json(empDB.BindCertificationDet(t_emno), JsonRequestBehavior.AllowGet);
        }

        //Retrive family details in textbox
        [HttpGet]
        public ActionResult GetFamilyDetails(string t_emno, string t_pono)
        {
            return Json(empDB.GetFamilyDetail(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        public ActionResult GetEducationDetails(string t_emno, string t_pono)
        {
            return Json(empDB.GetEducationDetail(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        public ActionResult GetDocumentDetails(string t_emno, string t_pono)
        {
            return Json(empDB.GetDocumentDetail(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }

        [HttpGet]
        public ActionResult GetCompanyDetails(string t_emno, string t_pono)
        {
            return Json(empDB.GetCompanyDetail(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        public ActionResult GetPayslipDetails(string t_emno, string t_pono)
        {
            return Json(empDB.GetPayslipDetail(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }

        [HttpGet]
        public ActionResult GetReferenceDetails(string t_emno, string t_pono)
        {
            return Json(empDB.GetReferenceDetail(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }

        [HttpGet]/* Certification Details retrive*/
        public ActionResult GetCertificationDetails(string t_emno, string t_pono)
        {
            return Json(empDB.GetCertificationDetail(t_emno, t_pono), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        public ActionResult FamilyDelete(string t_emno, string t_pono)
        {
            return Json(empDB.FamDelete(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }
        //[HttpPost]
        public ActionResult EducationDelele(string t_emno, string t_pono)
        {
            return Json(empDB.EduDelete(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }

        //[HttpPost]
        public ActionResult DocumentDelele(string t_emno, string t_pono)
        {
            return Json(empDB.DocDelete(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }
        //[HttpPost]
        public ActionResult CompanyDelele(string t_emno, string t_pono)
        {
            return Json(empDB.ComDelete(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }
        //[HttpPost]
        public ActionResult PayslipDelele(string t_emno, string t_pono)
        {
            return Json(empDB.PayDelete(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }

        //[HttpPost]
        public ActionResult ReferenceDelele(string t_emno, string t_pono)
        {
            return Json(empDB.RefDelete(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }
        //[HttpPost]
        public ActionResult CertificationDelele(string t_emno, string t_pono)
        {
            return Json(empDB.CerDelete(t_emno, t_pono), JsonRequestBehavior.AllowGet);

        }
        public ActionResult BindStateDetails()
        {
            return View();
        }
        public JsonResult BindState()
        {
            return Json(empDB.GetStateDetails(), JsonRequestBehavior.AllowGet);
        }
        //public ActionResult BindStatewise(string t_cste)
        //{
        //    return Json(empDB.GetStateWiseDetails(t_cste), JsonRequestBehavior.AllowGet);
        //}
        public ActionResult BindBankDetails()
        {
            return View();
        }
        public JsonResult BindBank()
        {
            return Json(empDB.GetBank(), JsonRequestBehavior.AllowGet);
        }
        public ActionResult BindBankwise(string t_bano)
        {
            return Json(empDB.GetBankName(t_bano), JsonRequestBehavior.AllowGet);
        }



    }
}