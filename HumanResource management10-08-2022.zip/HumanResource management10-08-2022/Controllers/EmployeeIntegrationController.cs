﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using HumanResourceManagement.Models;
using System.Web.SessionState;
namespace HumanResourceManagement.Controllers
{
    public class EmployeeIntegrationController : Controller
    {

        // GET: EmployeeIntegration
        string AlertPopupMsg = string.Empty;
        EmpIntegrationDB empDB = new EmpIntegrationDB();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult AddEmployee()
        {
            TempData["Selected"] = "0";
            TempData["Enabled"] = "0";
            TempData["Disabled"] = "1,2,3";
            return View();
        }
        
        //[HttpPost]
        public ActionResult GetBasicDetail()
        {
            
            return View();
        }
        public ActionResult GettTabledataList()
        { 
            List<Employee> obj = empDB.GetEmployeeDetails();
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetCandidateInfo(string t_emno)
        {
            if (!string.IsNullOrEmpty(t_emno))
            {
                Session["t_emno1"] = Convert.ToString(t_emno);
            }
            return Json(empDB.GetCandidateDetails(t_emno), JsonRequestBehavior.AllowGet);
        }
        //public ActionResult BindCandidateDocuments(string type1)
        //{
        //    //Session["t_emno"] = Convert.ToString(t_emno);
        //    if (!string.IsNullOrEmpty(Session["typ1"] as string))
        //    {
        //        type1 = Session["typ1"].ToString();
        //    }
           
        //    return View();
        //}
        //public ActionResult BindDocumentDetail(string t_emno, string t_dtyp)
        //{
        //    return Json(empDB.GetCandidateDocs(t_emno, t_dtyp), JsonRequestBehavior.AllowGet);
        //}
        //public ActionResult BindHighQualification()
        //{
        //    return View();
        //}
        public ActionResult BindFamily(string t_emno)
        {
            return Json(empDB.BindFamilyDet(t_emno), JsonRequestBehavior.AllowGet);

        }
        //public ActionResult BindEducation(string t_emno)
        //{
        //    return Json(empDB.GetQualification(t_emno), JsonRequestBehavior.AllowGet);
        //}
        public ActionResult BindEducationDetails(string t_emno)
        {
            return Json(empDB.BindEducationDet(t_emno), JsonRequestBehavior.AllowGet);

        }
        public ActionResult BindPayrollUnit()
        {
            return View();
        }
        public ActionResult GetCom100Payroll(string company)
        {
            return Json(empDB.GetCompany100Payroll(company), JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetCom200Payroll(string company)
        {
            return Json(empDB.GetCompany200Payroll(company), JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindPayroll(string t_emno)
        {
            return Json(empDB.GetPayrollUnit(t_emno), JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetPayrollUnitDesc(string t_puni)
        {
            return Json(empDB.GetPayrollDesc(t_puni), JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetPunching(string t_punc)
        {
            return Json(empDB.GetPunchCode(t_punc), JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetEmployeeId(string t_emno)
        {
            return Json(empDB.GetEmployeeCode(t_emno), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult AddEmployeeData(Employee _addEmp, List<Family> families, List<Education> educations)
        {
            return Json(empDB.AddEmpData(_addEmp, families, educations), JsonRequestBehavior.AllowGet);
        }
        //public ActionResult BindEmployeeData()
        //{
        //    return Json(empDB.BindEmployee(), JsonRequestBehavior.AllowGet);
        //}
        public ActionResult BindBankDetails()
        {
            return View();
        }
        public ActionResult BindBank()
        {
            return Json(empDB.GetBank(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindBankwise(string t_bano)
        {
            return Json(empDB.GetBankName(t_bano), JsonRequestBehavior.AllowGet);
        }
        public ActionResult ViewEmployee()
        {
            return View();
        }

        public ActionResult BindEmployeeData()
        {
            return Json(empDB.BindEmployee(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindEmployee()
        {
            return View();
        }

        public ActionResult BindEmployeeWise()
        {
            return Json(empDB.BindEmployeeWise(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetEmployeename(string t_emno)
        {
            return Json(empDB.GetEmpName(t_emno), JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindEmployeeIdWise(string t_emno)
        {
            return Json(empDB.BindEmployeeID(t_emno), JsonRequestBehavior.AllowGet);
        }


    }
}