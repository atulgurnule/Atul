﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

using System.IO;
using System.Text;
using System.Security.Cryptography;

using HumanResourceManagement.Models;

namespace HumanResourceManagement.Controllers
{
    public class HomeController : Controller
    {
        UserDataDB userDB = new UserDataDB();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Paging_Search()
        {
            return View();
        }
        [HttpPost]
        public ActionResult BindBusinessPartner(int pageIndex)
        {
            return Json(userDB.BindPartnerDetails(pageIndex), JsonRequestBehavior.AllowGet);

        }
        [HttpPost]
        public JsonResult ValidateUser(UserData userdb)
        //string userid, string password)
        {
            Session["t_emno"] = userdb.t_emno;
            return Json(userDB.GetLoginDataFromDB(userdb), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult ValidateUserLogin(UserData userdb)
        //string userid, string password)
        {
            Session["t_emno"] = userdb.t_emno;
            return Json(userDB.GetLoginDataFromDB(userdb), JsonRequestBehavior.AllowGet);
        }

        //public ActionResult LogOut()
        //{
        //    Session["t_emno"] = null;
        //    FormsAuthentication.SignOut();

        //    return RedirectToAction("Index", "Home");
        //}
        [HttpPost]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon();
            return RedirectToAction("Index", "Home");
        }
       
    }
}