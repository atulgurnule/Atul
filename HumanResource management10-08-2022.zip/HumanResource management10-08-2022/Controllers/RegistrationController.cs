﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HumanResourceManagement.Models;
namespace HumanResourceManagement.Controllers
{
    public class RegistrationController : Controller
    {
        UserRegistrationDB Reg = new UserRegistrationDB();
        // GET: Registration
        public ActionResult RegistrationDetails()
        {
            return View();
        }
        [HttpPost]
        public JsonResult AddUser(UserRegistration user)
        {
            //_salOrd.t_logn = Convert.ToString(Session["uname"]);
            return Json(Reg.AddUser(user), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetUserDetails(string t_emno)
        {
          
            return Json(Reg.GetDetails(t_emno), JsonRequestBehavior.AllowGet);
        }
        public ActionResult CandidateDelete(string t_emno)
        {
            return Json(Reg.CanDelete(t_emno), JsonRequestBehavior.AllowGet);

        }
    }
}