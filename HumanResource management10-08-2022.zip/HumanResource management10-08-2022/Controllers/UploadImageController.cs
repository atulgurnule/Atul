﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using Microsoft.AspNetCore.Hosting;
//using Microsoft.AspNetCore.Hosting.Internal;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
using HumanResourceManagement.Models;

namespace HumanResourceManagement.Controllers
{
    public class UploadImageController : Controller
    {
        // GET: UploadImage
        public ActionResult UploadImage()
        {
            return View();
        }

        public ActionResult UploadFiles(HttpPostedFileBase file)
        //IEnumerable<HttpPostedFileBase> files
        {
            //foreach (var file in files)
            //{
            if (file.ContentLength > 0)
            {
                var fileName = Path.GetFileName(file.FileName);
                var path = Path.Combine(Server.MapPath("~/UploadFiles/Resume/"), fileName);
                file.SaveAs(path);
            }
            //}
            //string response;
            //HttpFileCollectionBase files = Request.Files;
            //if (Request.Files.Count > 0)
            //{

            //    for (int i = 0; i < files.Count; i++)
            //    {
            //        //string resume = new System.Linq.SystemCore_EnumerableDebugView(Request.Files).Items[0].ToString();
            //        if (i == 0)
            //        {
            //            string path = Server.MapPath("~/UploadFiles/Resume/");
            //            HttpPostedFileBase file = files[i];
            //            file.SaveAs(path + file.FileName);
            //        }
            //        else if(i==1)
            //        {
            //            string path1 = Server.MapPath("~/UploadFiles/ProfilePhoto/");
            //            HttpPostedFileBase file1 = files[i];
            //            file1.SaveAs(path1 + file1.FileName);
            //        }
            //        else
            //        {
            //            response = "Image Not Upload";
            //        }

            //    }

            //}


            //return Json(files.Count + " Files Uploaded!");
            return Json(" Files Uploaded!");
        }
    }
}