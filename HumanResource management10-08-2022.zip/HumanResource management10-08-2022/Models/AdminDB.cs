﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using HumanResourceManagement.Models;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Web.UI;
using System.Text;


using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

namespace HumanResourceManagement.Models
{
    
    public class AdminDB
    {
        string cs = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
        private string message = string.Empty;

        public List<UserRegistration> BindRegistrationDet()
        {
            string response = string.Empty;
            //string dobOfFamMem=string.Empty;
            try
            {
                List<UserRegistration> Userlst = new List<UserRegistration>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWUserRegistration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    //comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime TodayDate = Convert.ToDateTime(rdr["t_dobt"]);
                        //string dateofbirth = TodayDate.ToString("dd-MM-yyyy");
                       
                        Userlst.Add(new UserRegistration
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_emai = rdr["t_emai"].ToString(),
                            t_mobl = rdr["t_mobl"].ToString(),
                            t_pass = rdr["t_pass"].ToString(),
                            t_stat = rdr["t_stat"].ToString(),
                            t_pemp = rdr["t_pemp"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Userlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<AdminRegistration> BindRegistrationAdmin()
        {
            string response = string.Empty;
            //string dobOfFamMem=string.Empty;
            try
            {
                List<AdminRegistration> Userlst = new List<AdminRegistration>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWAdminRegistration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    //comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime TodayDate = Convert.ToDateTime(rdr["t_dobt"]);
                        //string dateofbirth = TodayDate.ToString("dd-MM-yyyy");

                        Userlst.Add(new AdminRegistration
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_emai = rdr["t_emai"].ToString(),
                            t_mobl = rdr["t_mobl"].ToString(),
                            t_pass = rdr["t_pass"].ToString(),
                            t_crdt = rdr["t_crdt"].ToString(),
                           

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Userlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<AdminRegistration> GetDetails(string t_emno)
        {
            try
            {
                string response = string.Empty;
                List<AdminRegistration> User = new List<AdminRegistration>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWAdminRegistration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "S");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        User.Add(new AdminRegistration
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_emai = rdr["t_emai"].ToString(),
                            t_mobl = rdr["t_mobl"].ToString(),
                            t_pass = rdr["t_pass"].ToString(),

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return User;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string AdminDelete(string t_emno)
        {
            string response = string.Empty;
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand com = new SqlCommand("testdb..[SWAdminRegistration]", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@t_emno", t_emno);
                    com.Parameters.AddWithValue("@Action", "D");
                    com.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    com.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    com.ExecuteNonQuery();
                    message = (string)com.Parameters["@ERROR"].Value.ToString();
                    con.Close();
                    response = message;

                }
                return response;
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return response;
        }

        public List<Employee> BindBasicDet(string t_emno)
        {
            string response = string.Empty;
            //string dobOfFamMem=string.Empty;
            try
            {
                List<Employee> Emplst = new List<Employee>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime TodayDate = Convert.ToDateTime(rdr["t_dobt"]);
                        //string dateofbirth = TodayDate.ToString("dd-MM-yyyy");

                        Emplst.Add(new Employee
                        {
                            
                            t_emno=rdr["t_emno"].ToString(),
                            employeeName = rdr["employeeName"].ToString(),
                            t_path = rdr["t_path"].ToString(),
                            t_rpat = rdr["t_rpat"].ToString(),
                            t_motn =rdr["t_motn"].ToString(),
                            t_gend = Convert.ToInt32(rdr["t_gend"].ToString()),
                            //t_dobt = Convert.ToDateTime(rdr["t_dobt"].ToString()),
                            t_dobt = rdr["t_dobt"].ToString(),
                            t_plob = rdr["t_plob"].ToString(),
                            t_culo = rdr["t_culo"].ToString(),
                            t_cadr = rdr["t_cadr"].ToString(),
                            t_coad = rdr["t_coad"].ToString(),
                            //t_cste = rdr["t_cste"].ToString(),
                            t_cstedesc = rdr["t_cstedesc"].ToString(),
                            t_city = rdr["t_city"].ToString(),
                            t_nati = rdr["t_nati"].ToString(),
                            t_matr = Convert.ToInt32(rdr["t_matr"].ToString()),
                            //t_datm = Convert.ToDateTime(rdr["t_datm"].ToString()),
                            t_datm = rdr["t_datm"].ToString(),
                            t_mobl = rdr["t_mobl"].ToString(),
                            t_emmo = rdr["t_emmo"].ToString(),
                            t_emai = rdr["t_emai"].ToString(),
                            t_reli = rdr["t_reli"].ToString(),
                            t_cast = rdr["t_cast"].ToString(),
                            t_motl = rdr["t_motl"].ToString(),
                            t_etyp = rdr["t_etyp"].ToString(),
                            t_woex = rdr["t_woex"].ToString(),
                            t_esic = rdr["t_esic"].ToString(),
                            t_uanc = rdr["t_uanc"].ToString(),
                            t_bano = rdr["t_bano"].ToString(),
                            t_bank = rdr["t_bank"].ToString(),
                            t_ifsc = rdr["t_ifsc"].ToString(),
                            t_stat = rdr["t_stat"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<UserRegistration> BindRegistrationCom()
        {
            string response = string.Empty;
            //string dobOfFamMem=string.Empty;
            try
            {
                List<UserRegistration> Userlst = new List<UserRegistration>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWUserRegistration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECTCOMPLETED");
                    //comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        
                         Userlst.Add(new UserRegistration
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_emai = rdr["t_emai"].ToString(),
                            t_mobl = rdr["t_mobl"].ToString(),
                            t_pass = rdr["t_pass"].ToString(),
                            t_stat = rdr["t_stat"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Userlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string AddAdminDet(AdminRegistration admin)
        {
            string response = string.Empty;
            int i;
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWAdminRegistration]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    if (admin.t_emno == null)
                    {
                        comm.Parameters.AddWithValue("@t_emno", null);
                    }
                    else
                    {
                        comm.Parameters.AddWithValue("@t_emno", admin.t_emno);
                    }
                    comm.Parameters.AddWithValue("@Action", admin.Action);
                    //comm.Parameters.AddWithValue("@Action", "INSERT");
                    //comm.Parameters.AddWithValue("@t_emno", "1001");
                    comm.Parameters.AddWithValue("@t_nama", admin.t_nama);
                    comm.Parameters.AddWithValue("@t_emai", admin.t_emai);
                    comm.Parameters.AddWithValue("@t_mobl", admin.t_mobl);
                    comm.Parameters.AddWithValue("@t_pass", admin.t_pass);
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    /////////////////Send Mail To User////////////////////////////
                    string Feedback;
                    //string EmailMode = "Admin";
                    //string AdminMail1 = "atul.gurnule7@gmail.com";
                    //const string SERVER = "relay-hosting.secureserver.net";
                    if (admin.t_emai != "")
                    {
                        /////////////////////////
                        using (StringWriter sw = new StringWriter())
                        {
                            using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                            {
                                //////////////////////////////

                                StringBuilder sb = new StringBuilder();
                                sb.Append("<html><body>");
                                //sb.Append("<img src='~/HumanResourceManagement/HumanResourceManagement/dist/img/loginlogo.png' alt='Smiley face'  width='35%' height='15%'/>");
                                //sb.Append("<hr size='15' style='background-color:#72AFD1'>");
                                sb.Append("<h2>SPACEWOOD FURNISHERS PVT LTD.</h2>");
                                sb.Append("<h4>Hi, " + admin.t_nama + "</h4>");
                                sb.Append("<h4>Thank You For Contacting Us</h4>");
                                sb.Append("<p>You have registered successfully in spacewood.</p>");
                                sb.Append("</br>");
                                //sb.Append("<style>table, th, td { border: 1px solid black;border-collapse: collapse;}</style>");
                                sb.Append("<hr>");
                                sb.Append("<table>");
                                sb.Append("<tr>");
                                sb.Append("<h4>Please note your user name and password for all further communication with Spacewood.</h4>");
                                sb.Append("</tr>");
                                sb.Append("<tr >");
                                sb.Append("<td>User name: <b>" + admin.t_mobl + "</b></td>");
                                sb.Append("</tr>");
                                sb.Append("<tr>");
                                sb.Append("<td>Password: <b>" + admin.t_pass + "</b></td>");
                                sb.Append("</tr>");
                                sb.Append("</br>");
                                sb.Append("</table>");

                                sb.Append("<p><b>Regards,</b></p>");
                                sb.Append("<p><b>Team Spacewood</b></p>");
                                sb.Append("</body></html>");

                                //StringReader sr = new StringReader(sb.ToString());
                                Feedback = sb.ToString();


                                //MailMessage oMail = new MailMessage();
                                //oMail.From = new MailAddress(AdminMail1);
                                //oMail.To.Add(admin.t_emai);

                                //oMail.Subject = "Spacewood | Registration Details";
                                //oMail.IsBodyHtml = true; // enumeration
                                //oMail.Priority = MailPriority.High; // enumeration
                                //oMail.Body = Feedback;
                                //SmtpClient smtp = new SmtpClient();
                                ////smtp.Host = "email-smtp.us-east-1.amazonaws.com";smtp.gmail.com
                                //smtp.Host = "smtp.gmail.com";
                                //smtp.EnableSsl = true;
                                //NetworkCredential NetworkCred = new NetworkCredential("atul.gurnule7@gmail.com", "atul$1987");
                                ////smtp.UseDefaulCredentials = true;
                                //smtp.Credentials = NetworkCred;
                                //smtp.Port = 587;
                                ////vbnguwwiuntyorlm
                                //smtp.Send(oMail);
                                con.Open();
                                SqlCommand cmd = new SqlCommand("testdb..[SWSendEmailUserRegistratioComplete]", con);

                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@subject", "Spacewood | Admin Registration Details");
                                //cmd.Parameters.AddWithValue("@profile", "SpacewoodMail");
                                cmd.Parameters.AddWithValue("@profile", "SpacewoodHRMailProfile");
                                //cmd.Parameters.AddWithValue("@profile", "scp_mail");
                                cmd.Parameters.AddWithValue("@to", admin.t_emai);
                                cmd.Parameters.AddWithValue("@cc", "");
                                cmd.Parameters.AddWithValue("@bcc", "");
                                cmd.Parameters.AddWithValue("@mbody", Feedback);
                                i = cmd.ExecuteNonQuery();
                                con.Close();

                            }

                        }
                    }
                    /////////////////////End Mail///////////////////////////////////
                    response = message;
                    return response;
               
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }

        }

      
        public List<UserData> GetLoginDataAdmin(AdminRegistration userdb)
        //string userId, string password
        {
            //string Uid, pass;
            try
            {
                //string cs = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
                var userList = new List<UserData>();


                SqlConnection con = new SqlConnection(cs);
                con.Open();
                SqlCommand cmd = new SqlCommand("testdb..[SWAdminRegistration]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "ADMINLOGIN");
                cmd.Parameters.Add(new SqlParameter("@t_mobl", userdb.t_mobl));
                cmd.Parameters.Add(new SqlParameter("@t_pass", userdb.t_pass));
                cmd.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                cmd.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    HttpContext.Current.Session["userName"] = userdb.t_nama;
                    userList.Add(new UserData
                    {

                        t_mobl = rdr["t_mobl"].ToString(),
                        t_pass = rdr["t_pass"].ToString(),
                        t_emno = rdr["t_emno"].ToString(),
                        t_nama = rdr["t_nama"].ToString()

                    });

                }
                con.Close();
                message = (string)cmd.Parameters["@ERROR"].Value.ToString();
                if (userList.Count != 0)
                {
                    HttpContext.Current.Session["empid"] = userList[0].t_emno;
                    HttpContext.Current.Session["userName"] = userList[0].t_nama;
                }
                return userList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Family> BindFamilyDet(string t_emno)
        {
            string response = string.Empty;
            //string dobOfFamMem=string.Empty;
            try
            {
                List<Family> Famlst = new List<Family>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpFamilyDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    //comm.Parameters.Add(new SqlParameter("@SalOrdNo", SalOrdNo));
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime TodayDate = Convert.ToDateTime(rdr["t_dobt"]);
                        //string dateofbirth = TodayDate.ToString("dd-MM-yyyy");
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Famlst.Add(new Family
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_rela = rdr["t_rela"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            //t_dobt = Convert.ToDateTime(MemberDOB),
                            t_dobt = rdr["t_dobt"].ToString(),
                            t_mema = rdr["t_mema"].ToString(),
                            t_mmob = rdr["t_mmob"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Famlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Education> BindEducationDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Education> Edulst = new List<Education>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpEducationDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    //comm.Parameters.Add(new SqlParameter("@SalOrdNo", SalOrdNo));
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Edulst.Add(new Education
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_educ = rdr["t_educ"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_boar = rdr["t_boar"].ToString(),
                            t_poyr = Convert.ToInt32(rdr["t_poyr"].ToString()),
                            t_scmd = rdr["t_scmd"].ToString(),
                            t_crse = rdr["t_crse"].ToString(),
                            t_spec = rdr["t_spec"].ToString(),
                            t_univ = rdr["t_univ"].ToString(),
                            t_coty = rdr["t_coty"].ToString(),
                            t_totm = rdr["t_totm"].ToString(),
                            t_ecpa = rdr["t_ecpa"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Edulst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Document> BindDocumenmtDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Document> Doclst = new List<Document>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpDocumentDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    //comm.Parameters.Add(new SqlParameter("@SalOrdNo", SalOrdNo));
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Doclst.Add(new Document
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_dtyp = rdr["t_dtyp"].ToString(),
                            t_docm = rdr["t_docm"].ToString(),
                            t_dpat = rdr["t_dpat"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Doclst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Company> BindCompanyDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Company> Comlst = new List<Company>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpCompanyDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Comlst.Add(new Company
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_dnam = rdr["t_dnam"].ToString(),
                            t_orga = rdr["t_orga"].ToString(),
                            t_expe = rdr["t_expe"].ToString(),
                            t_cuco = rdr["t_cuco"].ToString(),
                            t_year = rdr["t_year"].ToString(),
                            t_mont = rdr["t_mont"].ToString(),
                            t_toyr = rdr["t_toyr"].ToString(),
                            t_tomo = rdr["t_tomo"].ToString(),
                            t_dyjp = rdr["t_dyjp"].ToString(),
                            t_cena = rdr["t_cena"].ToString(),
                            t_epat = rdr["t_epat"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Comlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Payslip> BindPayslipDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Payslip> Paylst = new List<Payslip>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpPaySlipDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Paylst.Add(new Payslip
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_paym = rdr["t_paym"].ToString(),
                            t_payy = rdr["t_payy"].ToString(),
                            t_psna = rdr["t_psna"].ToString(),
                            t_ppat = rdr["t_ppat"].ToString(),
                            t_stat = rdr["t_stat"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Paylst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Reference> BindReferenceDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Reference> Reflst = new List<Reference>();
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpReferenceDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Reflst.Add(new Reference
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_rnam = rdr["t_rnam"].ToString(),
                            t_phon = rdr["t_phon"].ToString(),
                            t_stat = rdr["t_stat"].ToString()


                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Reflst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Certification> BindCertificationDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Certification> Cerlst = new List<Certification>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpCertificationDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {

                        Cerlst.Add(new Certification
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_cnam = rdr["t_cnam"].ToString(),
                            t_cema = rdr["t_cema"].ToString(),
                            t_cena = rdr["t_cena"].ToString(),
                            t_cpat = rdr["t_cpat"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Cerlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Employee> GetEmpName(string t_emno)
        {
            try
            {
                List<Employee> emplst = new List<Employee>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        emplst.Add(new Employee
                        {
                             employeeName = rdr["employeeName"].ToString(),
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    return emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}