﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class AdminRegistration
    {
        public string t_emno { get; set; }
        public string t_nama { get; set; }
        public string t_emai { get; set; }
        public string t_mobl { get; set; }
        public string t_pass { get; set; }
        public string t_stat { get; set; }
        public string t_crdt { get; set; }
        public string Action { get; set; }

    }
}