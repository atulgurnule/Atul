﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class Bank
    {
        public string t_bano { get; set; }
        public string t_bnam { get; set; }
        public string t_ifsc { get; set; }
        
    }
}