﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class Company
    {
        public string t_emno { get; set; }
        public int t_pono { get; set; }
        public string t_orga { get; set; }
        public string t_dnam { get; set; }
        public string t_expe { get; set; }
        public string t_cuco { get; set; }
        public string t_year { get; set; }
        public string t_mont { get; set; }
        public string t_toyr { get; set; }
        public string t_tomo { get; set; }
        public string t_dyjp { get; set; }
        public string t_cena { get; set; }
        public string t_epat { get; set; }
        public HttpPostedFileBase uploadExpCertificate { get; set; }
        public string AlertPopupMsg { get; set; }
        public string t_stat { get; set; }
    }
}