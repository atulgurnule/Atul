﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class Document
    {
        public string t_emno { get; set; }
        public int t_pono { get; set; }
        public string t_dtyp { get; set; }
        public string t_docm { get; set; }
        public string t_imag { get; set; }
        public string t_dpat { get; set; }
        public HttpPostedFileBase uploadDocument { get; set; }
        public string AlertPopupMsg { get; set; }
        public string t_stat { get; set; }


    }
}