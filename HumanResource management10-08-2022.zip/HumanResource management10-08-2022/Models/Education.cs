﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class Education
    {
        public string t_emno { get; set; }
        public int t_pono { get; set; }
        public string t_educ { get; set; }
        public string t_boar { get; set; }
        public Nullable<int> t_poyr { get; set; }
        public string t_scmd { get; set; }
        public string t_crse { get; set; }
        public string t_spec { get; set; }
        public string t_univ { get; set; }
        public string t_coty { get; set; }
        public string t_totm { get; set; }
        public string t_cena { get; set; }
        public string t_ecpa { get; set; }
        public HttpPostedFileBase uploadEduCertificate { get; set; }
        public string AlertPopupMsg { get; set; }
        public string t_stat { get; set; }

    }
}