﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using HumanResourceManagement.Models;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Web.UI;
using System.Text;
using context = System.Web.HttpContext;

using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

using System.Collections;
using System.Globalization;

namespace HumanResourceManagement.Models
{
    public class EmpIntegrationDB
    {
        string cs = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
        private string message = string.Empty;
        public List<Employee> GetEmployeeDetails()
        {
            try
            {
                string response = string.Empty;

                List<Employee> Emplst = new List<Employee>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "S");
                    //comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Emplst.Add(new Employee
                        {

                            t_emno = rdr["t_emno"].ToString(),
                            t_firn = rdr["t_firn"].ToString(),
                            t_midn = rdr["t_midn"].ToString(),
                            t_lasn = rdr["t_lasn"].ToString(),
                            t_motn = rdr["t_motn"].ToString(),
                            t_gend = Convert.ToInt32(rdr["t_gend"].ToString()),
                            t_dobt = rdr["t_dobt"].ToString(),
                            t_plob = rdr["t_plob"].ToString(),
                            t_city = rdr["t_city"].ToString(),
                            t_cste = rdr["t_cste"].ToString(),
                            t_nati = rdr["t_nati"].ToString(),
                            t_mobl = rdr["t_mobl"].ToString(),
                            t_emai = rdr["t_emai"].ToString(),
                            t_etyp = rdr["t_etyp"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                    return Emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Employee> GetCandidateDetails(string t_emno)
        {
            try
            {
                string response = string.Empty;
                HttpContext.Current.Session["t_emno1"] = t_emno;
                List<Employee> Emplst = new List<Employee>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb.dbo.[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "R");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Emplst.Add(new Employee
                        {

                            t_emno = rdr["t_emno"].ToString(),
                            t_firn = rdr["t_firn"].ToString(),
                            t_midn = rdr["t_midn"].ToString(),
                            t_lasn = rdr["t_lasn"].ToString(),
                            t_motn = rdr["t_motn"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_gend = Convert.ToInt32(rdr["t_gend"].ToString()),
                            t_dobt = rdr["t_dobt"].ToString(),
                            t_plob = rdr["t_plob"].ToString(),
                            t_culo = rdr["t_culo"].ToString(),
                            t_mobl = rdr["t_mobl"].ToString(),
                            t_cadr = rdr["t_cadr"].ToString(),
                            t_coad = rdr["t_coad"].ToString(),
                            t_matr = Convert.ToInt32(rdr["t_matr"].ToString()),
                            t_datm = rdr["t_datm"].ToString(),
                            t_emai = rdr["t_emai"].ToString(),
                            t_cste = rdr["t_cste"].ToString(),
                            t_cstedesc = rdr["t_cstedesc"].ToString(),
                            t_nati = rdr["t_nati"].ToString(),
                            t_motl = rdr["t_motl"].ToString(),
                            t_reli = rdr["t_reli"].ToString(),
                            t_etyp = rdr["t_etyp"].ToString(),
                            t_esic = rdr["t_esic"].ToString(),
                            t_bano = rdr["t_bano"].ToString(),
                            t_bank = rdr["t_bank"].ToString(),
                            t_uanc = rdr["t_uanc"].ToString(),
                            t_adhe = rdr["t_adhe"].ToString(),
                            t_panu = rdr["t_panu"].ToString(),
                            t_high = rdr["t_high"].ToString()



                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                    return Emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public List<Document> GetCandidateDocs(string t_emno, string t_dtyp)
        //{
        //    try
        //    {
        //        string response = string.Empty;

        //        List<Document> Emplst = new List<Document>();

        //        using (SqlConnection con = new SqlConnection(cs))
        //        {

        //            con.Open();
        //            SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
        //            comm.CommandType = CommandType.StoredProcedure;
        //            comm.Parameters.AddWithValue("@Action", "DOC");
        //            comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
        //            comm.Parameters.Add(new SqlParameter("@t_dtyp", t_dtyp));
        //            comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
        //            comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
        //            SqlDataReader rdr = comm.ExecuteReader();

        //            while (rdr.Read())
        //            {
        //                Emplst.Add(new Document
        //                {

        //                    t_emno = rdr["t_emno"].ToString(),
        //                    t_dtyp = rdr["t_dtyp"].ToString(),
        //                    t_docm = rdr["t_docm"].ToString(),

        //                });
        //            }
        //            con.Close();
        //            message = (string)comm.Parameters["@ERROR"].Value.ToString();
        //            response = message;

        //            return Emplst;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        public List<Family> BindFamilyDet(string t_emno)
        {
            string response = string.Empty;
            //string dobOfFamMem=string.Empty;
            try
            {
                List<Family> Famlst = new List<Family>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpFamilyDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    //comm.Parameters.Add(new SqlParameter("@SalOrdNo", SalOrdNo));
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                      
                        Famlst.Add(new Family
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_rela = rdr["t_rela"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_dobt = rdr["t_dobt"].ToString(),
                            t_mema = rdr["t_mema"].ToString(),
                            t_mmob = rdr["t_mmob"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Famlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Education> BindEducationDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Education> Edulst = new List<Education>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpEducationDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    //comm.Parameters.Add(new SqlParameter("@SalOrdNo", SalOrdNo));
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Edulst.Add(new Education
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_educ = rdr["t_educ"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_boar = rdr["t_boar"].ToString(),
                            t_poyr = Convert.ToInt32(rdr["t_poyr"].ToString()),
                            t_scmd = rdr["t_scmd"].ToString(),
                            t_crse = rdr["t_crse"].ToString(),
                            t_spec = rdr["t_spec"].ToString(),
                            t_univ = rdr["t_univ"].ToString(),
                            t_coty = rdr["t_coty"].ToString(),
                            t_totm = rdr["t_totm"].ToString(),
                            t_ecpa = rdr["t_ecpa"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Edulst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //public List<Education> GetQualification(string t_emno)
        //{
        //    try
        //    {
        //        string response = string.Empty;

        //        List<Education> Emplst = new List<Education>();

        //        using (SqlConnection con = new SqlConnection(cs))
        //        {

        //            con.Open();
        //            SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
        //            comm.CommandType = CommandType.StoredProcedure;
        //            comm.Parameters.AddWithValue("@Action", "EDU");
        //            comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
        //            comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
        //            comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
        //            SqlDataReader rdr = comm.ExecuteReader();

        //            while (rdr.Read())
        //            {
        //                Emplst.Add(new Education
        //                {

        //                    //t_emno = rdr["t_emno"].ToString(),
        //                    //t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
        //                    t_educ = rdr["t_educ"].ToString(),
        //                    t_boar = rdr["t_boar"].ToString(),
        //                    t_poyr = Convert.ToInt32(rdr["t_poyr"].ToString()),
        //                    t_scmd = rdr["t_scmd"].ToString(),
        //                    t_crse = rdr["t_crse"].ToString(),
        //                    t_spec = rdr["t_spec"].ToString(),
        //                    t_univ = rdr["t_univ"].ToString(),
        //                    t_coty = rdr["t_coty"].ToString(),
        //                    t_totm = rdr["t_totm"].ToString()

        //                });
        //            }
        //            con.Close();
        //            message = (string)comm.Parameters["@ERROR"].Value.ToString();
        //            response = message;

        //            return Emplst;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        public List<Payrollunit> GetPayrollUnit(string t_emno)
        {
            try
            {
                string response = string.Empty;

                List<Payrollunit> Emplst = new List<Payrollunit>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "PAY");
                    //comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Emplst.Add(new Payrollunit
                        {

                            //t_emno = rdr["t_emno"].ToString(),
                            //t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_puni = rdr["t_puni"].ToString(),
                            t_pnam = rdr["t_pnam"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                    return Emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Payrollunit> GetCompany100Payroll(string company)
        {
            try
            {
                string response = string.Empty;

                List<Payrollunit> Emplst = new List<Payrollunit>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "PAYROLL");
                    comm.Parameters.Add(new SqlParameter("@TransCompany", company));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Emplst.Add(new Payrollunit
                        {
                            
                            t_puni = rdr["t_puni"].ToString(),
                            t_pnam = rdr["t_pnam"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Payrollunit> GetCompany200Payroll(string company)
        {
            try
            {
                string response = string.Empty;

                List<Payrollunit> Emplst = new List<Payrollunit>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "PAYROLL");
                    comm.Parameters.Add(new SqlParameter("@TransCompany", company));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();
                    while (rdr.Read())
                    {
                        Emplst.Add(new Payrollunit
                        {

                            t_puni = rdr["t_puni"].ToString(),
                            t_pnam = rdr["t_pnam"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Payrollunit> GetPayrollDesc(string t_puni)
        {
            try
            {
                string response = string.Empty;
                List<Payrollunit> Emplst = new List<Payrollunit>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb.dbo.[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "PAY");
                    comm.Parameters.Add(new SqlParameter("@t_puni", t_puni));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();
                    while (rdr.Read())
                    {
                        Emplst.Add(new Payrollunit
                        {
                            t_puni = rdr["t_puni"].ToString(),
                            t_pnam = rdr["t_pnam"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string AddEmpData(Employee _addEmp,List<Family> families,List<Education> educations)
        {
            int i;
            string response = string.Empty;
            string response1 = string.Empty;
            string response2 = string.Empty;
            string response3 = string.Empty;
            //DateTime dobdatetime;
            //DateTime domdatetime;
            try
            {
                string EmpNo = _addEmp.t_emno;
                string DOMToday;
                if (_addEmp.t_datm == null)
                {
                    DOMToday = "01-01-1900";
                }
                else
                {
                    DOMToday = _addEmp.t_datm;
                }
                //string LEmpdate = string.Empty;
                //if(_addEmp.t_laem == null)
                //{
                //    LEmpdate = "01-01-1900";
                //}
                //else
                //{
                //    LEmpdate = _addEmp.t_laem;
                //}
                string cs1 = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
                using (SqlConnection con = new SqlConnection(cs1))
                {
                    SqlCommand comm = new SqlCommand("testdb..[SWAddEmployeeDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", _addEmp.t_emno);
                    comm.Parameters.AddWithValue("@t_canId", _addEmp.t_canId);
                    comm.Parameters.AddWithValue("@t_fir_n", _addEmp.t_fir_n);
                    comm.Parameters.AddWithValue("@t_midn", _addEmp.t_midn);
                    comm.Parameters.AddWithValue("@t_lasn", _addEmp.t_lasn);
                    comm.Parameters.AddWithValue("@t_motn", _addEmp.t_motn);
                    comm.Parameters.AddWithValue("@t_gend", _addEmp.t_gend);
                    comm.Parameters.AddWithValue("@t_dobt", _addEmp.t_dobt);
                    comm.Parameters.AddWithValue("@t_plob", _addEmp.t_plob);
                    comm.Parameters.AddWithValue("@t_culo", _addEmp.t_culo);
                    comm.Parameters.AddWithValue("@t_nati", _addEmp.t_nati);
                    comm.Parameters.AddWithValue("@t_matr", _addEmp.t_matr);
                    comm.Parameters.AddWithValue("@t_datm", DOMToday);
                    comm.Parameters.AddWithValue("@t_phon", _addEmp.t_phon);
                    comm.Parameters.AddWithValue("@t_emai", _addEmp.t_emai);
                    comm.Parameters.AddWithValue("@t_reli", String.IsNullOrEmpty(_addEmp.t_reli) ? "" : (object)_addEmp.t_reli);
                    comm.Parameters.AddWithValue("@t_motl", String.IsNullOrEmpty(_addEmp.t_motl) ? "" : (object)_addEmp.t_motl);
                    comm.Parameters.AddWithValue("@t_high", _addEmp.t_high);
                    comm.Parameters.AddWithValue("@t_dojd", _addEmp.t_dojd);
                    comm.Parameters.AddWithValue("@t_empt", _addEmp.t_empt);
                    comm.Parameters.AddWithValue("@t_cste", _addEmp.t_cste);
                    comm.Parameters.AddWithValue("@t_esic", String.IsNullOrEmpty(_addEmp.t_esic) ? "" : (object)_addEmp.t_esic);
                   
                   
                    if (_addEmp.t_bank == null)
                    {
                        comm.Parameters.AddWithValue("@t_bank", "");
                    }
                    else
                    {
                        comm.Parameters.AddWithValue("@t_bank", _addEmp.t_bank);
                    }
                    //comm.Parameters.AddWithValue("@t_bank", _addEmp.t_bank);
                   
                    if (_addEmp.t_bano == null)
                    {
                        comm.Parameters.AddWithValue("@t_bano", "");
                    }
                    else
                    {
                        comm.Parameters.AddWithValue("@t_bano", _addEmp.t_bano);
                    }
                    //comm.Parameters.AddWithValue("@t_bano", _addEmp.t_bano);

                    comm.Parameters.AddWithValue("@t_uanc", String.IsNullOrEmpty(_addEmp.t_uanc) ? "" : (object)_addEmp.t_uanc);
                    comm.Parameters.AddWithValue("@t_adhe", _addEmp.t_adhe);
                    comm.Parameters.AddWithValue("@t_panu", _addEmp.t_panu);
                    comm.Parameters.AddWithValue("@t_week", _addEmp.t_week);
                    comm.Parameters.AddWithValue("@t_shif", _addEmp.t_shif);
                    comm.Parameters.AddWithValue("@t_punc", _addEmp.t_punc);
                    //comm.Parameters.AddWithValue("@t_padr", _addEmp.t_cadr);
                    //comm.Parameters.AddWithValue("@t_cadr", _addEmp.t_coad);
                    comm.Parameters.AddWithValue("@t_padr", "");
                    comm.Parameters.AddWithValue("@t_cadr", "");
                    //comm.Parameters.AddWithValue("@t_laem", LEmpdate);
                    comm.Parameters.AddWithValue("@t_atos", _addEmp.t_atos);
                    comm.Parameters.AddWithValue("@t_nama", _addEmp.t_nama);
                    comm.Parameters.AddWithValue("@t_puni", _addEmp.t_puni);

                    comm.Parameters.AddWithValue("@Action", "I");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    con.Open();
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    //response = "";
                    //For Insert Employee Location
                    if(response == "SUCCESS")
                    { 
                        using (SqlConnection con3 = new SqlConnection(cs1))
                        {
                            string msg1 = string.Empty;
                            SqlCommand comm1 = new SqlCommand("testdb..[SWAddEmployeeDetails]", con3);

                            comm1.CommandType = CommandType.StoredProcedure;
                            comm1.Parameters.AddWithValue("@t_emno", _addEmp.t_emno);
                            comm1.Parameters.AddWithValue("@t_culo", _addEmp.t_culo);
                            comm1.Parameters.AddWithValue("@t_cste", _addEmp.t_cste);
                            comm1.Parameters.AddWithValue("@Action", "L");
                            comm1.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                            comm1.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                            con3.Open();
                            i = comm1.ExecuteNonQuery();
                            con3.Close();
                            msg1 = (string)comm1.Parameters["@ERROR"].Value.ToString();
                            response1 = msg1;
                          
                        }

                        //Start Family
                        if (families != null)
                        {
                        
                            foreach (Family family in families)
                            {
                                //string query = "INSERT INTO Customers VALUES(@Name, @Country)";
                                //SqlCommand com = new SqlCommand("test..[SWAddEmployeeDetails]", con);
                                //string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
                                int relation = 0;
                                string msg2 = string.Empty;
                                using (SqlConnection con1 = new SqlConnection(cs1))
                                {
                                    using (SqlCommand cmd = new SqlCommand("testdb.dbo.[SWAddEmployeeDetails]", con1))
                                    {
                                        cmd.CommandType = CommandType.StoredProcedure;
                                        cmd.Parameters.AddWithValue("@t_emno", family.t_emno);
                                    
                                        if (family.t_rela == "Father")
                                        {
                                            relation = 1;
                                        }
                                        else if(family.t_rela == "Mother")
                                        {
                                            relation = 2;
                                        }
                                        else if (family.t_rela == "Husaband")
                                        {
                                            relation = 3;
                                        }
                                        else if (family.t_rela == "Wife")
                                        {
                                            relation = 4;
                                        }
                                        else if (family.t_rela == "Son")
                                        {
                                            relation = 5;
                                        }
                                        else if (family.t_rela == "Daughter")
                                        {
                                            relation = 6;
                                        }
                                        cmd.Parameters.AddWithValue("@t_rela", relation);
                                        cmd.Parameters.AddWithValue("@t_nama", family.t_nama);
                                        cmd.Parameters.AddWithValue("@n_dobt", family.t_dobt);
                                        if (family.t_mmob == null)
                                        {
                                            cmd.Parameters.AddWithValue("@t_mmob", "");
                                        }
                                        else
                                        {
                                            cmd.Parameters.AddWithValue("@t_mmob", family.t_mmob);
                                        }
                                        if(family.t_mema == null)
                                        {
                                            cmd.Parameters.AddWithValue("@t_mema", "");
                                        }
                                        else
                                        {
                                            cmd.Parameters.AddWithValue("@t_mema", family.t_mema);
                                        }

                                        cmd.Parameters.AddWithValue("@Action", 'F');
                                        cmd.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                                        cmd.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                                        con1.Open();
                                        i = cmd.ExecuteNonQuery();
                                        con1.Close();
                                        msg2 = (string)comm.Parameters["@ERROR"].Value.ToString();
                                        response2 = msg2;
                                        //cmd.Connection = con;
                                        //con.Open();
                                        //cmd.ExecuteNonQuery();
                                        //con.Close();
                                    }
                                }
                            }
                        }
                        //Start Education
                        if (educations != null)
                        {
                            foreach (Education education in educations)
                            {
                                int coursetype = 0;
                                string msg3 = string.Empty;
                                using (SqlConnection con2 = new SqlConnection(cs1))
                                {
                                    using (SqlCommand cmd1 = new SqlCommand("testdb..[SWAddEmployeeDetails]", con2))
                                    {
                                        cmd1.CommandType = CommandType.StoredProcedure;
                                        cmd1.Parameters.AddWithValue("@t_emno", education.t_emno);
                                        cmd1.Parameters.AddWithValue("@t_educ", education.t_educ);
                                        cmd1.Parameters.AddWithValue("@t_poyr", education.t_poyr);
                                        //cmd1.Parameters.AddWithValue("@t_grad", "");
                                        if (education.t_boar == null)
                                        {
                                            cmd1.Parameters.AddWithValue("@t_boar", education.t_univ);
                                        }
                                        else
                                        {
                                            cmd1.Parameters.AddWithValue("@t_boar", education.t_boar);
                                        }
                                        if (education.t_coty == "Part Time")
                                        {
                                            coursetype = 1;
                                        }
                                        else if (education.t_coty == "Full Time")
                                        {
                                            coursetype = 2;
                                        }
                                        else if (education.t_coty == "Correspondence")
                                        {
                                            coursetype = 3;
                                        }
                                        else if (education.t_coty == "Distance Learning")
                                        {
                                            coursetype = 4;
                                        }
                                        cmd1.Parameters.AddWithValue("@t_coty", coursetype);
                                        cmd1.Parameters.AddWithValue("@Action", "E");
                                        cmd1.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                                        cmd1.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                                        con2.Open();
                                        i = cmd1.ExecuteNonQuery();
                                        con2.Close();
                                        msg3 = (string)comm.Parameters["@ERROR"].Value.ToString();
                                        response3 = msg3;
                                      
                                    }
                                }
                            }
                        }
                        //End
                    }
                    return response;
                }
            }

            catch (Exception ex)
            {
                ex.ToString();
                message = (ex.ToString());
                response = message;
                return response;

            }
        }
        public List<Employee> BindEmployee()
        {
            try
            {
                string response = string.Empty;
                //HttpContext.Current.Session["t_emno1"] = t_emno;
                List<Employee> Emplst = new List<Employee>();
                string cs1 = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
                using (SqlConnection con = new SqlConnection(cs1))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb.dbo.[SWAddEmployeeDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "S");
                    //comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Emplst.Add(new Employee
                        {

                            t_emno = rdr["t_emno"].ToString(),
                            t_fir_n = rdr["t_fir_n"].ToString(),
                            t_midn = rdr["t_midn"].ToString(),
                            t_lasn = rdr["t_lasn"].ToString(),
                            t_motn = rdr["t_motn"].ToString(),
                            //t_nama = rdr["t_nama"].ToString(),
                            t_gend = Convert.ToInt32(rdr["t_gend"].ToString()),
                            t_dobt = rdr["t_dobt"].ToString(),
                            t_plob = rdr["t_plob"].ToString(),
                            t_nati = rdr["t_nati"].ToString(),
                            t_matr = Convert.ToInt32(rdr["t_matr"].ToString()),
                            t_datm = rdr["t_datm"].ToString(),
                            t_phon = rdr["t_phon"].ToString(),
                            t_emai = rdr["t_emai"].ToString(),
                            t_reli = rdr["t_reli"].ToString(),
                            t_motl = rdr["t_motl"].ToString(),
                            t_high = rdr["t_high"].ToString(),
                            t_dojd = rdr["t_dojd"].ToString(),
                            t_empt = rdr["t_empt"].ToString(),
                            t_cste = rdr["t_cste"].ToString(),
                            t_stat = rdr["t_stat"].ToString(),
                            t_esic = rdr["t_esic"].ToString(),
                            t_bano = rdr["t_bano"].ToString(),
                            t_bank = rdr["t_bank"].ToString(),
                            t_uanc = rdr["t_uanc"].ToString(),
                            t_adhe = rdr["t_adhe"].ToString(),
                            t_panu = rdr["t_panu"].ToString(),
                            t_week = rdr["t_week"].ToString(),
                            t_shif = rdr["t_shif"].ToString(),
                            t_punc = rdr["t_punc"].ToString(),
                            t_padr = rdr["t_padr"].ToString(),
                            t_cadr = rdr["t_cadr"].ToString(),
                            t_laem = rdr["t_laem"].ToString(),
                            t_atos = rdr["t_atos"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_puni = rdr["t_puni"].ToString(),
                            t_cstedesc = rdr["t_cstedesc"].ToString()
                          

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                    return Emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Employee> BindEmployeeWise()
        {
            try
            {
                string response = string.Empty;
                //HttpContext.Current.Session["t_emno1"] = t_emno;
                List<Employee> Emplst = new List<Employee>();
                string cs1 = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
                using (SqlConnection con = new SqlConnection(cs1))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb.dbo.[SWAddEmployeeDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SIW");
                    //comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Emplst.Add(new Employee
                        {

                            t_emno = rdr["t_emno"].ToString(),
                            t_fir_n = rdr["t_fir_n"].ToString(),
                            t_midn = rdr["t_midn"].ToString(),
                            t_lasn = rdr["t_lasn"].ToString(),
                            t_motn = rdr["t_motn"].ToString(),
                            //t_nama = rdr["t_nama"].ToString(),
                            t_gend = Convert.ToInt32(rdr["t_gend"].ToString()),
                            t_dobt = rdr["t_dobt"].ToString(),
                            t_plob = rdr["t_plob"].ToString(),
                            t_nati = rdr["t_nati"].ToString(),
                            t_phon = rdr["t_phon"].ToString(),
                           
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                    return Emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<Employee> GetPunchCode(string t_punc)
        {
            
            string response = string.Empty;
            try
            {
                List<Employee> stlst = new List<Employee>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "PUN");
                    comm.Parameters.Add(new SqlParameter("@t_punc", t_punc));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {

                        stlst.Add(new Employee
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_punc = rdr["t_punc"].ToString()
                          

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return stlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Employee> GetEmployeeCode(string t_emno)
        {

            string response = string.Empty;
            try
            {
                List<Employee> stlst = new List<Employee>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "EMP");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {

                        stlst.Add(new Employee
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_nama = rdr["t_nama"].ToString()


                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return stlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Bank> GetBank()
        {
            string response = string.Empty;

            try
            {
                List<Bank> stlst = new List<Bank>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "BNK");
                    //comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {

                        stlst.Add(new Bank
                        {
                            t_bano = rdr["t_bano"].ToString(),
                            t_bnam = rdr["t_bnam"].ToString(),
                            t_ifsc = rdr["t_ifsc"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return stlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Bank> GetBankName(string t_bano)
        {
            string response = string.Empty;
            try
            {
                List<Bank> stlst = new List<Bank>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "BNK");
                    comm.Parameters.Add(new SqlParameter("@t_bano", t_bano));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {

                        stlst.Add(new Bank
                        {
                            t_bano = rdr["t_bano"].ToString(),
                            t_bnam = rdr["t_bnam"].ToString(),
                            t_ifsc = rdr["t_ifsc"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return stlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Employee> GetEmpName(string t_emno)
        {
            string response = string.Empty;
            try
            {
                List<Employee> stlst = new List<Employee>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb.dbo.[SWAddEmployeeDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "ENM");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {

                        stlst.Add(new Employee
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_nama = rdr["t_nama"].ToString()
                           

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return stlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Employee> BindEmployeeID(string t_emno)
        {
            try
            {
                string response = string.Empty;
                //HttpContext.Current.Session["t_emno1"] = t_emno;
                List<Employee> Emplst = new List<Employee>();
                string cs1 = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
                using (SqlConnection con = new SqlConnection(cs1))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb.dbo.[SWAddEmployeeDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "S");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Emplst.Add(new Employee
                        {

                            t_emno = rdr["t_emno"].ToString(),
                            t_fir_n = rdr["t_fir_n"].ToString(),
                            t_midn = rdr["t_midn"].ToString(),
                            t_lasn = rdr["t_lasn"].ToString(),
                            t_motn = rdr["t_motn"].ToString(),
                            //t_nama = rdr["t_nama"].ToString(),
                            t_gend = Convert.ToInt32(rdr["t_gend"].ToString()),
                            t_dobt = rdr["t_dobt"].ToString(),
                            t_plob = rdr["t_plob"].ToString(),
                            t_nati = rdr["t_nati"].ToString(),
                            t_matr = Convert.ToInt32(rdr["t_matr"].ToString()),
                            t_datm = rdr["t_datm"].ToString(),
                            t_phon = rdr["t_phon"].ToString(),
                            t_emai = rdr["t_emai"].ToString(),
                            t_reli = rdr["t_reli"].ToString(),
                            t_motl = rdr["t_motl"].ToString(),
                            t_high = rdr["t_high"].ToString(),
                            t_dojd = rdr["t_dojd"].ToString(),
                            t_empt = rdr["t_empt"].ToString(),
                            t_cste = rdr["t_cste"].ToString(),
                            t_stat = rdr["t_stat"].ToString(),
                            t_esic = rdr["t_esic"].ToString(),
                            t_bano = rdr["t_bano"].ToString(),
                            t_bank = rdr["t_bank"].ToString(),
                            t_uanc = rdr["t_uanc"].ToString(),
                            t_adhe = rdr["t_adhe"].ToString(),
                            t_panu = rdr["t_panu"].ToString(),
                            t_week = rdr["t_week"].ToString(),
                            t_shif = rdr["t_shif"].ToString(),
                            t_punc = rdr["t_punc"].ToString(),
                            t_padr = rdr["t_padr"].ToString(),
                            t_cadr = rdr["t_cadr"].ToString(),
                            t_laem = rdr["t_laem"].ToString(),
                            t_atos = rdr["t_atos"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_puni = rdr["t_puni"].ToString(),
                            t_cstedesc = rdr["t_cstedesc"].ToString()


                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                    return Emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
  
}