﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using HumanResourceManagement.Models;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Web.UI;
using System.Text;
using context = System.Web.HttpContext;

using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

using System.Collections;
using System.Globalization;

namespace HumanResourceManagement.Models
{
    public class EmployeeDB
    {
        //string AlertPopupMsg = string.Empty;
        string cs = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
        private string message = string.Empty;

        //public void ErrorReport(string message)
        //{
        //    string path = Path.Combine(Directory.GetCurrentDirectory(), "Errors");
        //    if (!Directory.Exists(path))
        //    {
        //        Directory.CreateDirectory(path);
        //    }

        //    string dt = DateTime.Now.ToShortDateString();
        //    string d = dt.Replace('/', '_');
        //    string filePath = Path.Combine(path, "Error_Log_" + d + ".txt");

        //    string line = DateTime.Now + Environment.NewLine + message + Environment.NewLine + Environment.NewLine;

        //    File.AppendAllText(filePath, line);
        //}

        public string CheckNotExistTabStatus(Employee employee)
        {
            string response = string.Empty;
            //string dobOfFamMem=string.Empty;
            try
            {
                List<Employee> EmpExistlst = new List<Employee>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "CHECKTABSTATUS");
                    comm.Parameters.Add(new SqlParameter("@t_emno", employee.t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    //comm.Parameters.Add(new SqlParameter("@SalOrdNo", SalOrdNo));
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        EmpExistlst.Add(new Employee
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_stat = rdr["t_stat"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
        }

        public string CheckExistTabStatus(Employee employee)
        {
            string response = string.Empty;
            //string dobOfFamMem=string.Empty;
            try
            {
                List<Employee> EmpExistlst = new List<Employee>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "CHECKEXISTSTATUS");
                    comm.Parameters.Add(new SqlParameter("@t_emno", employee.t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    //comm.Parameters.Add(new SqlParameter("@SalOrdNo", SalOrdNo));
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        EmpExistlst.Add(new Employee
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_stat = rdr["t_stat"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
        }

        public string Add(Employee emp)
        {
            int i;
            string response = string.Empty;
            //DateTime dobdatetime;
            //DateTime domdatetime;
            try
            {
                string EmpNo = emp.t_emno;
                if (emp.AlertPopupMsg != null)
                {
                    response = emp.AlertPopupMsg;
                    return response;
                }
                else
                {
                    //DateTime myDateTime = DateTime.Today;
                    //emp.AlertPopupMsg = myDateTime.ToString();
                    //string DOBToday = emp.t_dobt;
                    //DateTime TodayDOB = Convert.ToDateTime(DOBToday);
                    //IFormatProvider cul = new System.Globalization.CultureInfo("IN-us", true);
                    //DateTime dtdob = DateTime.Parse(DOBToday, cul, System.Globalization.DateTimeStyles.AssumeLocal);

                    //DateTime dtdob = DateTime.ParseExact(emp.t_dobt, "dd/MM/yyyy", null);
                    //dtdob = Convert.ToDateTime(dtdob, System.Globalization.CultureInfo.GetCultureInfo("hi-IN").DateTimeFormat);
                    //DateTime TodayDOM = Convert.ToDateTime(DOMToday);
                    //IFormatProvider cul1 = new System.Globalization.CultureInfo("en-us", true);
                    //DateTime dtdom = DateTime.Parse(DOMToday, cul1, System.Globalization.DateTimeStyles.AssumeLocal);

                    //DateTime dtdom = DateTime.ParseExact(emp.t_datm, "dd/MM/yyyy", null);
                    // dtdom = Convert.ToDateTime(dtdom, System.Globalization.CultureInfo.GetCultureInfo("hi-IN").DateTimeFormat);
                    string DOMToday;
                    if (emp.t_datm == null)
                    {
                        DOMToday = "01-01-1900";
                    }
                    else
                    {
                        DOMToday = emp.t_datm;
                    }

                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        con.Open();

                        SqlCommand comm = new SqlCommand("testdb..[SWEmployeeDetails]", con);

                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@t_emno", emp.t_emno);
                        comm.Parameters.AddWithValue("@t_firn", emp.t_firn.ToUpper());
                        comm.Parameters.AddWithValue("@t_midn", emp.t_midn.ToUpper());
                        comm.Parameters.AddWithValue("@t_lasn", emp.t_lasn.ToUpper());
                        comm.Parameters.AddWithValue("@t_motn", emp.t_motn.ToUpper());
                        comm.Parameters.AddWithValue("@t_gend", emp.t_gend);
                        comm.Parameters.AddWithValue("@t_dobt", emp.t_dobt);
                        //dobdatetime = Convert.ToDateTime(emp.t_dobt);
                        //.ToString("MM/dd/yyyy hh:mm:ss tt")
                        //response = dobdatetime.ToString();
                        //comm.Parameters.AddWithValue("@t_dobt", emp.t_dobt);
                        comm.Parameters.AddWithValue("@t_plob", emp.t_plob.ToUpper());
                        comm.Parameters.AddWithValue("@t_culo", emp.t_culo.ToUpper());
                        comm.Parameters.AddWithValue("@t_cadr", emp.t_cadr.ToUpper());
                        comm.Parameters.AddWithValue("@t_coad", emp.t_coad.ToUpper());
                        comm.Parameters.AddWithValue("@t_cste", emp.t_cste);
                        comm.Parameters.AddWithValue("@t_city", emp.t_city.ToUpper());
                        comm.Parameters.AddWithValue("@t_nati", emp.t_nati.ToUpper());
                        //comm.Parameters.AddWithValue("@t_imag", emp.t_imag);
                        //comm.Parameters.AddWithValue("@t_path", emp.t_path);
                        //comm.Parameters.AddWithValue("@t_filn", emp.t_filn);
                        //comm.Parameters.AddWithValue("@t_rpat", emp.t_rpat);
                        //if (emp.t_imag == null)
                        comm.Parameters.AddWithValue("@t_imag", String.IsNullOrEmpty(emp.t_imag) ? "" : (object)emp.t_imag);
                        //comm.Parameters.AddWithValue("@t_imag", emp.t_imag != null ? emp.t_imag : DBNull.Value;

                        comm.Parameters.AddWithValue("@t_path", String.IsNullOrEmpty(emp.t_path) ? "" : (object)emp.t_path);
                        comm.Parameters.AddWithValue("@t_filn", String.IsNullOrEmpty(emp.t_filn) ? "" : (object)emp.t_filn);
                        comm.Parameters.AddWithValue("@t_rpat", String.IsNullOrEmpty(emp.t_rpat) ? "" : (object)emp.t_rpat);

                        comm.Parameters.AddWithValue("@t_matr", emp.t_matr);
                        comm.Parameters.AddWithValue("@t_datm", DOMToday);
                        //domdatetime = Convert.ToDateTime(emp.t_datm);
                        //response = domdatetime.ToString();
                        //String.IsNullOrEmpty(emp.t_datm) ? "" :
                        comm.Parameters.AddWithValue("@t_mobl", emp.t_mobl);
                        comm.Parameters.AddWithValue("@t_emmo", emp.t_emmo);
                        comm.Parameters.AddWithValue("@t_emai", emp.t_emai);
                        //comm.Parameters.AddWithValue("@t_reli", emp.t_reli);
                        comm.Parameters.AddWithValue("@t_reli", String.IsNullOrEmpty(emp.t_reli) ? "" : (object)emp.t_reli.ToUpper());
                        comm.Parameters.AddWithValue("@t_cast", String.IsNullOrEmpty(emp.t_cast) ? "" : (object)emp.t_cast.ToUpper());
                        comm.Parameters.AddWithValue("@t_motl", String.IsNullOrEmpty(emp.t_motl) ? "" : (object)emp.t_motl);
                        comm.Parameters.AddWithValue("@t_etyp", emp.t_etyp);
                        comm.Parameters.AddWithValue("@t_woex", emp.t_woex);
                        comm.Parameters.AddWithValue("@t_esic", String.IsNullOrEmpty(emp.t_esic) ? "" : (object)emp.t_esic);
                        //comm.Parameters.AddWithValue("@t_bank", emp.t_bank);
                        //comm.Parameters.AddWithValue("@t_bano", emp.t_bano);
                        //comm.Parameters.AddWithValue("@t_ifsc", emp.t_ifsc);
                        if (emp.t_bank == null)
                        {
                            comm.Parameters.AddWithValue("@t_bank", "");
                        }
                        else
                        {
                            comm.Parameters.AddWithValue("@t_bank", emp.t_bank);
                        }
                        if (emp.t_bano == null)
                        {
                            comm.Parameters.AddWithValue("@t_bano", "");
                        }
                        else
                        {
                            comm.Parameters.AddWithValue("@t_bano", emp.t_bano);
                        }
                        if (emp.t_ifsc == null)
                        {
                            comm.Parameters.AddWithValue("@t_ifsc", "");
                        }
                        else
                        {
                            comm.Parameters.AddWithValue("@t_ifsc", emp.t_ifsc);
                        }
                        comm.Parameters.AddWithValue("@t_uanc", String.IsNullOrEmpty(emp.t_uanc) ? "" : (object)emp.t_uanc);
                        comm.Parameters.AddWithValue("@Action", "Insert");
                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                        i = comm.ExecuteNonQuery();
                        con.Close();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();

                        response = message;
                        //response = emp.Selected;
                        //response = emp.Enabled;
                        //response = emp.Disabled;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                message = (ex.ToString());
                response = message;
                return response;

            }
            //return response;
            //return i;
        }

        public string UpdateBasicDet(Employee emp)
        {
            string response = string.Empty;
            try
            {
                ////ErrorReport(emp.t_dobt);
                ////ErrorReport(emp.t_datm);
                //DateTime datedob = DateTime.ParseExact(emp.t_dobt, "MM/dd/yyyy", null);
                //DateTime datedom = DateTime.ParseExact(emp.t_datm, "MM/dd/yyyy", null);
                int i;
                string EmpNo = emp.t_emno;
                string DOMToday;
                if (emp.t_datm == null)
                {
                    DOMToday = "01-01-1900";
                }
                else
                {
                    DOMToday = emp.t_datm;
                }
                if (emp.AlertPopupMsg != null)
                {
                    response = emp.AlertPopupMsg;
                    return response;

                }
                else
                {
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        con.Open();
                        SqlCommand comm = new SqlCommand("testdb..[SWEmployeeDetails]", con);
                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@t_emno", emp.t_emno);
                        comm.Parameters.AddWithValue("@t_firn", emp.t_firn);
                        comm.Parameters.AddWithValue("@t_midn", emp.t_midn);
                        comm.Parameters.AddWithValue("@t_lasn", emp.t_lasn);
                        comm.Parameters.AddWithValue("@t_motn", emp.t_motn);
                        comm.Parameters.AddWithValue("@t_gend", emp.t_gend);
                        comm.Parameters.AddWithValue("@t_dobt", emp.t_dobt);
                        comm.Parameters.AddWithValue("@t_plob", emp.t_plob);
                        comm.Parameters.AddWithValue("@t_culo", emp.t_culo);
                        comm.Parameters.AddWithValue("@t_cadr", emp.t_cadr);
                        comm.Parameters.AddWithValue("@t_coad", emp.t_coad);
                        comm.Parameters.AddWithValue("@t_cste", emp.t_cste);
                        comm.Parameters.AddWithValue("@t_city", emp.t_city);
                        comm.Parameters.AddWithValue("@t_nati", emp.t_nati);
                        //comm.Parameters.AddWithValue("@t_imag", emp.t_imag);
                        //comm.Parameters.AddWithValue("@t_path", emp.t_path);
                        //comm.Parameters.AddWithValue("@t_filn", emp.t_filn);
                        //comm.Parameters.AddWithValue("@t_rpat", emp.t_rpat);
                        //if (emp.t_imag == null)
                        comm.Parameters.AddWithValue("@t_imag", String.IsNullOrEmpty(emp.t_imag) ? "" : (object)emp.t_imag);
                        //comm.Parameters.AddWithValue("@t_imag", emp.t_imag != null ? emp.t_imag : DBNull.Value;

                        comm.Parameters.AddWithValue("@t_path", String.IsNullOrEmpty(emp.t_path) ? "" : (object)emp.t_path);
                        comm.Parameters.AddWithValue("@t_filn", String.IsNullOrEmpty(emp.t_filn) ? "" : (object)emp.t_filn);
                        comm.Parameters.AddWithValue("@t_rpat", String.IsNullOrEmpty(emp.t_rpat) ? "" : (object)emp.t_rpat);

                        comm.Parameters.AddWithValue("@t_matr", emp.t_matr);
                        comm.Parameters.AddWithValue("@t_datm", DOMToday);
                        //String.IsNullOrEmpty(emp.t_datm) ? "" : (object)emp.t_datm);
                        //String.IsNullOrEmpty(emp.t_datm) ? "" :
                        comm.Parameters.AddWithValue("@t_mobl", emp.t_mobl);
                        comm.Parameters.AddWithValue("@t_emmo", emp.t_emmo);
                        comm.Parameters.AddWithValue("@t_emai", emp.t_emai);
                        //comm.Parameters.AddWithValue("@t_reli", emp.t_reli);
                        comm.Parameters.AddWithValue("@t_reli", String.IsNullOrEmpty(emp.t_reli) ? "" : (object)emp.t_reli);
                        comm.Parameters.AddWithValue("@t_cast", String.IsNullOrEmpty(emp.t_cast) ? "" : (object)emp.t_cast);
                        comm.Parameters.AddWithValue("@t_motl", String.IsNullOrEmpty(emp.t_motl) ? "" : (object)emp.t_motl);
                        comm.Parameters.AddWithValue("@t_etyp", emp.t_etyp);
                        comm.Parameters.AddWithValue("@t_woex", emp.t_woex);
                        comm.Parameters.AddWithValue("@t_esic", String.IsNullOrEmpty(emp.t_esic) ? "" : (object)emp.t_esic);
                        if(emp.t_bank== null)
                        {
                            comm.Parameters.AddWithValue("@t_bank", "");
                        }
                        else
                        { 
                            comm.Parameters.AddWithValue("@t_bank", emp.t_bank);
                        }
                        if (emp.t_bano == null)
                        {
                            comm.Parameters.AddWithValue("@t_bano", "");
                        }
                        else
                        { 
                            comm.Parameters.AddWithValue("@t_bano", emp.t_bano);
                        }
                        if (emp.t_ifsc == null)
                        {
                            comm.Parameters.AddWithValue("@t_ifsc", "");
                        }
                        else
                        {
                            comm.Parameters.AddWithValue("@t_ifsc", emp.t_ifsc);
                        }
                       
                        comm.Parameters.AddWithValue("@t_uanc", String.IsNullOrEmpty(emp.t_uanc) ? "" : (object)emp.t_uanc);
                        comm.Parameters.AddWithValue("@Action", "UPDATE");
                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                        i = comm.ExecuteNonQuery();
                        con.Close();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();
                        response = message;
                      
                        return response;
                    }

                }

            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return response;
            //return i;
        }


        public string AddFamily(Family family)
        {
            int i;
            string response = string.Empty;
            string EmpNo = family.t_emno;
            string DOBToday;
            if (family.t_dobt == null)
            {
                DOBToday = "01-01-1900";
            }
            else
            {
                DOBToday = family.t_dobt;
            }
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpFamilyDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", family.t_emno);
                    comm.Parameters.AddWithValue("@t_rela", family.t_rela);
                    comm.Parameters.AddWithValue("@t_nama", family.t_nama);
                    comm.Parameters.AddWithValue("@t_dobt", DOBToday);
                    //Convert.ToDateTime(family.t_dobt).ToString());
                    //String.IsNullOrEmpty(family.t_dobt) ? "" : (object)family.t_dobt);
                    comm.Parameters.AddWithValue("@t_mema", String.IsNullOrEmpty(family.t_mema) ? "" : (object)family.t_mema);
                    comm.Parameters.AddWithValue("@t_mmob", String.IsNullOrEmpty(family.t_mmob) ? "" : (object)family.t_mmob);
                    comm.Parameters.AddWithValue("@Action", "Insert");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }

        public string AddFamilyInsertConfirm(string t_emno)
        {
            int i;
            string response = string.Empty;
            //string EmpNo = family.t_emno;
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpFamilyDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", t_emno);
                    comm.Parameters.AddWithValue("@Action", "INSERTCONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }

        public string AddFamilyUpdateConfirm(string t_emno)
        {
            int i;
            string response = string.Empty;
            //string EmpNo = family.t_emno;
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpFamilyDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", t_emno);
                    comm.Parameters.AddWithValue("@Action", "UPDATECONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }

        public string AddEducationInsertConfirm(string t_emno)
        {
            int i;
            string response = string.Empty;
            try
            {
                //string EmpNo = education.t_emno;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpEducationDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", t_emno);
                    comm.Parameters.AddWithValue("@Action", "INSERTCONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }

            //return i;
        }
        public string AddEducationUpdateConfirm(string t_emno)
        {
            int i;
            string response = string.Empty;
            try
            {
                //string EmpNo = education.t_emno;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpEducationDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", t_emno);
                    comm.Parameters.AddWithValue("@Action", "UPDATECONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }

            //return i;
        }

        public string AddDocumentInsertConfirm(string t_emno)
        {
            int i;
            string response = string.Empty;
            try
            {
                //string EmpNo = education.t_emno;

                //string EmpNo = document.t_emno;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpDocumentDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", t_emno);
                    comm.Parameters.AddWithValue("@Action", "INSERTCONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }
        public string AddDocumentUpdateConfirm(string t_emno)
        {
            int i;
            string message1 = string.Empty;
            string response = string.Empty;
            try
            {
                //string EmpNo = document.t_emno;
                //int p;
                using (SqlConnection con1 = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con1.Open();
                    SqlCommand comm1 = new SqlCommand("testdb..[SWEmpDocumentDetails]", con1);

                    comm1.CommandType = CommandType.StoredProcedure;
                    comm1.Parameters.AddWithValue("@t_emno", t_emno);
                    comm1.Parameters.AddWithValue("@Action", "UPDATECONFIRM");
                    comm1.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm1.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm1.ExecuteNonQuery();
                    con1.Close();

                    message1 = (string)comm1.Parameters["@ERROR"].Value.ToString();
                    response = message1;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }

        }

        public string AddCompanyInsertConfirm(string t_emno)
        {
            int i;
            string response = string.Empty;
            try
            {
                //Update status in company
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpCompanyDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", t_emno);
                    comm.Parameters.AddWithValue("@Action", "INSERTCONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    //return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }


            return response;
            //return i;
        }
        public string AddCompanyUpdateConfirm(string t_emno)
        {
            int i;
            string response = string.Empty;
            try
            {
                //Update status in company
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpCompanyDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", t_emno);
                    comm.Parameters.AddWithValue("@Action", "UPDATECONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    //return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //Update status in documnet

            return response;
            //return i;
        }

        public string AddPayslipInsertConfirm(string t_emno)
        {
            int i;
            string response = string.Empty;
            try
            {
                //Update status in company

                //Update status in documnet
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpPaySlipDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", t_emno);
                    comm.Parameters.AddWithValue("@Action", "INSERTCONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }

            return response;
            //return i;
        }
        public string AddPayslipUpdateConfirm(string t_emno)
        {
            int i;
            string response = string.Empty;
            try
            {
                //Update status in company

                //Update status in documnet
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpPaySlipDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", t_emno);
                    comm.Parameters.AddWithValue("@Action", "UPDATECONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //Update status in reference

            return response;
            //return i;
        }

        public string AddReferenceInsertConfirm(string t_emno)
        {
            int i;
            string response = string.Empty;
            try
            {
                //Update status in company

                //Update status in reference
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpReferenceDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", t_emno);
                    comm.Parameters.AddWithValue("@Action", "INSERTCONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    //return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }

            return response;
            //return i;
        }
        public string AddReferenceUpdateConfirm(string t_emno)
        {
            int i;
            string response = string.Empty;
            try
            {
                //Update status in company

                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpReferenceDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", t_emno);
                    comm.Parameters.AddWithValue("@Action", "UPDATECONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    //return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //Update status in Certification

            return response;
            //return i;
        }

        public string AddCertificationInsertConfirm(Certification certification, UserRegistration userRegistration, Employee employee)
        {
            int i;
            string response = string.Empty;
            try
            {
                //Update status in company

                //Update status in Certification
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpCertificationDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", certification.t_emno);
                    comm.Parameters.AddWithValue("@Action", "INSERTCONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    //return response;
                }
                //Update status in Registration form
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWUserRegistration]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", userRegistration.t_emno);
                    comm.Parameters.AddWithValue("@Action", "INSERTCONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    //return response;
                }
                //Send Submitted confirm mail
                string Feedback;
                //string EmailMode = "Admin";
                //string AdminMail1 = "atul.gurnule7@gmail.com";
                //const string SERVER = "relay-hosting.secureserver.net";
                using (SqlConnection con = new SqlConnection(cs))
                {
                    if (employee.t_emai != "")
                    {
                        /////////////////////////
                        using (StringWriter sw = new StringWriter())
                        {
                            using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                            {
                                //////////////////////////////
                                string FullName = string.Join(" ", employee.t_firn, employee.t_midn, employee.t_lasn);
                                StringBuilder sb = new StringBuilder();
                                sb.Append("<html><body>");
                                //sb.Append("<img src='~/HumanResourceManagement/HumanResourceManagement/dist/img/loginlogo.png' alt='Smiley face'  width='35%' height='15%'/>");
                                sb.Append("<h2>SPACEWOOD FURNISHERS PVT LTD.</h2>");
                                sb.Append("<hr size='15' style='background-color:#72AFD1'>");
                                sb.Append("<h4>Hi, " + FullName + "</h4>");
                                sb.Append("<h2>Thank You For Contacting Us</h2>");
                                sb.Append("<p>You have submitted application successfully in spacewood.</p>");

                                sb.Append("</br>");
                                sb.Append("<hr>");
                                sb.Append("<table>");
                                sb.Append("<tr>");
                                sb.Append("<h5>Please note your registered application number for all further communication with Spacewood.</h5>");
                                sb.Append("</tr>");
                                sb.Append("<tr>");
                                sb.Append("<td>Registration No.: <b>" + certification.t_emno + "</b></td>");
                                sb.Append("</tr>");
                                //sb.Append("<tr>");
                                //sb.Append("<td>Password: <b>" + user.t_pass + "</b></td>");
                                //sb.Append("</tr>");
                                sb.Append("</br>");
                                sb.Append("</table>");

                                sb.Append("<hr>");
                                sb.Append("<p>You can contact us at hr@spacewood.in for queries regarding anything about the service.</p>");
                                sb.Append("</hr>");
                                sb.Append("<p><b>Regards,</b></p>");
                                sb.Append("<p><b>Team Spacewood</b></p>");
                                sb.Append("</body></html>");

                                //StringReader sr = new StringReader(sb.ToString());
                                Feedback = sb.ToString();


                                //MailMessage oMail = new MailMessage();

                                //oMail.From = new MailAddress(AdminMail1);
                                //oMail.To.Add(employee.t_emai);

                                //oMail.Subject = "Spacewood | Application Details";
                                //oMail.IsBodyHtml = true; // enumeration
                                //oMail.Priority = MailPriority.High; // enumeration
                                //oMail.Body = Feedback;
                                //SmtpClient smtp = new SmtpClient();
                                ////smtp.Host = "email-smtp.us-east-1.amazonaws.com";smtp.gmail.com
                                //smtp.Host = "smtp.gmail.com";
                                //smtp.EnableSsl = true;
                                //NetworkCredential NetworkCred = new NetworkCredential("atul.gurnule7@gmail.com", "atul$1987");
                                ////smtp.UseDefaulCredentials = true;
                                //smtp.Credentials = NetworkCred;
                                //smtp.Port = 587;
                                ////vbnguwwiuntyorlm
                                //smtp.Send(oMail);

                                con.Open();
                                SqlCommand comm = new SqlCommand("testdb..[SWSendEmailUserRegistratioComplete]", con);

                                comm.CommandType = CommandType.StoredProcedure;
                                comm.Parameters.AddWithValue("@subject", "Spacewood | Application Details");
                                //cmd.Parameters.AddWithValue("@profile", "SpacewoodMail");
                                comm.Parameters.AddWithValue("@profile", "SpacewoodHRMailProfile"); 
                                //comm.Parameters.AddWithValue("@profile", "scp_mail");
                                comm.Parameters.AddWithValue("@to", employee.t_emai);
                                comm.Parameters.AddWithValue("@cc", "pers@spacewood.in");
                                comm.Parameters.AddWithValue("@bcc", "");
                                comm.Parameters.AddWithValue("@mbody", Feedback);
                                i = comm.ExecuteNonQuery();
                                con.Close();

                            }

                        }
                    }
                }

                return response;
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }
        
        public string AddCertificationUpdateConfirm(Certification certification, UserRegistration userRegistration, Employee employee)
        {
            int i;
            string response = string.Empty;
            try
            {
                //Update status in company

                //Update status in Certification
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpCertificationDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", certification.t_emno);
                    comm.Parameters.AddWithValue("@Action", "UPDATECONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    //return response;
                }
                //Update status in Registration form
                using (SqlConnection con = new SqlConnection(cs))
                {
                    //DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                    //string dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWUserRegistration]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", userRegistration.t_emno);
                    comm.Parameters.AddWithValue("@Action", "UPDATECONFIRM");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    //return response;
                }

                using (SqlConnection con = new SqlConnection(cs))
                {
                    //Send Submitted confirm mail
                    string Feedback;
                    //string EmailMode = "Admin";
                    //string AdminMail1 = "pers@spacewood.in";
                    //const string SERVER = "relay-hosting.secureserver.net";
                    if (employee.t_emai != "")
                    {
                        /////////////////////////
                        using (StringWriter sw = new StringWriter())
                        {
                            using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                            {
                                //////////////////////////////
                                string FullName = string.Join(" ", employee.t_firn, employee.t_midn, employee.t_lasn);
                                StringBuilder sb = new StringBuilder();
                                sb.Append("<html><body>");
                                //sb.Append("<img class='animation__wobble' src='../UploadFiles/loginlogo.png' alt='Logo' height='60' width='60'>");
                                //sb.Append("<div class='preloader flex-column justify-content-center align-items-center'><img class='animation__wobble' src='UploadFiles/loginlogo.png' alt='Logo' height='60' width='60'></div>");
                                sb.Append("<h2>SPACEWOOD FURNISHERS PVT LTD.</h2>");
                                sb.Append("<hr size='15' style='background-color:#72AFD1'>");
                                sb.Append("<h4>Hi, " + FullName + "</h4>");
                                sb.Append("<h2>Thank You For Contacting Us</h2>");
                                sb.Append("<p>You have submitted application form successfully in spacewood.</p>");

                                sb.Append("</br>");
                                sb.Append("<hr>");
                                sb.Append("<table>");
                                sb.Append("<tr>");
                                sb.Append("<h5>Please note your registration no for all further communication with Spacewood.</h5>");
                                sb.Append("</tr>");
                                sb.Append("<tr>");
                                sb.Append("<td>Registration No.: <b>" + certification.t_emno + "</b></td>");
                                sb.Append("</tr>");
                                //sb.Append("<tr>");
                                //sb.Append("<td>Password: <b>" + user.t_pass + "</b></td>");
                                //sb.Append("</tr>");
                                sb.Append("</br>");
                                sb.Append("</table>");

                                sb.Append("<hr>");
                                sb.Append("<p>You can contact us at hr@spacewood.in for queries regarding anything about the service.</p>");
                                sb.Append("</hr>");
                                sb.Append("<p><b>Regards,</b></p>");
                                sb.Append("<p><b>Team Spacewood</b></p>");
                                sb.Append("</body></html>");

                                //StringReader sr = new StringReader(sb.ToString());
                                Feedback = sb.ToString();


                                //MailMessage oMail = new MailMessage();

                                //oMail.From = new MailAddress(AdminMail1);
                                //oMail.To.Add(employee.t_emai);

                                //oMail.Subject = "Spacewood | Application Details";
                                //oMail.IsBodyHtml = true; // enumeration
                                //oMail.Priority = MailPriority.High; // enumeration
                                //oMail.Body = Feedback;
                                //SmtpClient smtp = new SmtpClient();
                                ////smtp.Host = "email-smtp.us-east-1.amazonaws.com";smtp.gmail.com
                                //smtp.Host = "smtp.gmail.com";
                                //smtp.EnableSsl = true;
                                ////NetworkCredential NetworkCred = new NetworkCredential("atul.gurnule7@gmail.com", "atul$1987");
                                //NetworkCredential NetworkCred = new NetworkCredential("pers@spacewood.in", "");
                                //smtp.UseDefaultCredentials = true;
                                //smtp.Credentials = NetworkCred;
                                //smtp.Port = 587;
                                ////vbnguwwiuntyorlm
                                //smtp.Send(oMail);

                                con.Open();
                                SqlCommand comm = new SqlCommand("testdb..[SWSendEmailUserRegistratioComplete]", con);

                                comm.CommandType = CommandType.StoredProcedure;
                                comm.Parameters.AddWithValue("@subject", "Spacewood | Application Details");
                                //cmd.Parameters.AddWithValue("@profile", "SpacewoodMail");
                                comm.Parameters.AddWithValue("@profile", "SpacewoodHRMailProfile");
                                //comm.Parameters.AddWithValue("@profile", "scp_mail");
                                comm.Parameters.AddWithValue("@to", employee.t_emai);
                                comm.Parameters.AddWithValue("@cc", "pers@spacewood.in");
                                comm.Parameters.AddWithValue("@bcc", "");
                                comm.Parameters.AddWithValue("@mbody", Feedback);
                                i = comm.ExecuteNonQuery();
                                con.Close();
                                //message = (string)comm.Parameters["@ERROR"].Value.ToString();
                                //response = message;
                            }
                        }
                    }

                    //return response;
                }

                return response;
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }
        
        public string AddEducation(Education education)
        {
            int i;
            string response = string.Empty;
            string EmpNo = education.t_emno;
            try
            {
                if (education.AlertPopupMsg != null)
                {
                    response = education.AlertPopupMsg;
                    return response;
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        if (education.t_boar == "(--All India--)" || education.t_boar == "(--State Board--)")
                        {
                            education.t_boar = "";
                        }
                        if (education.t_scmd == "--Select--")
                        {
                            education.t_scmd = "";
                        }
                        if (education.t_coty == "--Select--")
                        {
                            education.t_coty = "";
                        }
                        con.Open();

                        SqlCommand comm = new SqlCommand("testdb..[SWEmpEducationDetails]", con);

                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@t_emno", education.t_emno);
                        comm.Parameters.AddWithValue("@t_educ", education.t_educ);
                        comm.Parameters.AddWithValue("@t_boar", String.IsNullOrEmpty(education.t_boar) ? "" : (object)education.t_boar);
                        comm.Parameters.AddWithValue("@t_poyr", education.t_poyr);
                        comm.Parameters.AddWithValue("@t_scmd", String.IsNullOrEmpty(education.t_scmd) ? "" : (object)education.t_scmd);
                        comm.Parameters.AddWithValue("@t_crse", String.IsNullOrEmpty(education.t_crse) ? "" : (object)education.t_crse);
                        comm.Parameters.AddWithValue("@t_spec", String.IsNullOrEmpty(education.t_spec) ? "" : (object)education.t_spec);
                        comm.Parameters.AddWithValue("@t_univ", String.IsNullOrEmpty(education.t_univ) ? "" : (object)education.t_univ);
                        comm.Parameters.AddWithValue("@t_coty", String.IsNullOrEmpty(education.t_coty) ? "" : (object)education.t_coty);
                        comm.Parameters.AddWithValue("@t_totm", String.IsNullOrEmpty(education.t_totm) ? "" : (object)education.t_totm);
                        comm.Parameters.AddWithValue("@t_cena", education.t_cena);
                        comm.Parameters.AddWithValue("@t_ecpa", education.t_ecpa);

                        comm.Parameters.AddWithValue("@Action", "Insert");
                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                        i = comm.ExecuteNonQuery();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();
                        con.Close();

                        response = message;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }

        public string AddDocument(Document document)
        {
            int i;
            string response = string.Empty;
            string EmpNo = document.t_emno;
            try
            {
                if (document.AlertPopupMsg != null)
                {
                    response = document.AlertPopupMsg;
                    return response;
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        con.Open();

                        SqlCommand comm = new SqlCommand("testdb..[SWEmpDocumentDetails]", con);

                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@t_emno", document.t_emno);
                        comm.Parameters.AddWithValue("@t_docm", document.t_docm);
                        comm.Parameters.AddWithValue("@t_dpat", document.t_dpat);
                        comm.Parameters.AddWithValue("@t_dtyp", document.t_dtyp);
                        comm.Parameters.AddWithValue("@t_imag", document.t_imag);


                        comm.Parameters.AddWithValue("@Action", "Insert");
                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                        i = comm.ExecuteNonQuery();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();
                        con.Close();

                        response = message;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }

        public string AddCompany(Company company)
        {
            int i;
            string response = string.Empty;
            string EmpNo = company.t_emno;
            try
            {
                if (company.AlertPopupMsg != null)
                {
                    response = company.AlertPopupMsg;
                    return response;
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        con.Open();

                        SqlCommand comm = new SqlCommand("testdb..[SWEmpCompanyDetails]", con);

                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@t_emno", company.t_emno.Trim());
                        comm.Parameters.AddWithValue("@t_orga", company.t_orga.Trim());
                        comm.Parameters.AddWithValue("@t_dnam", company.t_dnam.Trim());
                        comm.Parameters.AddWithValue("@t_expe", company.t_expe.Trim());
                        comm.Parameters.AddWithValue("@t_cuco", company.t_cuco.Trim());
                        comm.Parameters.AddWithValue("@t_year", company.t_year.Trim());
                        comm.Parameters.AddWithValue("@t_mont", company.t_mont.Trim());
                        comm.Parameters.AddWithValue("@t_toyr", company.t_toyr.Trim());
                        comm.Parameters.AddWithValue("@t_tomo", company.t_tomo.Trim());
                        comm.Parameters.AddWithValue("@t_dyjp", company.t_dyjp.Trim());
                        comm.Parameters.AddWithValue("@t_cena", company.t_cena.Trim());
                        comm.Parameters.AddWithValue("@t_epat", company.t_epat.Trim());
                        comm.Parameters.AddWithValue("@Action", "INSERT");
                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                        i = comm.ExecuteNonQuery();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();
                        con.Close();

                        response = message;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }
        public string AddPayslip(Payslip payslip)
        {
            int i;
            string response = string.Empty;
            string EmpNo = payslip.t_emno;
            try
            {
                if (payslip.AlertPopupMsg != null)
                {
                    response = payslip.AlertPopupMsg;
                    return response;
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        con.Open();

                        SqlCommand comm = new SqlCommand("testdb..[SWEmpPaySlipDetails]", con);

                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@t_emno", payslip.t_emno);
                        comm.Parameters.AddWithValue("@t_paym", payslip.t_paym);
                        comm.Parameters.AddWithValue("@t_payy", payslip.t_payy);
                        comm.Parameters.AddWithValue("@t_psna", payslip.t_psna);
                        comm.Parameters.AddWithValue("@t_ppat", payslip.t_ppat);

                        comm.Parameters.AddWithValue("@Action", "Insert");
                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                        i = comm.ExecuteNonQuery();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();
                        con.Close();

                        response = message;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }

        public string AddReference(Reference reference)
        {
            int i;
            string response = string.Empty;
            string EmpNo = reference.t_emno;
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpReferenceDetails]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@t_emno", reference.t_emno);
                    comm.Parameters.AddWithValue("@t_rnam", reference.t_rnam);
                    comm.Parameters.AddWithValue("@t_phon", reference.t_phon);
                    comm.Parameters.AddWithValue("@Action", "Insert");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    con.Close();

                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }

        public string AddCertification(Certification certification)
        {
            int i;
            string response = string.Empty;
            string EmpNo = certification.t_emno;
            try
            {
                if (certification.AlertPopupMsg != null)
                {
                    response = certification.AlertPopupMsg;
                    return response;
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        con.Open();

                        SqlCommand comm = new SqlCommand("testdb..[SWEmpCertificationDetails]", con);

                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@t_emno", certification.t_emno);
                        comm.Parameters.AddWithValue("@t_cnam", certification.t_cnam);
                        comm.Parameters.AddWithValue("@t_cema", certification.t_cema);
                        comm.Parameters.AddWithValue("@t_cena", certification.t_cena);
                        comm.Parameters.AddWithValue("@t_cpat", certification.t_cpat);
                        comm.Parameters.AddWithValue("@Action", "Insert");
                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                        i = comm.ExecuteNonQuery();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();
                        con.Close();

                        response = message;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
            //return i;
        }

        public List<Employee> GetBasicDetails(string t_emno)
        {
            try
            {
                string response = string.Empty;

                List<Employee> Emplst = new List<Employee>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECTID");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Emplst.Add(new Employee
                        {

                            t_emno = rdr["t_emno"].ToString(),
                            t_firn = rdr["t_firn"].ToString(),
                            t_midn = rdr["t_midn"].ToString(),
                            t_lasn = rdr["t_lasn"].ToString(),
                            t_motn = rdr["t_motn"].ToString(),
                            t_gend = Convert.ToInt32(rdr["t_gend"].ToString()),
                            //t_dobt = Convert.ToDateTime(rdr["t_dobt"]),
                            t_dobt = rdr["t_dobt"].ToString(),
                            t_plob = rdr["t_plob"].ToString(),
                            t_culo = rdr["t_culo"].ToString(),
                            t_cadr = rdr["t_cadr"].ToString(),
                            t_coad = rdr["t_coad"].ToString(),
                            t_cste = rdr["t_cste"].ToString(),
                            t_city = rdr["t_city"].ToString(),
                            t_nati = rdr["t_nati"].ToString(),
                            t_imag = rdr["t_imag"].ToString(),
                            t_path = rdr["t_path"].ToString(),
                            t_filn = rdr["t_filn"].ToString(),
                            t_rpat = rdr["t_rpat"].ToString(),
                            t_matr = Convert.ToInt32(rdr["t_matr"].ToString()),
                            //t_datm = Convert.ToDateTime(rdr["t_datm"]),
                            t_datm = rdr["t_datm"].ToString(),
                            t_mobl = rdr["t_mobl"].ToString(),
                            t_emmo = rdr["t_emmo"].ToString(),
                            t_emai = rdr["t_emai"].ToString(),
                            t_reli = rdr["t_reli"].ToString(),
                            t_cast = rdr["t_cast"].ToString(),
                            t_motl = rdr["t_motl"].ToString(),
                            t_etyp = rdr["t_etyp"].ToString(),
                            t_esic = rdr["t_esic"].ToString(),
                            t_bano = rdr["t_bano"].ToString(),
                            t_bank = rdr["t_bank"].ToString(),
                            t_ifsc = rdr["t_ifsc"].ToString(),
                            t_woex = rdr["t_woex"].ToString(),
                            t_uanc = rdr["t_uanc"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                    return Emplst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Family> GetFamilyDetail(string t_emno, string t_pono)
        {
            try
            {
                string response = string.Empty;
                List<Family> Familylst = new List<Family>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpFamilyDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECTID");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add(new SqlParameter("@t_pono", t_pono));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime TodayDate = Convert.ToDateTime(rdr["t_dobt"]);
                        //string dateofbirth = TodayDate.ToString("dd-MM-yyyy");

                        Familylst.Add(new Family
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_rela = rdr["t_rela"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_dobt = rdr["t_dobt"].ToString(),
                            t_mema = rdr["t_mema"].ToString(),
                            t_mmob = rdr["t_mmob"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                    return Familylst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Education> GetEducationDetail(string t_emno, string t_pono)
        {
            try
            {
                string response = string.Empty;
                List<Education> Edulst = new List<Education>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpEducationDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECTID");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add(new SqlParameter("@t_pono", t_pono));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Edulst.Add(new Education
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_educ = rdr["t_educ"].ToString(),
                            t_boar = rdr["t_boar"].ToString(),
                            t_poyr = Convert.ToInt32(rdr["t_poyr"].ToString()),
                            t_scmd = rdr["t_scmd"].ToString(),
                            t_crse = rdr["t_crse"].ToString(),
                            t_spec = rdr["t_spec"].ToString(),
                            t_univ = rdr["t_univ"].ToString(),
                            t_coty = rdr["t_coty"].ToString(),
                            t_totm = rdr["t_totm"].ToString(),
                            t_cena = rdr["t_cena"].ToString(),
                            t_ecpa = rdr["t_ecpa"].ToString()

                        });
                    }

                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                    return Edulst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Document> GetDocumentDetail(string t_emno, string t_pono)
        {
            try
            {
                string response = string.Empty;
                List<Document> Doclst = new List<Document>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpDocumentDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECTID");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add(new SqlParameter("@t_pono", t_pono));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Doclst.Add(new Document
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_dtyp = rdr["t_dtyp"].ToString(),
                            t_docm = rdr["t_docm"].ToString(),
                            t_imag = rdr["t_imag"].ToString(),
                            t_dpat = rdr["t_dpat"].ToString()


                        });
                    }

                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                    return Doclst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Company> GetCompanyDetail(string t_emno, string t_pono)
        {
            try
            {
                string response = string.Empty;
                List<Company> Comlst = new List<Company>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpCompanyDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECTID");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add(new SqlParameter("@t_pono", t_pono));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Comlst.Add(new Company
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_orga = rdr["t_orga"].ToString(),
                            t_dnam = rdr["t_dnam"].ToString(),
                            t_expe = rdr["t_expe"].ToString(),
                            t_cuco = rdr["t_cuco"].ToString(),
                            t_year = rdr["t_year"].ToString(),
                            t_mont = rdr["t_mont"].ToString(),
                            t_toyr = rdr["t_toyr"].ToString(),
                            t_tomo = rdr["t_tomo"].ToString(),
                            t_dyjp = rdr["t_dyjp"].ToString(),
                            t_cena = rdr["t_cena"].ToString(),
                            t_epat = rdr["t_epat"].ToString()
                        });
                    }

                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;

                    return Comlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Payslip> GetPayslipDetail(string t_emno, string t_pono)
        {
            try
            {
                string response = string.Empty;
                List<Payslip> Paylst = new List<Payslip>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpPaySlipDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECTID");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add(new SqlParameter("@t_pono", t_pono));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Paylst.Add(new Payslip
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_paym = rdr["t_paym"].ToString(),
                            t_payy = rdr["t_payy"].ToString(),
                            t_psna = rdr["t_psna"].ToString(),
                            t_ppat = rdr["t_ppat"].ToString(),

                        });
                    }

                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Paylst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Reference> GetReferenceDetail(string t_emno, string t_pono)
        {
            try
            {
                string response = string.Empty;
                List<Reference> Reflst = new List<Reference>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpReferenceDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECTID");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add(new SqlParameter("@t_pono", t_pono));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Reflst.Add(new Reference
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_rnam = rdr["t_rnam"].ToString(),
                            t_phon = rdr["t_phon"].ToString()


                        });
                    }

                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Reflst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Certification> GetCertificationDetail(string t_emno, string t_pono)
        {
            try
            {
                string response = string.Empty;
                List<Certification> Cerlst = new List<Certification>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpCertificationDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECTID");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add(new SqlParameter("@t_pono", t_pono));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        Cerlst.Add(new Certification
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_cnam = rdr["t_cnam"].ToString(),
                            t_cema = rdr["t_cema"].ToString(),
                            t_cena = rdr["t_cena"].ToString(),
                            t_cpat = rdr["t_cpat"].ToString()

                        });
                    }

                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Cerlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Family> BindFamilyDet(string t_emno)
        {
            string response = string.Empty;
            //string dobOfFamMem=string.Empty;
            try
            {
                List<Family> Famlst = new List<Family>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpFamilyDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    //comm.Parameters.Add(new SqlParameter("@SalOrdNo", SalOrdNo));
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime TodayDate = Convert.ToDateTime(rdr["t_dobt"]);
                        //string dateofbirth = TodayDate.ToString("dd-MM-yyyy");
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Famlst.Add(new Family
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_rela = rdr["t_rela"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            //t_dobt = Convert.ToDateTime(MemberDOB),
                            t_dobt = rdr["t_dobt"].ToString(),
                            t_mema = rdr["t_mema"].ToString(),
                            t_mmob = rdr["t_mmob"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Famlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Education> BindEducationDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Education> Edulst = new List<Education>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpEducationDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    //comm.Parameters.Add(new SqlParameter("@SalOrdNo", SalOrdNo));
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Edulst.Add(new Education
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_educ = rdr["t_educ"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_boar = rdr["t_boar"].ToString(),
                            t_poyr = Convert.ToInt32(rdr["t_poyr"].ToString()),
                            t_scmd = rdr["t_scmd"].ToString(),
                            t_crse = rdr["t_crse"].ToString(),
                            t_spec = rdr["t_spec"].ToString(),
                            t_univ = rdr["t_univ"].ToString(),
                            t_coty = rdr["t_coty"].ToString(),
                            t_totm = rdr["t_totm"].ToString(),
                            t_ecpa = rdr["t_ecpa"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Edulst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Document> BindDocumenmtDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Document> Doclst = new List<Document>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpDocumentDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    //comm.Parameters.Add(new SqlParameter("@SalOrdNo", SalOrdNo));
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Doclst.Add(new Document
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_dtyp = rdr["t_dtyp"].ToString(),
                            t_docm = rdr["t_docm"].ToString(),
                            t_dpat = rdr["t_dpat"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Doclst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Company> BindCompanyDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Company> Comlst = new List<Company>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpCompanyDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Comlst.Add(new Company
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_dnam = rdr["t_dnam"].ToString(),
                            t_orga = rdr["t_orga"].ToString(),
                            t_expe = rdr["t_expe"].ToString(),
                            t_cuco = rdr["t_cuco"].ToString(),
                            t_year = rdr["t_year"].ToString(),
                            t_mont = rdr["t_mont"].ToString(),
                            t_toyr = rdr["t_toyr"].ToString(),
                            t_tomo = rdr["t_tomo"].ToString(),
                            t_dyjp = rdr["t_dyjp"].ToString(),
                            t_cena = rdr["t_cena"].ToString(),
                            t_epat = rdr["t_epat"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Comlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Payslip> BindPayslipDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Payslip> Paylst = new List<Payslip>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpPaySlipDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Paylst.Add(new Payslip
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_paym = rdr["t_paym"].ToString(),
                            t_payy = rdr["t_payy"].ToString(),
                            t_psna = rdr["t_psna"].ToString(),
                            t_ppat = rdr["t_ppat"].ToString(),
                            t_stat = rdr["t_stat"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Paylst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Reference> BindReferenceDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Reference> Reflst = new List<Reference>();
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpReferenceDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        //DateTime dobOfFamMem = Convert.ToDateTime(rdr["t_dobt"].ToString());
                        //string MemberDOB = dobOfFamMem.ToString("dd-MM-yyyy");
                        Reflst.Add(new Reference
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_rnam = rdr["t_rnam"].ToString(),
                            t_phon = rdr["t_phon"].ToString(),
                            t_stat = rdr["t_stat"].ToString()


                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Reflst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Certification> BindCertificationDet(string t_emno)
        {
            string response = string.Empty;

            try
            {
                List<Certification> Cerlst = new List<Certification>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmpCertificationDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECT");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {

                        Cerlst.Add(new Certification
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_pono = Convert.ToInt32(rdr["t_pono"].ToString()),
                            t_cnam = rdr["t_cnam"].ToString(),
                            t_cema = rdr["t_cema"].ToString(),
                            t_cena = rdr["t_cena"].ToString(),
                            t_cpat = rdr["t_cpat"].ToString(),
                            t_stat = rdr["t_stat"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return Cerlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public string UpdateFamily(Family family)
        {
            string response = string.Empty;
            int i;
            try
            {
                //string dateofbirth = string.Empty;
                //if (family.t_dobt == null)
                //{
                //    dateofbirth = "";
                //}
                //else
                //{
                //    DateTime TodayDate = Convert.ToDateTime(family.t_dobt);
                //    dateofbirth = TodayDate.ToString("yyyy-MM-dd");
                //}
                //var ItemId = prd.t_item;
                string DOBToday;
                if (family.t_dobt == null)
                {
                    DOBToday = "01-01-1900";
                }
                else
                {
                    DOBToday = family.t_dobt;
                }

                using (SqlConnection con = new SqlConnection(cs))
                {
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpFamilyDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "UPDATE");
                    comm.Parameters.AddWithValue("@t_emno", family.t_emno);
                    comm.Parameters.AddWithValue("@t_pono", family.t_pono);
                    comm.Parameters.AddWithValue("@t_rela", family.t_rela);
                    comm.Parameters.AddWithValue("@t_nama", family.t_nama);
                    comm.Parameters.AddWithValue("@t_dobt", DOBToday);
                    //String.IsNullOrEmpty(family.t_dobt) ? "" : (object)family.t_dobt);
                    comm.Parameters.AddWithValue("@t_mema", String.IsNullOrEmpty(family.t_mema) ? "" : (object)family.t_mema);
                    comm.Parameters.AddWithValue("@t_mmob", String.IsNullOrEmpty(family.t_mmob) ? "" : (object)family.t_mmob);


                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    con.Open();
                    i = comm.ExecuteNonQuery();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    con.Close();

                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
        }

        public string UpdateEducation(Education education)
        {
            string response = string.Empty;
            int i;
            try
            {
                if (education.AlertPopupMsg != null)
                {
                    response = education.AlertPopupMsg;
                    return response;
                }
                else
                {
                    //var ItemId = prd.t_item;
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        SqlCommand comm = new SqlCommand("testdb..[SWEmpEducationDetails]", con);
                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@Action", "UPDATE");
                        comm.Parameters.AddWithValue("@t_emno", education.t_emno);
                        comm.Parameters.AddWithValue("@t_pono", education.t_pono);

                        comm.Parameters.AddWithValue("@t_educ", education.t_educ);
                        //comm.Parameters.AddWithValue("@t_boar", education.t_boar);
                        comm.Parameters.AddWithValue("@t_boar", String.IsNullOrEmpty(education.t_boar) ? "" : (object)education.t_boar);
                        comm.Parameters.AddWithValue("@t_poyr", education.t_poyr);
                        //comm.Parameters.AddWithValue("@t_scmd", education.t_scmd);
                        //comm.Parameters.AddWithValue("@t_crse", education.t_crse);
                        //comm.Parameters.AddWithValue("@t_spec", education.t_spec);
                        //comm.Parameters.AddWithValue("@t_univ", education.t_univ);
                        comm.Parameters.AddWithValue("@t_scmd", String.IsNullOrEmpty(education.t_scmd) ? "" : (object)education.t_scmd);
                        comm.Parameters.AddWithValue("@t_crse", String.IsNullOrEmpty(education.t_crse) ? "" : (object)education.t_crse);
                        comm.Parameters.AddWithValue("@t_spec", String.IsNullOrEmpty(education.t_spec) ? "" : (object)education.t_spec);
                        comm.Parameters.AddWithValue("@t_univ", String.IsNullOrEmpty(education.t_univ) ? "" : (object)education.t_univ);

                        comm.Parameters.AddWithValue("@t_coty", String.IsNullOrEmpty(education.t_coty) ? "" : (object)education.t_coty);
                        comm.Parameters.AddWithValue("@t_totm", String.IsNullOrEmpty(education.t_totm) ? "" : (object)education.t_totm);
                        comm.Parameters.AddWithValue("@t_cena", String.IsNullOrEmpty(education.t_cena) ? "" : (object)education.t_cena);
                        comm.Parameters.AddWithValue("@t_ecpa", String.IsNullOrEmpty(education.t_ecpa) ? "" : (object)education.t_ecpa);

                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                        con.Open();
                        i = comm.ExecuteNonQuery();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();
                        con.Close();

                        response = message;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
        }

        public string UpdateDocument(Document document)
        {
            string response = string.Empty;
            int i;
            try
            {
                if (document.AlertPopupMsg != null)
                {
                    response = document.AlertPopupMsg;
                    return response;
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        SqlCommand comm = new SqlCommand("testdb..[SWEmpDocumentDetails]", con);
                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@Action", "UPDATE");
                        comm.Parameters.AddWithValue("@t_emno", document.t_emno);
                        comm.Parameters.AddWithValue("@t_pono", document.t_pono);
                        comm.Parameters.AddWithValue("@t_docm", document.t_docm);
                        comm.Parameters.AddWithValue("@t_dtyp", document.t_dtyp);
                        comm.Parameters.AddWithValue("@t_imag", document.t_imag);
                        comm.Parameters.AddWithValue("@t_dpat", document.t_dpat);

                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                        con.Open();
                        i = comm.ExecuteNonQuery();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();
                        con.Close();

                        response = message;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
        }

        public string UpdateCompany(Company company)
        {
            string response = string.Empty;
            int i;
            try
            {
                if (company.AlertPopupMsg != null)
                {
                    response = company.AlertPopupMsg;
                    return response;
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        SqlCommand comm = new SqlCommand("testdb..[SWEmpCompanyDetails]", con);
                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@Action", "UPDATE");
                        comm.Parameters.AddWithValue("@t_emno", company.t_emno);
                        comm.Parameters.AddWithValue("@t_pono", company.t_pono);
                        comm.Parameters.AddWithValue("@t_orga", company.t_orga);
                        comm.Parameters.AddWithValue("@t_dnam", company.t_dnam);
                        comm.Parameters.AddWithValue("@t_expe", company.t_expe);
                        comm.Parameters.AddWithValue("@t_cuco", company.t_cuco);
                        comm.Parameters.AddWithValue("@t_year", company.t_year);
                        comm.Parameters.AddWithValue("@t_mont", company.t_mont);
                        comm.Parameters.AddWithValue("@t_toyr", company.t_toyr);
                        comm.Parameters.AddWithValue("@t_tomo", company.t_tomo);
                        comm.Parameters.AddWithValue("@t_dyjp", company.t_dyjp);
                        comm.Parameters.AddWithValue("@t_cena", company.t_cena);
                        comm.Parameters.AddWithValue("@t_epat", company.t_epat);

                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                        con.Open();
                        i = comm.ExecuteNonQuery();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();
                        con.Close();

                        response = message;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
        }

        public string UpdatePayslip(Payslip payslip)
        {
            string response = string.Empty;
            try
            {
                int i;
                if (payslip.AlertPopupMsg != null)
                {
                    response = payslip.AlertPopupMsg;
                    return response;
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        SqlCommand comm = new SqlCommand("testdb..[SWEmpPaySlipDetails]", con);
                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@Action", "UPDATE");
                        comm.Parameters.AddWithValue("@t_emno", payslip.t_emno);
                        comm.Parameters.AddWithValue("@t_pono", payslip.t_pono);
                        comm.Parameters.AddWithValue("@t_paym", payslip.t_paym);
                        comm.Parameters.AddWithValue("@t_payy", payslip.t_payy);
                        comm.Parameters.AddWithValue("@t_psna", payslip.t_psna);
                        comm.Parameters.AddWithValue("@t_ppat", payslip.t_ppat);


                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                        con.Open();
                        i = comm.ExecuteNonQuery();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();
                        con.Close();

                        response = message;
                        return response;
                    }
                }

            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
        }

        public string UpdateReference(Reference reference)
        {
            string response = string.Empty;
            int i;
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    SqlCommand comm = new SqlCommand("testdb..[SWEmpReferenceDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "UPDATE");
                    comm.Parameters.AddWithValue("@t_emno", reference.t_emno);
                    comm.Parameters.AddWithValue("@t_pono", reference.t_pono);
                    comm.Parameters.AddWithValue("@t_rnam", reference.t_rnam);
                    comm.Parameters.AddWithValue("@t_phon", reference.t_phon);


                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    con.Open();
                    i = comm.ExecuteNonQuery();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    con.Close();

                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
        }

        public string UpdateCertification(Certification certification)
        {
            string response = string.Empty;
            int i;
            try
            {
                if (certification.AlertPopupMsg != null)
                {
                    response = certification.AlertPopupMsg;
                    return response;
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        SqlCommand comm = new SqlCommand("testdb..[SWEmpCertificationDetails]", con);
                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@Action", "UPDATE");
                        comm.Parameters.AddWithValue("@t_emno", certification.t_emno);
                        comm.Parameters.AddWithValue("@t_pono", certification.t_pono);
                        comm.Parameters.AddWithValue("@t_cnam", certification.t_cnam);
                        comm.Parameters.AddWithValue("@t_cema", certification.t_cema);
                        comm.Parameters.AddWithValue("@t_cena", certification.t_cena);
                        comm.Parameters.AddWithValue("@t_cpat", certification.t_cpat);

                        comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                        comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                        con.Open();
                        i = comm.ExecuteNonQuery();
                        message = (string)comm.Parameters["@ERROR"].Value.ToString();
                        con.Close();

                        response = message;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }
        }

        public string FamDelete(string t_emno, string t_pono)
        {
            string response = string.Empty;
            try
            {
                int i;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand com = new SqlCommand("testdb..[SWEmpFamilyDetails]", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@t_emno", t_emno);
                    com.Parameters.AddWithValue("@t_pono", t_pono);
                    com.Parameters.AddWithValue("@Action", "DELETE");
                    com.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    com.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    i = com.ExecuteNonQuery();
                    message = (string)com.Parameters["@ERROR"].Value.ToString();
                    con.Close();

                    response = message;

                }
                return response;
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return response;
        }

        public string EduDelete(string t_emno, string t_pono)
        {
            string response = string.Empty;
            try
            {
                int i;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand com = new SqlCommand("testdb..[SWEmpEducationDetails]", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@t_emno", t_emno);
                    com.Parameters.AddWithValue("@t_pono", t_pono);
                    com.Parameters.AddWithValue("@Action", "DELETE");
                    com.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    com.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    i = com.ExecuteNonQuery();
                    message = (string)com.Parameters["@ERROR"].Value.ToString();
                    con.Close();

                    response = message;

                }

                return response;
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return response;
        }

        public string DocDelete(string t_emno, string t_pono)
        {
            string response = string.Empty;
            try
            {
                int i;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand com = new SqlCommand("testdb..[SWEmpDocumentDetails]", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@t_emno", t_emno);
                    com.Parameters.AddWithValue("@t_pono", t_pono);
                    com.Parameters.AddWithValue("@Action", "DELETE");
                    com.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    com.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    i = com.ExecuteNonQuery();
                    message = (string)com.Parameters["@ERROR"].Value.ToString();
                    con.Close();

                    response = message;

                }

                return response;
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return response;
        }

        public string ComDelete(string t_emno, string t_pono)
        {
            string response = string.Empty;
            try
            {
                int i;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand com = new SqlCommand("testdb..[SWEmpCompanyDetails]", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@t_emno", t_emno);
                    com.Parameters.AddWithValue("@t_pono", t_pono);
                    com.Parameters.AddWithValue("@Action", "DELETE");
                    com.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    com.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    i = com.ExecuteNonQuery();
                    message = (string)com.Parameters["@ERROR"].Value.ToString();
                    con.Close();

                    response = message;

                }
                return response;
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return response;
        }

        public string PayDelete(string t_emno, string t_pono)
        {
            string response = string.Empty;
            try
            {
                int i;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand com = new SqlCommand("testdb..[SWEmpPaySlipDetails]", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@t_emno", t_emno);
                    com.Parameters.AddWithValue("@t_pono", t_pono);
                    com.Parameters.AddWithValue("@Action", "DELETE");
                    com.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    com.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    i = com.ExecuteNonQuery();
                    message = (string)com.Parameters["@ERROR"].Value.ToString();
                    con.Close();

                    response = message;

                }
                return response;
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return response;
        }

        public string RefDelete(string t_emno, string t_pono)
        {
            string response = string.Empty;
            try
            {
                int i;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand com = new SqlCommand("testdb..[SWEmpReferenceDetails]", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@t_emno", t_emno);
                    com.Parameters.AddWithValue("@t_pono", t_pono);
                    com.Parameters.AddWithValue("@Action", "DELETE");
                    com.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    com.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    i = com.ExecuteNonQuery();
                    message = (string)com.Parameters["@ERROR"].Value.ToString();
                    con.Close();

                    response = message;

                }
                return response;
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return response;
        }

        public string CerDelete(string t_emno, string t_pono)
        {
            string response = string.Empty;
            try
            {

                int i;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand com = new SqlCommand("testdb..[SWEmpCertificationDetails]", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@t_emno", t_emno);
                    com.Parameters.AddWithValue("@t_pono", t_pono);
                    com.Parameters.AddWithValue("@Action", "DELETE");
                    com.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    com.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    i = com.ExecuteNonQuery();
                    message = (string)com.Parameters["@ERROR"].Value.ToString();
                    con.Close();
                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return response;
        }

        public List<StateMaster> GetStateDetails()
        {
            string response = string.Empty;

            try
            {
                List<StateMaster> stlst = new List<StateMaster>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeDetails]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "STATE");
                    //comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {

                        stlst.Add(new StateMaster
                        {
                            t_ccty = rdr["t_ccty"].ToString(),
                            t_cste = rdr["t_cste"].ToString(),
                            t_dsca = rdr["t_dsca"].ToString(),
                            t_tzid = rdr["t_tzid"].ToString(),
                            t_abbr = rdr["t_abbr"].ToString()
                          
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return stlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //public List<StateMaster> GetStateWiseDetails(string t_cste)
        //{
        //    string response = string.Empty;

        //    try
        //    {
        //        List<StateMaster> stlst = new List<StateMaster>();
        //        using (SqlConnection con = new SqlConnection(cs))
        //        {

        //            con.Open();

        //            SqlCommand comm = new SqlCommand("testdb..[SWEmployeeDetails]", con);
        //            comm.CommandType = CommandType.StoredProcedure;
        //            comm.Parameters.AddWithValue("@Action", "STATE");
        //            comm.Parameters.Add(new SqlParameter("@t_cste", t_cste));
        //            comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

        //            comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

        //            SqlDataReader rdr = comm.ExecuteReader();

        //            while (rdr.Read())
        //            {

        //                stlst.Add(new StateMaster
        //                {
        //                    t_ccty = rdr["t_ccty"].ToString(),
        //                    t_cste = rdr["t_cste"].ToString(),
        //                    t_dsca = rdr["t_dsca"].ToString(),
        //                    t_tzid = rdr["t_tzid"].ToString(),
        //                    t_abbr = rdr["t_abbr"].ToString()

        //                });
        //            }
        //            con.Close();
        //            message = (string)comm.Parameters["@ERROR"].Value.ToString();
        //            response = message;
        //            return stlst;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        public List<Bank> GetBank()
        {
            string response = string.Empty;

            try
            {
                List<Bank> stlst = new List<Bank>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "BNK");
                    //comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {

                        stlst.Add(new Bank
                        {
                            t_bano = rdr["t_bano"].ToString(),
                            t_bnam = rdr["t_bnam"].ToString(),
                            t_ifsc = rdr["t_ifsc"].ToString()
                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return stlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Bank> GetBankName(string t_bano)
        {
            string response = string.Empty;
            try
            {
                List<Bank> stlst = new List<Bank>();
                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWEmployeeIntegration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "BNK");
                    comm.Parameters.Add(new SqlParameter("@t_bano", t_bano));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;

                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {

                        stlst.Add(new Bank
                        {
                            t_bano = rdr["t_bano"].ToString(),
                            t_bnam = rdr["t_bnam"].ToString(),
                            t_ifsc = rdr["t_ifsc"].ToString()

                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return stlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}