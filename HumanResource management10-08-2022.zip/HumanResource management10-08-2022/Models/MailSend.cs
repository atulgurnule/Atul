﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class MailSend
    {
        public string subject { get; set; }
        public string profile { get; set; }
        public string to { get; set; }
        public string cc { get; set; }
        public string bcc { get; set; }
        public string mbody { get; set; }
        public string sub { get; set; }

    }
}