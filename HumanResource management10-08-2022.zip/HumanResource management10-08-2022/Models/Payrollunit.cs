﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class Payrollunit
    {
        public string t_puni { get; set; }
        public string t_pnam { get; set; }
    }
}