﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class Payslip
    {
        public string t_emno { get; set; }
        public int t_pono { get; set; }
        public string t_paym { get; set; }
        public string t_payy { get; set; }
        public string t_psna { get; set; }
        public string t_ppat { get; set; }
        public HttpPostedFileBase uploadPayslip { get; set; }
        public string AlertPopupMsg { get; set; }
        public string t_stat { get; set; }

    }
}