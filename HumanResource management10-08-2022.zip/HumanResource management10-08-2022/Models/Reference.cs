﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class Reference
    {
        public string t_emno { get; set; }
        public int t_pono { get; set; }
        public string t_rnam { get; set; }
        public string t_phon { get; set; }
        public string t_stat { get; set; }

    }
}