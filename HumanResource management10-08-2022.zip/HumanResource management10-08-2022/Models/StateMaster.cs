﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class StateMaster
    {
        public string t_ccty { get; set; }
        public string t_cste { get; set; }
        public string t_dsca { get; set; }
        public string t_tzid { get; set; }
        public string t_abbr { get; set; }
       
    }
}