﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class UserData
    {
        [Required(ErrorMessage = "Required.")]
        public string t_mobl { get; set; }
        [Required(ErrorMessage = "Required.")]
        public string t_pass { get; set; }
        public string t_emno { get; set; }
        public string t_nama { get; set; }
        //public bool rememberme { get; set; }
    }
}