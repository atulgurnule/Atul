﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Linq.Dynamic;


namespace HumanResourceManagement.Models
{
    
    public class UserDataDB
    {
        private static int PageSize = 10;
        string cs = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
        private string message = string.Empty;
        public List<UserData> GetLoginDataFromDB(UserData userdb)
        //string userId, string password
        {
            //string Uid, pass;
            try
            {
                //string cs = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
                var userList = new List<UserData>();
              
                
                SqlConnection con = new SqlConnection(cs);
                con.Open();
                SqlCommand cmd = new SqlCommand("testdb..[SWEmployeeLogin]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@t_mobl", userdb.t_mobl));
                cmd.Parameters.Add(new SqlParameter("@t_pass", userdb.t_pass));
                SqlDataReader rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                   
                    userList.Add(new UserData
                    {

                        t_mobl = rdr["t_mobl"].ToString(),
                        t_pass = rdr["t_pass"].ToString(),
                        t_emno= rdr["t_emno"].ToString(),
                        t_nama = rdr["t_nama"].ToString()

                    });
                   
                }
                con.Close();
                if(userList.Count!=0)
                { 
                    HttpContext.Current.Session["empid"] = userList[0].t_emno;
                    HttpContext.Current.Session["userName"] = userList[0].t_nama;
                }
                return userList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string BindPartnerDetails(int pageIndex)
        {
            string response = string.Empty;
            
            try
            {
                List<BusinessPartner> Userlst = new List<BusinessPartner>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWGetBusinessPartner_Pager]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    //comm.Parameters.AddWithValue("@Action", "spGetEmployees");
                    //comm.Parameters.AddWithValue("@DisplayLength", 10);
                    //comm.Parameters.AddWithValue("@DisplayStart", 0);
                    //comm.Parameters.AddWithValue("@SortCol", 0);
                    //comm.Parameters.AddWithValue("@SortDir", "asc");
                    //comm.Parameters.AddWithValue("@SearchTerm", searchTerm);
                    comm.Parameters.AddWithValue("@PageIndex", pageIndex);
                    comm.Parameters.AddWithValue("@PageSize", PageSize);
                    comm.Parameters.Add("@RecordCount", SqlDbType.Int, 4).Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();
                    while (rdr.Read())
                    {

                        Userlst.Add(new BusinessPartner
                        {
                            t_bpid = rdr["t_bpid"].ToString(),
                            t_ctit = rdr["t_ctit"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_seak = rdr["t_seak"].ToString(),
                            t_prbp = rdr["t_prbp"].ToString(),
                            t_prst = rdr["t_prst"].ToString(),
                            t_stdt = rdr["t_stdt"].ToString(),
                            t_endt = rdr["t_endt"].ToString(),
                            t_clan = rdr["t_clan"].ToString(),
                            t_ccur = rdr["t_ccur"].ToString(),
                            t_sndr = rdr["t_sndr"].ToString(),
                            t_edyn = rdr["t_edyn"].ToString(),
                            t_fovn = rdr["t_fovn"].ToString(),
                            t_lvdt = rdr["t_lvdt"].ToString(),
                            t_inrl = rdr["t_inrl"].ToString(),
                            t_iscn = rdr["t_iscn"].ToString(),
                            t_lgid = rdr["t_lgid"].ToString(),
                            t_cmid = rdr["t_cmid"].ToString(),
                            t_bptx = rdr["t_bptx"].ToString(),
                            t_cadr = rdr["t_cadr"].ToString(),
                            t_telp = rdr["t_telp"].ToString(),
                            t_tlcy = rdr["t_tlcy"].ToString(),
                            t_tlci = rdr["t_tlci"].ToString(),
                            t_tlln = rdr["t_tlln"].ToString(),
                            t_tlex = rdr["t_tlex"].ToString(),
                            t_tefx = rdr["t_tefx"].ToString(),
                            t_tfcy = rdr["t_tfcy"].ToString(),
                            t_tfci = rdr["t_tfci"].ToString(),
                            t_tfln = rdr["t_tfln"].ToString(),
                            t_tfex = rdr["t_tfex"].ToString(),
                            t_ccnt = rdr["t_ccnt"].ToString(),
                            t_cint = rdr["t_cint"].ToString(),
                            t_foid = rdr["t_foid"].ToString(),
                            t_crid = rdr["t_crid"].ToString(),
                            t_icst = rdr["t_icst"].ToString(),
                            t_icod = rdr["t_icod"].ToString(),
                            t_fact = rdr["t_fact"].ToString(),
                            t_ecmp = rdr["t_ecmp"].ToString(),
                            t_coff = rdr["t_coff"].ToString(),
                            t_crdt = rdr["t_crdt"].ToString(),
                            t_lmdt = rdr["t_lmdt"].ToString(),
                            t_lmus = rdr["t_lmus"].ToString(),
                            t_bprl = rdr["t_bprl"].ToString(),
                            t_btbv = rdr["t_btbv"].ToString(),
                            t_usid = rdr["t_usid"].ToString(),
                            t_clcd = rdr["t_clcd"].ToString(),
                            t_cbcl = rdr["t_cbcl"].ToString(),
                            t_beid = rdr["t_beid"].ToString(),
                            t_inet = rdr["t_inet"].ToString(),
                            t_imag = rdr["t_imag"].ToString(),
                            t_smt1 = rdr["t_smt1"].ToString(),
                            t_sml1 = rdr["t_sml1"].ToString(),
                            t_smt2 = rdr["t_smt2"].ToString(),
                            t_sml2 = rdr["t_sml2"].ToString(),
                            t_smt3 = rdr["t_smt3"].ToString(),
                            t_sml3 = rdr["t_sml3"].ToString(),
                            t_smt4 = rdr["t_smt4"].ToString(),
                            t_sml4 = rdr["t_sml4"].ToString(),
                            t_smt5 = rdr["t_smt5"].ToString(),
                            t_sml5 = rdr["t_sml5"].ToString(),
                            t_txta = rdr["t_txta"].ToString(),
                        });
                    }
                    con.Close();
                    return GetData(comm, pageIndex).GetXml();
                    //comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    //comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                 
                    //message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    //response = message;
                    //return Userlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static DataSet GetData(SqlCommand comm, int pageIndex)
        {
            string strConnString = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
            using (SqlConnection con = new SqlConnection(strConnString))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    comm.Connection = con;
                    sda.SelectCommand = comm;
                    using (DataSet ds = new DataSet())
                    {
                        sda.Fill(ds, "Customers");
                        DataTable dt = new DataTable("Pager");
                        dt.Columns.Add("PageIndex");
                        dt.Columns.Add("PageSize");
                        dt.Columns.Add("RecordCount");
                        dt.Rows.Add();
                        dt.Rows[0]["PageIndex"] = pageIndex;
                        dt.Rows[0]["PageSize"] = PageSize;
                        dt.Rows[0]["RecordCount"] = comm.Parameters["@RecordCount"].Value;
                        ds.Tables.Add(dt);
                        return ds;
                    }
                }
            }
        }

        public List<BusinessPartner> BindPartner()
        {
            string response = string.Empty;

            try
            {
                List<BusinessPartner> Userlst = new List<BusinessPartner>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWUserRegistration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "SELECTPARTNER");
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    //comm.Parameters.AddWithValue("@DisplayLength", 10);
                    //comm.Parameters.AddWithValue("@DisplayStart", 0);
                    //comm.Parameters.AddWithValue("@SortCol", 0);
                    //comm.Parameters.AddWithValue("@SortDir", "asc");
                    //comm.Parameters.AddWithValue("@SearchTerm", searchTerm);
                    //comm.Parameters.AddWithValue("@PageIndex", pageIndex);
                    //comm.Parameters.AddWithValue("@PageSize", PageSize);
                    //comm.Parameters.Add("@RecordCount", SqlDbType.Int, 4).Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();
                    while (rdr.Read())
                    {

                        Userlst.Add(new BusinessPartner
                        {
                            t_bpid = rdr["t_bpid"].ToString(),
                            t_ctit = rdr["t_ctit"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_seak = rdr["t_seak"].ToString(),
                            t_prbp = rdr["t_prbp"].ToString(),
                            t_prst = rdr["t_prst"].ToString(),
                            t_stdt = rdr["t_stdt"].ToString(),
                            t_endt = rdr["t_endt"].ToString(),
                            t_clan = rdr["t_clan"].ToString(),
                            t_ccur = rdr["t_ccur"].ToString(),
                            t_sndr = rdr["t_sndr"].ToString(),
                            t_edyn = rdr["t_edyn"].ToString(),
                            t_fovn = rdr["t_fovn"].ToString(),
                            t_lvdt = rdr["t_lvdt"].ToString(),
                            t_inrl = rdr["t_inrl"].ToString(),
                            t_iscn = rdr["t_iscn"].ToString(),
                            t_lgid = rdr["t_lgid"].ToString(),
                            t_cmid = rdr["t_cmid"].ToString(),
                            t_bptx = rdr["t_bptx"].ToString(),
                            t_cadr = rdr["t_cadr"].ToString(),
                            t_telp = rdr["t_telp"].ToString(),
                            t_tlcy = rdr["t_tlcy"].ToString(),
                            t_tlci = rdr["t_tlci"].ToString(),
                            t_tlln = rdr["t_tlln"].ToString(),
                            t_tlex = rdr["t_tlex"].ToString(),
                            t_tefx = rdr["t_tefx"].ToString(),
                            t_tfcy = rdr["t_tfcy"].ToString(),
                            t_tfci = rdr["t_tfci"].ToString(),
                            t_tfln = rdr["t_tfln"].ToString(),
                            t_tfex = rdr["t_tfex"].ToString(),
                            t_ccnt = rdr["t_ccnt"].ToString(),
                            t_cint = rdr["t_cint"].ToString(),
                            t_foid = rdr["t_foid"].ToString(),
                            t_crid = rdr["t_crid"].ToString(),
                            t_icst = rdr["t_icst"].ToString(),
                            t_icod = rdr["t_icod"].ToString(),
                            t_fact = rdr["t_fact"].ToString(),
                            t_ecmp = rdr["t_ecmp"].ToString(),
                            t_coff = rdr["t_coff"].ToString(),
                            t_crdt = rdr["t_crdt"].ToString(),
                            t_lmdt = rdr["t_lmdt"].ToString(),
                            t_lmus = rdr["t_lmus"].ToString(),
                            t_bprl = rdr["t_bprl"].ToString(),
                            t_btbv = rdr["t_btbv"].ToString(),
                            t_usid = rdr["t_usid"].ToString(),
                            t_clcd = rdr["t_clcd"].ToString(),
                            t_cbcl = rdr["t_cbcl"].ToString(),
                            t_beid = rdr["t_beid"].ToString(),
                            t_inet = rdr["t_inet"].ToString(),
                            t_imag = rdr["t_imag"].ToString(),
                            t_smt1 = rdr["t_smt1"].ToString(),
                            t_sml1 = rdr["t_sml1"].ToString(),
                            t_smt2 = rdr["t_smt2"].ToString(),
                            t_sml2 = rdr["t_sml2"].ToString(),
                            t_smt3 = rdr["t_smt3"].ToString(),
                            t_sml3 = rdr["t_sml3"].ToString(),
                            t_smt4 = rdr["t_smt4"].ToString(),
                            t_sml4 = rdr["t_sml4"].ToString(),
                            t_smt5 = rdr["t_smt5"].ToString(),
                            t_sml5 = rdr["t_sml5"].ToString(),
                            t_txta = rdr["t_txta"].ToString(),
                        });
                    }
                    con.Close();
                    //return GetData(comm, pageIndex).GetXml();
                    

                    message = (string)comm.Parameters["@ERROR"].Value.ToString();

                    //JsonResult json = Json(Userlst, JsonRequestBehavior.AllowGet);
                    //json.MaxJsonLength = int.MaxValue;
                    //return json;
                    
                    //response = message;
                    return Userlst;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }

    public class BusinessPartner
    {

        public string t_bpid { get; set; }
        public string t_ctit { get; set; }
        public string t_nama { get; set; }
        public string t_seak { get; set; }
        public string t_prbp { get; set; }
        public string t_prst { get; set; }
        public string t_stdt { get; set; }
        public string t_endt { get; set; }
        public string t_clan { get; set; }
        public string t_ccur { get; set; }
        public string t_sndr { get; set; }
        public string t_edyn { get; set; }
        public string t_fovn { get; set; }
        public string t_lvdt { get; set; }
        public string t_inrl { get; set; }
        public string t_iscn { get; set; }
        public string t_lgid { get; set; }
        public string t_cmid { get; set; }
        public string t_bptx { get; set; }
        public string t_cadr { get; set; }
        public string t_telp { get; set; }
        public string t_tlcy { get; set; }
        public string t_tlci { get; set; }
        public string t_tlln { get; set; }
        public string t_tlex { get; set; }
        public string t_tefx { get; set; }
        public string t_tfcy { get; set; }
        public string t_tfci { get; set; }
        public string t_tfln { get; set; }
        public string t_tfex { get; set; }
        public string t_ccnt { get; set; }
        public string t_cint { get; set; }
        public string t_foid { get; set; }
        public string t_crid { get; set; }
        public string t_icst { get; set; }
        public string t_icod { get; set; }
        public string t_fact { get; set; }
        public string t_ecmp { get; set; }
        public string t_coff { get; set; }
        public string t_crdt { get; set; }
        public string t_lmdt { get; set; }
        public string t_lmus { get; set; }
        public string t_bprl { get; set; }
        public string t_btbv { get; set; }
        public string t_usid { get; set; }
        public string t_clcd { get; set; }
        public string t_cbcl { get; set; }
        public string t_beid { get; set; }
        public string t_inet { get; set; }
        public string t_imag { get; set; }
        public string t_smt1 { get; set; }
        public string t_sml1 { get; set; }
        public string t_smt2 { get; set; }
        public string t_sml2 { get; set; }
        public string t_smt3 { get; set; }
        public string t_sml3 { get; set; }
        public string t_smt4 { get; set; }
        public string t_sml4 { get; set; }
        public string t_smt5 { get; set; }
        public string t_sml5 { get; set; }
        public string t_txta { get; set; }

    }



}