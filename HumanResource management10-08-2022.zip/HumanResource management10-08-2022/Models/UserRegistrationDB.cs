﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using HumanResourceManagement.Models;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Web.UI;
using System.Text;


using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

namespace HumanResourceManagement.Models
{
    public class UserRegistrationDB
    {
        string cs = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
        private string message = string.Empty;
        //public string checkstatus = "SUCCESS";
        //public string checkItemstatus = "SUCCESS";

        public string AddUser(UserRegistration user)
        {
            string response = string.Empty;
            int i;
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand comm = new SqlCommand("testdb..[SWUserRegistration]", con);

                    comm.CommandType = CommandType.StoredProcedure;
                    
                    if (user.t_emno == null)
                    {
                        comm.Parameters.AddWithValue("@t_emno", null);
                    }
                    else
                    {
                        comm.Parameters.AddWithValue("@t_emno", user.t_emno);
                    }
                    comm.Parameters.AddWithValue("@Action", user.Action);
                    comm.Parameters.AddWithValue("@t_nama", user.t_nama);
                    comm.Parameters.AddWithValue("@t_emai", user.t_emai);
                    comm.Parameters.AddWithValue("@t_mobl", user.t_mobl);
                    comm.Parameters.AddWithValue("@t_pass", user.t_pass);
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    i = comm.ExecuteNonQuery();
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    /////////////////Send Mail To User////////////////////////////
                    string Feedback;
                    //string EmailMode = "Admin";
                    //string AdminMail1 = "atul.gurnule7@gmail.com";
                    //const string SERVER = "relay-hosting.secureserver.net";
                    if (user.t_emai != "")
                    {
                        /////////////////////////
                        using (StringWriter sw = new StringWriter())
                        {
                            using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                            {
                                //////////////////////////////

                                StringBuilder sb = new StringBuilder();
                                sb.Append("<html><body>");
                                //sb.Append("<img src='~/HumanResourceManagement/HumanResourceManagement/dist/img/loginlogo.png' alt='Smiley face'  width='35%' height='15%'/>");
                                //sb.Append("<hr size='15' style='background-color:#72AFD1'>");
                                sb.Append("<h2>SPACEWOOD FURNISHERS PVT LTD.</h2>");
                                sb.Append("<h4>Hi, " + user.t_nama + "</h4>");
                                sb.Append("<h4>Thank You For Contacting Us</h4>");
                                sb.Append("<p>You have registered successfully in spacewood.</p>");

                                sb.Append("</br>");
                                sb.Append("<hr>");
                                sb.Append("<table>");
                                sb.Append("<tr>");
                                sb.Append("<h4>Please note your user name and password for all further communication with Spacewood.</h4>");
                                sb.Append("</tr>");
                                sb.Append("<tr>");
                                sb.Append("<td>User name: <b>" + user.t_mobl + "</b></td>");
                                sb.Append("</tr>");
                                sb.Append("<tr>");
                                sb.Append("<td>Password: <b>" + user.t_pass + "</b></td>");
                                sb.Append("</tr>");
                                sb.Append("</br>");
                                sb.Append("</table>");
                                sb.Append("<h4>Note : Keep the scan copy of listed document ready for uploading on candidate details portal.</h4>");
                                sb.Append("<h4>1) Passport size photo in jpg,jpeg or png format</h4>");
                                sb.Append("<h4>2) Resume in doc,docx, or pdf format</h4>");
                                sb.Append("<h4>3) Education certificate in pdf format</h4>");
                                sb.Append("<h4>4) Previous company  experience certificate in pdf format</h4>");
                                sb.Append("<h4>5) Last 3 month Payslip in pdf format</h4>");
                                sb.Append("<h4>6) Keep scan copy of Address Proof(Electric bill),Aadhar Number, PAN Number,Driving License No,COVID-19 Vaccine Dose-1,COVID-19 Vaccine-Dose-2,UAN Number(Not mandatory for fresher) in pdf format</h5>");
                                sb.Append("<h4>7) Any certification certificate in pdf format</h4>");
                                sb.Append("<h4>Kindly click on below link for filling candidate details.</h4>");
                                sb.Append("<h4>Go through this link for fill application form. https://recruitment.spacewood.in/(S(jm4zmhge2f2azzupkh4ebxle))/Home/Index</h4>");
                                sb.Append("<hr>");
                                sb.Append("<p>Thank you for the interest in exploring carrier opportunities with Spacewood Furnishers Pvt Ltd.</p>");
                                sb.Append("<p>Wish u the best of Luck for the selection process.</p>");
                                sb.Append("<p>You can contact us at <u>hr@spacewood.in</u> for queries regarding anything about the service.</p>");
                                sb.Append("</hr>");
                                sb.Append("<p><b>Regards,</b></p>");
                                sb.Append("<p><b>Team Spacewood</b></p>");
                                sb.Append("</body></html>");

                                //StringReader sr = new StringReader(sb.ToString());
                                Feedback = sb.ToString();
                              
                                con.Open();
                                SqlCommand cmd = new SqlCommand("testdb..[SWSendEmailUserRegistratioComplete]", con);

                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@subject", "Spacewood | Candidate Registration Details");
                                //cmd.Parameters.AddWithValue("@profile", "SpacewoodMail");
                                cmd.Parameters.AddWithValue("@profile", "SpacewoodHRMailProfile");
                                //cmd.Parameters.AddWithValue("@profile", "scp_mail");
                                cmd.Parameters.AddWithValue("@to", user.t_emai);
                                cmd.Parameters.AddWithValue("@cc", "pers@spacewood.in");
                                cmd.Parameters.AddWithValue("@bcc", "");
                                cmd.Parameters.AddWithValue("@mbody", Feedback);
                                i = cmd.ExecuteNonQuery();
                                con.Close();
                            }
                         }
                    }
                    /////////////////////End Mail///////////////////////////////////
                    response = message;
                    return response;
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                response = ex.ToString();
                return response;
            }

        }

        public List<UserRegistration> GetDetails(string t_emno)
        {
            try
            {
                string response = string.Empty;

                List<UserRegistration> User = new List<UserRegistration>();

                using (SqlConnection con = new SqlConnection(cs))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb..[SWUserRegistration]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "S");
                    comm.Parameters.Add(new SqlParameter("@t_emno", t_emno));
                    comm.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);

                    comm.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    SqlDataReader rdr = comm.ExecuteReader();

                    while (rdr.Read())
                    {
                        User.Add(new UserRegistration
                        {
                            t_emno = rdr["t_emno"].ToString(),
                            t_nama = rdr["t_nama"].ToString(),
                            t_emai = rdr["t_emai"].ToString(),
                            t_mobl = rdr["t_mobl"].ToString(),
                            t_pass = rdr["t_pass"].ToString(),

                         });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@ERROR"].Value.ToString();
                    response = message;
                    return User;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string CanDelete(string t_emno)
        {
            string response = string.Empty;
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    con.Open();

                    SqlCommand com = new SqlCommand("testdb..[SWUserRegistration]", con);
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@t_emno", t_emno);
                    com.Parameters.AddWithValue("@Action", "D");
                    com.Parameters.Add("@ERROR", SqlDbType.VarChar, 500);
                    com.Parameters["@ERROR"].Direction = ParameterDirection.Output;
                    com.ExecuteNonQuery();
                    message = (string)com.Parameters["@ERROR"].Value.ToString();
                    con.Close();
                    response = message;

                }
                return response;
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
            return response;
        }
    }
}