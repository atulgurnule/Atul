﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using HumanResourceManagement.Models;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Web.UI;
using System.Text;

namespace HumanResourceManagement.Models
{
    public class ttcswc001100_emp
    {
        public string t_emno { get; set; }
        public string t_firn { get; set; }
        public string t_midn { get; set; }
        public string t_lasn { get; set; }
        public string t_nama { get; set; }
        public string t_motn { get; set; }
        public int t_gend { get; set; }
        public string t_dobt { get; set; }
        public string t_plob { get; set; }
        public string t_nati { get; set; }
        public int t_matr { get; set; }
        public string t_datm { get; set; }
        public string t_phon { get; set; }
        public string t_emai { get; set; }
        public string t_reli { get; set; }
        public string t_motl { get; set; }
        public string t_high { get; set; }
        public string t_dojd { get; set; }//User
        public int t_empt { get; set; }
        public string t_cste { get; set; }//State
        public int t_stat { get; set; }//State
        public string t_esic { get; set; }
        public string t_bano { get; set; }
        public string t_bank { get; set; }
        public string t_pfco { get; set; }
        public string t_uanc { get; set; }
        public string t_adhe { get; set; }
        public string t_panu { get; set; }
        public int t_week { get; set; }
        public int t_shif { get; set; }
        public string t_punc { get; set; }
        public string t_cadr { get; set; }
        public string t_laem { get; set; }
        public int t_pono { get; set; }
        public string t_puni { get; set; }
        public string t_padr { get; set; }
        public string t_atos { get; set; }
        //public HttpPostedFileBase postedFiles { get; set; }
        //public HttpPostedFileBase uploadresume { get; set; }
        //public string AlertPopupMsg { get; set; }
      
      
    }
}