﻿$(document).ready(function () {
    BindUserDetails();
    BindRegistrationCompletedDetails();
    $("#refreshdiv").load(location.href + "#refreshdiv");

});

function BindUserDetails() {

    //var table = $('#tblregistrationdetails').DataTable();
    //table
    //    .clear()
    //    .draw();
    //destroy: true,
    //    table.destroy();


    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Adminpanel/BindRegistrationDetails",
        //data: '{t_emno :"' + detailempid + '"}',
        success: function (data) {


            var datatableVariable = $('#tblregistrationdetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "buttons": ["excel", "pdf", "print"],
                "bDestroy": true,
                data: data,

                columns: [

                    {
                        data: null, render: function (data, type, row, meta) {
                            return '<a href = "../Adminpanel/ViewApplicationForm?EmpId=' + row.t_emno + '&EmployeeName=' + row.t_nama + ' "class="badge badge-success">View</a>';
                            //return '<a href = "../Adminpanel/ViewApplicationForm?EmpId=' + row.t_emno + '&EmployeeName=' + row.t_nama + ' "class="badge badge-success"><i class="fa fa-backward"></i></a>';
                        }
                    },
                    { "data": "t_emno", "name": "Employee No." },
                    { "data": "t_nama", "name": "Employee Name" },
                    { "data": "t_emai", "name": "Email" },
                    { "data": "t_mobl", "name": "Mobile No." },
                    { "data": "t_pass", "name": "Password" },
                    {

                        data: null, render: function (data, type, row, meta) {
                            var submitStatus = "";
                            if (row.t_stat == 1) {
                                submitStatus = "PENDING";
                                return '<div' + submitStatus + '" class="badge bg-danger">' + submitStatus + '</div>';
                            }
                            else {
                                submitStatus = "COMPLETED";
                                return '<div' + submitStatus + '" class="badge bg-success">' + submitStatus + '</div>';
                            }

                        }
                    },
                    {
                        data: null, render: function (data, type, row, meta) {
                            var convertStatus = "";
                            //|| row.t_pemp != null 
                            if (row.t_pemp.trim() != '') {
                                convertStatus = "CONVERTED";
                                return '<div' + convertStatus + '" class="badge bg-success">' + convertStatus + '</div>';
                            }
                            else {
                                convertStatus = "PENDING";
                                return '<div' + convertStatus + '" class="badge bg-danger">' + convertStatus + '</div>';
                            }

                        }
                    }
                ]
            }).buttons().container().appendTo('#tblregistrationdetails_wrapper .col-md-6:eq(0)');

        }
    });

};


function BindRegistrationCompletedDetails() {

    var table = $('#tblregistrationformcompleted').DataTable();
    table
        .clear()
        .draw();
    destroy: true,
        table.destroy();


    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Adminpanel/BindRegistration",
        //data: '{t_emno :"' + detailempid + '"}',
        success: function (data) {


            var datatableVariable = $('#tblregistrationformcompleted').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "buttons": ["excel", "pdf", "print"],

                data: data,

                columns: [
                    {
                        data: null, render: function (data, type, row, meta) {

                            return '<a href = "../Adminpanel/ViewApplicationForm?EmpId=' + row.t_emno + '&EmployeeName=' + row.t_nama + ' "class="badge badge-success"><i class="fa fa-backward"></i></a>';
                        }
                    },
                    { "data": "t_emno", "name": "Employee No." },
                    { "data": "t_nama", "name": "Employee Name" },
                    { "data": "t_emai", "name": "Email" },
                    { "data": "t_mobl", "name": "Mobile No." },
                    //{ "data": "t_pass", "name": "Password" },
                    {

                        data: null, render: function (data, type, row, meta) {
                            var submitStatus;
                            if (row.t_stat == 3) {
                                submitStatus = "COMPLETED";
                                return '<div' + submitStatus + '" class="badge bg-success">' + submitStatus + '</div>';
                            }
                            //else {

                            //return '<div' + submitStatus + '" class="badge bg-success">' + submitStatus + '</div>';
                            //}

                        }
                    },


                ]
            }).buttons().container().appendTo('#tblregistrationformcompleted_wrapper .col-md-6:eq(0)');

        }
    });

};