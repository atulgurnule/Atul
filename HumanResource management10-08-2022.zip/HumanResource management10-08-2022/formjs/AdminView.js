﻿$(document).ready(function () {
   
    //BindAdminRegistrationDetails();
});



function BindAdminRegistrationDetails() {

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Adminpanel/AdminRegistrationBind",
        //data: '{t_emno :"' + detailempid + '"}',
        success: function (data) {


            var datatableVariable = $('#tblregistrationadmin').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "bDestroy": true,
                "buttons": ["excel", "pdf", "print"],
                 data: data,
                 columns: [
                   
                    { "data": "t_emno", "name": "Admin No." },
                    { "data": "t_nama", "name": "Admin Name" },
                    { "data": "t_emai", "name": "Admin Email" },
                    { "data": "t_mobl", "name": "Mobile No." },
                    { "data": "t_pass", "name": "Password" },
                    { "data": "t_crdt", "name": "Creation Date" },


                ]
            }).buttons().container().appendTo('#tblregistrationadmin_wrapper .col-md-6:eq(0)');

        }
    });

};