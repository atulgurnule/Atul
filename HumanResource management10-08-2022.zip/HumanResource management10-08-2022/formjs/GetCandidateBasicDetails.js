﻿
var detailempid;
$(document).ready(function () {
    debugger
    BindCandidateDetail();
});
//For Get Selected row
function pageLoad() {
}
function GetSelectedRow(lnk) {

    var StateName = lnk.value;
    /*window.opener.setValue(StateName); */
    window.opener.setValue(lnk);
    window.close();
    return false;
}


function BindCandidateDetail() {
    
    $("#divLoader").show();

    $.ajax({
        url: "../EmployeeIntegration/GettTabledataList",
        type: "POST",
        //data: '{t_emno : "' + detailempid + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            debugger
            $("#divLoader").hide();
            if (data.length > 0) {

            }
            var datatableVariable = $('#tblCandidateDetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": true,
                //"dom": 'Bfrtip',
                "buttons": ["excel", "pdf", "print"],
                "bDestroy": true,
                data: data,

                columns: [
                    {

                        data: null, "title": "#", render: function (data, type, row, meta) {

                            return '<a href="#" class="btn btn-block btn-secondary" onclick=javascript:GetSelectedRow("' + row.t_emno + '")><i class="fas fa-arrow-circle-left"></i></a></div>';
                            
                        }
                    },
                    { "data": "t_emno", "title": "Candidate Id" },
                    { "data": "t_firn", "title": "First Name" },
                    { "data": "t_midn", "title": "Middle Name" },
                    { "data": "t_lasn", "title": "Last Name" },
                    { "data": "t_motn", "title": "Mother Name" },
                    {

                        data: null, "title": "Gender", render: function (data, type, row, meta) {
                            var genderStatus = "";
                            if (row.t_gend == 1) {
                                genderStatus = "MALE";
                                return '<div' + genderStatus + '" class="badge bg-success">' + genderStatus + '</div>';
                            }
                            else {
                                genderStatus = "FEMALE";
                                return '<div' + genderStatus + '" class="badge bg-success">' + genderStatus + '</div>';
                            }

                        }
                    },
                    {

                        data: null, "title": "Date Of Birth", render: function (data, type, row, meta) {
                            var dobStatus = "";
                            if (row.t_dobt == '01-01-1900') {
                                dobStatus = "NA";
                                return '<div' + dobStatus + '" class="badge bg-danger">' + dobStatus + '</div>';
                            }
                            else {
                                dobStatus = row.t_dobt;
                                return '<div' + dobStatus + '" class="badge bg-success">' + dobStatus + '</div>';
                            }

                        }
                    },
                    { "data": "t_plob", "title": "Place of Birth" },
                    { "data": "t_city", "title": "City" },
                    { "data": "t_cste", "title": "State" },
                    { "data": "t_nati", "title": "Nationality" },
                    { "data": "t_mobl", "title": "Mobile No" },
                    { "data": "t_emai", "title": "Email" },
                    {
                        data: null, "title": "Employee Type", render: function (data, type, row, meta) {
                            var employeeytypeStatus = "";
                            if (row.t_etyp == 1) {
                                employeeytypeStatus = "Fresher";
                                return '<div' + employeeytypeStatus + '" class="badge bg-danger">' + employeeytypeStatus + '</div>';
                            }
                            else {
                                employeeytypeStatus = "Experienced";
                                return '<div' + employeeytypeStatus + '" class="badge bg-success">' + employeeytypeStatus + '</div>';
                            }
                        }
                    },
                    {

                        data: null, "title": "Status", render: function (data, type, row, meta) {
                            var submitStatus = "";
                            if (row.t_stat == 1) {
                                submitStatus = "IN PROCESS";
                                return '<div' + submitStatus + '" class="badge bg-danger">' + submitStatus + '</div>';
                            }
                            else {
                                submitStatus = "COMPLETED";
                                return '<div' + submitStatus + '" class="badge bg-success">' + submitStatus + '</div>';
                            }

                        }
                    },


                ]
            }).buttons().container().appendTo('#tblCandidateDetails_wrapper .col-md-6:eq(0)');

        }
    });

};



