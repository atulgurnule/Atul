﻿$(document).ready(function () {

    onlyAlphabets();
    onlyNumbers();
});
function onlyAlphabets() {

    $('.alphabetsOnly').keypress(function (event) {
        //Space Already Added
        var regex = new RegExp("^[a-zA-Z\b ]+$");
        var str = String.fromCharCode(!event.charCode ? event.which : event.charCode);
        if (regex.test(str)) {
            return true;
        }
        else {
            event.preventDefault();
            //alert('Please Enter Alphabate');
            toastr.warning('Please Enter alphabets only...!!!');
            return false;
        }
  });
}

function onlyNumbers() {
 $(".numbersOnly").keypress(function (e) {

        //if the letter is not digit then display error and don't type anything
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            //display error message
            //$("#errmsg").html("Digits Only").show().fadeOut("slow");
            //alert("Enter only numbers");
            toastr.warning('Enter numbers only...!!!');
            return false;
            e.preventDefault();
        }
    });
}

function AadharValidate() {
    var aadhar = document.getElementById("txtAadhar").value;
    var adharcardTwelveDigit = /^\d{12}$/;
    var adharSixteenDigit = /^\d{16}$/;
    if (aadhar != '') {
        if (aadhar.match(adharcardTwelveDigit)) {
            return true;
        }
        else if (aadhar.match(adharSixteenDigit)) {
            return true;
        }
        else {
            alert("Enter valid Aadhar Number");
            return false;
        }
    }
}

//function ValidateEmail() {

//$('[id*=txtEmail]').change(function (e) {
//    e.preventDefault();
//    if (!ValidateEmail($('[id*=txtEmail]').val())) {
//        ShowPopup("Invalid email address.");
//    }
//    else {
//        //ShowPopup("Valid email address.");
//    }
//});

////}
//function ValidateEmail(email) {
//    var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
//    return expr.test(email);
//};

//$('[id*=btnsave]').live("click", function (e) {

//});

//function ValidateEmail() {
//    $('[id*=txtEmail]').keypress(function (e) {
//        

//        var email = $('[id*=txtEmail]').val();
//        //var email = document.getElementById("<%=txtEmail.ClientID%>");
//        var filter = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/;
//        if (!filter.test(email.value)) {
//            ShowPopup('Please provide a valid email address');
//            email.focus;
//            e.preventDefault();
//            return false;
//        }
//        return true;

//    });
//}



function ShowPopup(message) {
    $(function () {
        $("#dialog").html(message);
        $("#dialog").dialog({
            title: "Admin Panel",
            buttons: {
                Close: function () {
                    $(this).dialog('close');
                }
            },
            modal: true
        });
    });
};
