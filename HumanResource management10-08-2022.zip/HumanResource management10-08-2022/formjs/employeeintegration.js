﻿var detailempid;
$(document).ready(function () {

   
    //$("#divLoader").show();
    //checkMaritalStatus();
    //if (detailempid != "") {
    //    getbyBasicDetails(detailempid);
    //}
   
    //BindEmployeeDetail();
   
    //$("#divLoader").hide();
   
});





