﻿//Load Data in Table when documents is ready  
var detailempid;
$(document).ready(function () {

    //var detailempid = '<%= Session["empid"] %>';
    //if (detailempid == "") {
        
    //    window.location.href = '/Home/Index';
    //}
   
    //Important Code
    //var enabled = [];
    //var disabled = [];
    //enabled = $('#hfEnabled').val().split(',').map(Number);
    //if ($('#hfDisabled').val() != '') {
    //    disabled = $('#hfDisabled').val().split(',').map(Number);
    //    $("#tabs").tabs({ active: $('#hfEnabled').val(), disabled: disabled });
    //}

    var CandidateId = $("#txtemployeeID").val();
    {
        if (CandidateId != "") {
            $("#divLoader").show();
            BindBasicDetail();
            BindFamilyDetail();
            BindEducationDetail();
            BindDocumentDetail();
            BindCompanyDetails();
            BindPayslipDetail();
            BindReferenceDetail();
            BindCertificationDetail();
            $("#divLoader").hide();
        }
    }
    
});

$("#txtemployeeID").change(function () {

    var empcode = $('#txtemployeeID').val();

    if (empcode == "") {
        //toastr.warning('Please enter employee Id...!!!');
    }
    else {


        $.ajax({
            url: "../Adminpanel/GetEmployeeName",
            data: '{t_emno :"' + empcode + '"}',

            type: "POST",
            contentType: "application/json;charset=UTF-8",
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {

                    var result = data;

                    $("#lblEmpName").text(result[0].employeeName);
                    $("#lblEmpName").show();
                    //$("[id*=txtpanno]").val(result[0].t_panu);
                    //$("[id*=txtdob]").val(result[0].t_dobt);
                    //$("[id*=ltEmbed]").val('');

                }
                else {

                    //toastr.warning('Record not found...!!!');
                    $("#lblEmpName").html("");
                    $("#txtemployeeID").val("");
                    //$('#headpreview').css('display', 'none');

                }

            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
        return false;
    }
    //BindEmployeeName();
});
$("#btnshow").click(function () {
    $("#divLoader").show();
    //getbyTabNotExistStatus();
    //getbyTabExistStatus();
    BindBasicDetail();
    BindFamilyDetail();
    BindEducationDetail();
    BindDocumentDetail();
    BindCompanyDetails();
    BindPayslipDetail();
    BindReferenceDetail();
    BindCertificationDetail();
    $("#divLoader").hide();
});

function getbyTabNotExistStatus() {
    $("#divLoader").show();
    $.ajax({
        url: "../Employee/CheckNotExistForTab",
        //data: '{t_emno :"' + detailempid + '"}',
        //data: { t_emno: detailempid},
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {

            //$('#ddlact').empty();
            var result = data;
            if (result == 'BASICNOTEXIST') {
                var enabled = 0;
                var disabled = [1, 2, 3, 4, 5, 6, 7];
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                $('#custom-tabs-three-home').addClass('active show');
                if (result == 'BASICNOTEXIST') {
                    $('#btnBasicDetails').show();
                    $('#btnBasicDetailsUpdate').hide();
                }
                else {
                    $('#btnBasicDetailsUpdate').show();
                    $('#btnBasicDetails').hide();
                }
                $("#divLoader").hide();
            }
            else if (result == 'FAMILYNOTEXIST') {
                var enabled = 1;
                var disabled = [0, 2, 3, 4, 5, 6, 7];
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-three-home').removeClass('active');
                $('#custom-tabs-three-profile').addClass('active show');
                if (result == 'FAMILYNOTEXIST') {
                    $('#btnAddFamily').show();
                    $('#btnUpdateFamily').hide();
                }
                else {
                    $('#btnUpdateFamily').show();
                    $('#btnAddFamily').hide();
                }
                $("#divLoader").hide();
            }
            else if (result == 'EDUCATIONNOTEXIST') {
                var enabled = 2;
                var disabled = [0, 1, 3, 4, 5, 6, 7];

                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-three-home').removeClass('active');
                $('#custom-tabs-three-profile').removeClass('active');
                $('#custom-tabs-three-messages').addClass('active show');
                if (result == 'EDUCATIONNOTEXIST') {
                    $('#btnInsertEducation').show();
                    $('#btnUpdateEducation').hide();
                }
                else {
                    $('#btnUpdateEducation').show();
                    $('#btnInsertEducation').hide();
                }
                $("#divLoader").hide();
            }
            else if (result == 'DOCUMENTNOTEXIST') {
                var enabled = 3;
                var disabled = [0, 1, 2, 4, 5, 6, 7];

                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-three-home').removeClass('active');
                $('#custom-tabs-three-profile').removeClass('active');
                $('#custom-tabs-three-messages').removeClass('active');
                $('#document').addClass('active show');
                if (result == 'DOCUMENTNOTEXIST') {
                    $('#btnInsertDocument').show();
                    $('#btnUpdateDocument').hide();
                }
                else {
                    $('#btnUpdateDocument').show();
                    $('#btnInsertDocument').hide();
                }
                $("#divLoader").hide();
            }
            else if (result == 'COMPANYNOTEXIST') {
                var enabled = 4;
                var disabled = [0, 1, 2, 3, 5, 6, 7];

                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-three-home').removeClass('active');
                $('#custom-tabs-three-profile').removeClass('active');
                $('#custom-tabs-three-messages').removeClass('active');
                $('#document').removeClass('active');
                $('#previous_company_details').addClass('active show');
                if (result == 'COMPANYNOTEXIST') {
                    $('#btncompanysubmit').show();
                    $('#btncompanyupdate').hide();
                }
                else {
                    $('#btncompanyupdate').show();
                    $('#btncompanysubmit').hide();
                }
                $("#divLoader").hide();
            }
            else if (result == 'PAYSLIPNOTEXIST') {
                var enabled = 5;
                var disabled = [0, 1, 2, 3, 4, 6, 7];

                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-three-home').removeClass('active');
                $('#custom-tabs-three-profile').removeClass('active');
                $('#custom-tabs-three-messages').removeClass('active');
                $('#document').removeClass('active');
                $('#previous_company_details').removeClass('active');
                $('#payslip_details').addClass('active show');
                if (result == 'PAYSLIPNOTEXIST') {
                    $('#btnPayslipsubmit').show();
                    $('#btnPayslipupdate').hide();
                }
                else {
                    $('#btnPayslipupdate').show();
                    $('#btnPayslipsubmit').hide();
                }
                $("#divLoader").hide();
            }
            else if (result == 'REFERENCENOTEXIST') {
                var enabled = 6;
                var disabled = [0, 1, 2, 3, 4, 5, 7];

                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-three-home').removeClass('active');
                $('#custom-tabs-three-profile').removeClass('active');
                $('#custom-tabs-three-messages').removeClass('active');
                $('#document').removeClass('active');
                $('#previous_company_details').removeClass('active');
                $('#payslip_details').removeClass('active');
                $('#reference_details').addClass('active show');
                if (result == 'REFERENCENOTEXIST') {
                    $('#btnreferencesubmit').show();
                    $('#btnreferenceupdate').hide();
                }
                else {
                    $('#btnreferenceupdate').show();
                    $('#btnreferencesubmit').hide();
                }
                $("#divLoader").hide();
            }
            else if (result == 'CERTIFICATIONNOTEXIST') {
                var enabled = 7;
                var disabled = [0, 1, 2, 3, 4, 5, 6];

                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-three-home').removeClass('active');
                $('#custom-tabs-three-profile').removeClass('active');
                $('#custom-tabs-three-messages').removeClass('active');
                $('#document').removeClass('active');
                $('#previous_company_details').removeClass('active');
                $('#reference_details').removeClass('active');
                $('#certification_details').addClass('active show');
                if (result == 'REFERENCENOTEXIST') {
                    $('#btnfinalsubmit').show();
                    $('#btnfinalupdate').hide();
                }
                else {
                    $('#btnfinalupdate').show();
                    $('#btnfinalsubmit').hide();
                }
                $("#divLoader").hide();
            }

            else if (result == 'ALLEXIST') {
                var enabled = 0;
                var disabled = [1, 2, 3, 4, 5, 6, 7];
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-three-profile').removeClass('active');
                $('#custom-tabs-three-messages').removeClass('active');
                $('#document').removeClass('active');
                $('#previous_company_details').removeClass('active');
                $('#reference_details').removeClass('active');
                $('#certification_details').removeClass('active');
                $('#custom-tabs-three-home').addClass('active show');
                toastr.warning('You have already submitted form,If you want any change then update form information...!!!');
                $('#btnBasicDetailsUpdate').show();
                $('#btnBasicDetails').hide();
                $("#divLoader").hide();
            }
            //else {
            //    var enabled = 7;
            //    var disabled = [0, 1, 2, 3, 4, 5, 6];
            //    $("#tabs").tabs({ active: enabled, disabled: disabled });
            //    $('#custom-tabs-three-home').removeClass('active');
            //    $('#custom-tabs-three-profile').removeClass('active');
            //    $('#custom-tabs-three-messages').removeClass('active');
            //    $('#document').removeClass('active');
            //    $('#previous_company_details').removeClass('active');
            //    $('#reference_details').removeClass('active');
            //    $('#certification_details').addClass('active show');
            //    $("#divLoader").hide();
            //    toastr.warning('You have not submitted form,Please submit form if you fill all required tab...!!!');
            //}

        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}
function getbyTabExistStatus() {
    $("#divLoader").show();
    $.ajax({
        url: "../Employee/CheckExistForTab",
        //data: '{t_emno :"' + detailempid + '"}',
        //data: { t_emno: detailempid},
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {
            $("#divLoader").hide();
            //$('#ddlact').empty();
            var result = data;
            if (result == 'BASICEXIST') {
                //var enabled = 0;
                //var disabled = [1, 2, 3, 4, 5, 6, 7];
                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                ////$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-home').addClass('active show');
                $('#btnBasicDetailsUpdate').show();
                $('#btnBasicDetails').hide();
            }
            else if (result == 'FAMILYEXIST') {
                $('#btnFamilyUpdate').show();
                $('#btnFamilyAdd').hide();
                //var enabled = 1;
                //var disabled = [0, 2, 3, 4, 5, 6, 7];
                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').addClass('active show');
            }
            else if (result == 'EDUCATIONEXIST') {
                $('#btnUpdateEducation').show();
                $('#btnInsertEducation').hide();
                //var enabled = 2;
                //var disabled = [0, 1, 3, 4, 5, 6, 7];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').addClass('active show');
            }
            else if (result == 'DOCUMENTEXIST') {
                $('#btnUpdateDocument').show();
                $('#btnInsertDocument').hide();
                //var enabled = 3;
                //var disabled = [0, 1, 2, 4, 5, 6, 7];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').addClass('active show');
            }
            else if (result == 'COMPANYEXIST') {
                $('#btncompanyupdate').show();
                $('#btncompanysubmit').hide();
                //var enabled = 4;
                //var disabled = [0, 1, 2, 3, 5, 6, 7];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').addClass('active show');
            }
            else if (result == 'PAYSLIPEXIST') {
                $('#btnPayslipupdate').show();
                $('#btnPayslipsubmit').hide();
                //var enabled = 5;
                //var disabled = [0, 1, 2, 3, 4, 6, 7];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').removeClass('active');
                //$('#payslip_details').addClass('active show');
            }
            else if (result == 'REFERENCEEXIST') {
                $('#btnreferenceupdate').show();
                $('#btnreferencesubmit').hide();
                $('#btnfinalupdate').show();
                $('#btnfinalsubmit').hide();
                //var enabled = 6;
                //var disabled = [0, 1, 2, 3, 4, 5, 7];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').removeClass('active');
                //$('#payslip_details').removeClass('active');
                //$('#reference_details').addClass('active show');
            }
            else if (result == 'CERTIFICATIONEXIST') {
                $('#btnfinalupdate').show();
                $('#btnfinalsubmit').hide();
                //var enabled = 7;
                //var disabled = [0, 1, 2, 3, 4, 5, 6];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').removeClass('active');
                //$('#reference_details').removeClass('active');
                //$('#certification_details').addClass('active show');
            }

            else if (result == 'ALLNOTEXIST') {
                $('#btnBasicDetails').show();
                $('#btnBasicDetailsUpdate').hide();
                //var enabled = 0;
                //var disabled = [1, 2, 3, 4, 5, 6, 7];
                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').removeClass('active');
                //$('#reference_details').removeClass('active');
                //$('#certification_details').removeClass('active');
                //$('#custom-tabs-three-home').addClass('active show');
                //toastr.warning('You have already submitted form,If you want any change then update form information...!!!');
            }
            else {
                //var enabled = 7;
                //var disabled = [0, 1, 2, 3, 4, 5, 6];
                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').removeClass('active');
                //$('#reference_details').removeClass('active');
                //$('#certification_details').addClass('active show');
                //toastr.warning('You have not submitted form,Please submit form if you fill all required tab...!!!');
            }

        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}
//Add Data Function   

function BasicNextConfirm() {
    var enabled = 1;
    var disabled = [0, 2, 3, 4, 5, 6, 7];
    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#custom-tabs-three-home').removeClass('active');
    $('#custom-tabs-three-profile').addClass('active show');
}
function familyNextConfirm() {
    var enabled = 2;
    var disabled = [0, 1, 3, 4, 5, 6, 7];

    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#custom-tabs-three-profile').removeClass('active');
    $('#custom-tabs-three-messages').addClass('active show');
}
function EducationNextConfirm() {
    var enabled = 3;
    var disabled = [0, 1, 2, 4, 5, 6, 7];

    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#custom-tabs-three-messages').removeClass('active');
    $('#document').addClass('active show');
}

function DocumentNextConfirm() {
    //var EmployeeType = $("#ddlEmployeeType option:selected").text();
    //if (EmployeeType == "Fresher") {
    //    $("#btnpreviouscompanyadd").attr("disabled", "disabled");
    //    $("#btnaddpayslip").attr("disabled", "disabled");
    //    var enabled = 6;
    //    var disabled = [0, 1, 2, 3, 4, 5, 7];

    //    $("#tabs").tabs({ active: enabled, disabled: disabled });
    //    $('#payslip_details').removeClass('active');
    //    $('#reference_details').addClass('active show');

    //} else {

    $("#btnpreviouscompanyadd").removeAttr("disabled");
    $("#btnaddpayslip").removeAttr("disabled");
    var enabled = 4;
    var disabled = [0, 1, 2, 3, 5, 6, 7];

    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#document').removeClass('active');
    $('#previous_company_details').addClass('active show');
    //}
}
function CompanyNextConfirm() {
    var enabled = 5;
    var disabled = [0, 1, 2, 3, 4, 6, 7];

    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#previous_company_details').removeClass('active');
    $('#payslip_details').addClass('active show');
}

function PayslipNextConfirm() {
    var enabled = 6;
    var disabled = [0, 1, 2, 3, 4, 5, 7];

    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#payslip_details').removeClass('active');
    $('#reference_details').addClass('active show');
}

function ReferenceNextConfirm() {
    var enabled = 7;
    var disabled = [0, 1, 2, 3, 4, 5, 6];

    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#reference_details').removeClass('active');
    $('#certification_details').addClass('active show');
}

function DownloadFinalApplication() {
    //var enabled = 7;
    //var disabled = [0, 1, 2, 3, 4, 5, 6];

    //$("#tabs").tabs({ active: enabled, disabled: disabled });
    //$('#reference_details').removeClass('active');
    //$('#certification_details').addClass('active show');
}

$("#btnFamilyBack").click(function () {

    $.ajax({
        url: "../Employee/CheckExistForTab",
        //data: '{t_emno :"' + detailempid + '"}',
        //data: { t_emno: detailempid},
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {

            //$('#ddlact').empty();
            var result = data;
            if (result == 'BASICEXIST') {
                var enabled = 0;
                var disabled = [1, 2, 3, 4, 5, 6, 7];
                //enabled = $('#hfEnabled').val().split(',').map(Number);
                //if ($('#hfDisabled').val() != '') {
                //disabled = $('#hfDisabled').val().split(',').map(Number);
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-three-profile').removeClass('active');
                $('#custom-tabs-three-home').addClass('active show');
                $('#btnBasicDetailsUpdate').show();
                $('#btnBasicDetails').hide();
            }
            else {
                var enabled = 0;
                var disabled = [1, 2, 3, 4, 5, 6, 7];
                //enabled = $('#hfEnabled').val().split(',').map(Number);
                //if ($('#hfDisabled').val() != '') {
                //disabled = $('#hfDisabled').val().split(',').map(Number);
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-three-profile').removeClass('active');
                $('#custom-tabs-three-home').addClass('active show');
            }



        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });

});

$("#btnEducationBack").click(function () {
    var enabled = 1;
    var disabled = [0, 2, 3, 4, 5, 6, 7];

    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#custom-tabs-three-messages').removeClass('active');
    $('#custom-tabs-three-profile').addClass('active show');
});

$("#btnDocumentBack").click(function () {
    var enabled = 2;
    var disabled = [0, 1, 3, 4, 5, 6, 7];

    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#document').removeClass('active');
    $('#custom-tabs-three-messages').addClass('active show');
});
$("#btncompanyBack").click(function () {
    var enabled = 3;
    var disabled = [0, 1, 2, 4, 5, 6, 7];

    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#previous_company_details').removeClass('active');
    $('#document').addClass('active show');
});
$("#btnPayslipBack").click(function () {
    var enabled = 4;
    var disabled = [0, 1, 2, 3, 5, 6, 7];

    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#payslip_details').removeClass('active');
    $('#previous_company_details').addClass('active show');
});
$("#btnreferenceBack").click(function () {

    var EmployeeType = $("#ddlEmployeeType option:selected").text();
    if (EmployeeType == "Fresher") {
        $("#btnpreviouscompanyadd").attr("disabled", "disabled");
        $("#btnaddpayslip").attr("disabled", "disabled");
        var enabled = 3;
        var disabled = [0, 1, 2, 4, 5, 6, 7];

        $("#tabs").tabs({ active: enabled, disabled: disabled });
        $('#reference_details').removeClass('active');
        $('#document').addClass('active show');

    } else {

        $("#btnpreviouscompanyadd").removeAttr("disabled");
        $("#btnaddpayslip").removeAttr("disabled");

        var enabled = 5;
        var disabled = [0, 1, 2, 3, 4, 6, 7];

        $("#tabs").tabs({ active: enabled, disabled: disabled });
        $('#reference_details').removeClass('active');
        $('#payslip_details').addClass('active show');
    }
});
$("#btnfinaldownloadBack").click(function () {

    var enabled = 6;
    var disabled = [0, 1, 2, 3, 4, 5, 7];
    //enabled = $('#hfEnabled').val().split(',').map(Number);
    //if ($('#hfDisabled').val() != '') {
    //disabled = $('#hfDisabled').val().split(',').map(Number);
    $("#tabs").tabs({ active: enabled, disabled: disabled });
    $('#certification_details').removeClass('active');
    $('#reference_details').addClass('active show');

});

function BindBasicDetail() {

    var table = $('#tblBasicdetails').DataTable();
    table
        .clear()
        .draw();
    destroy: true,
        table.destroy();
    var EmpId = $('#txtemployeeID').val();
    
    $.ajax({
        url: "../Adminpanel/BindBasicInfoDetails",
        type: "POST",
        data: '{t_emno :"' + EmpId + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (data.length > 0) {
                
                var datatableVariable = $('#tblBasicdetails').DataTable({
                    "responsive": true, "lengthChange": false, "autoWidth": false,
                    "dom": 'Bfrtip',
                    "bDestroy": true,
                    "buttons": ["excel", "pdf", "print"],
                    data: data,

                    columns: [
                        { "data": "t_emno", "name": "Employee No." },
                        { "data": "employeeName", "name": "Candidate Name" },
                        {
                            "title": "Profile Photo", data: null, render: function (data, type, row, meta) {
                                return '<a href="#" onclick = "return ViewImg(\'' + row.t_path + '\')" ><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_path + '" width="50" height="50"></li ></a>'
                            }

                        },
                        {
                            data: null, render: function (data, type, row, meta) {
                                return '<a href="' + row.t_rpat + '" <i class="fas fa-download badge bg-primary" download></i>Download File</a>'
                            }
                        },
                        { "data": "t_motn", "name": "Mother Name" },
                        {

                            data: null, render: function (data, type, row, meta) {
                                var genderStatus = "";
                                if (row.t_gend == 1) {
                                    genderStatus = "MALE";
                                    return '<div' + genderStatus + '" class="badge bg-success">' + genderStatus + '</div>';
                                }
                                else {
                                    genderStatus = "FEMALE";
                                    return '<div' + genderStatus + '" class="badge bg-success">' + genderStatus + '</div>';
                                }

                            }
                        },

                        { "data": "t_dobt", "name": "Candidate DOB" },
                        { "data": "t_plob", "name": "Place of Birth" },
                        { "data": "t_culo", "name": "Current Location" },
                        { "data": "t_cadr", "name": "Permanant Address" },
                        { "data": "t_coad", "name": "Correspondence Address" },
                        { "data": "t_cstedesc", "name": "State" },
                        { "data": "t_city", "name": "City" },
                        { "data": "t_nati", "name": "Nationality" },
                        {
                            data: null, render: function (data, type, row, meta) {
                                var maritalStatus = "";
                                if (row.t_matr == 1) {
                                    maritalStatus = "Unmarried";
                                    return '<div' + maritalStatus + '" class="badge bg-danger">' + maritalStatus + '</div>';
                                }
                                else if (row.t_matr == 2) {
                                    maritalStatus = "Married";
                                    return '<div' + maritalStatus + '" class="badge bg-success">' + maritalStatus + '</div>';
                                }
                                else if (row.t_matr == 3) {
                                    maritalStatus = "Widow";
                                    return '<div' + maritalStatus + '" class="badge bg-success">' + maritalStatus + '</div>';
                                }
                                else {
                                    maritalStatus = "Divorced";
                                    return '<div' + maritalStatus + '" class="badge bg-success">' + maritalStatus + '</div>';
                                }
                            }
                        },
                        { "data": "t_datm", "name": "Date of Marriage" },
                        { "data": "t_mobl", "name": "Mobile No." },
                        { "data": "t_emmo", "name": "Emergency Mobile No" },
                        { "data": "t_emai", "name": "Email" },
                        { "data": "t_reli", "name": "Religion" },
                        { "data": "t_cast", "name": "Cast" },
                        { "data": "t_motl", "name": "Mother Tongue" },
                        {
                            data: null, render: function (data, type, row, meta) {
                                var employeeytypeStatus = "";
                                if (row.t_etyp == 1) {
                                    employeeytypeStatus = "Fresher";
                                    return '<div' + employeeytypeStatus + '" class="badge bg-danger">' + employeeytypeStatus + '</div>';
                                }
                                else {
                                    employeeytypeStatus = "Experienced";
                                    return '<div' + employeeytypeStatus + '" class="badge bg-success">' + employeeytypeStatus + '</div>';
                                }
                            }
                        },
                        { "data": "t_woex", "name": "Total work experience" },
                        { "data": "t_esic", "name": "ESIC Code" },
                        { "data": "t_uanc", "name": "UAN Number" },
                        { "data": "t_bano", "name": "Bank Account" },
                        { "data": "t_bank", "name": "Bank Name" },
                        { "data": "t_ifsc", "name": "IFSC Code" },

                    ]
                }).buttons().container().appendTo('#tblBasicdetails_wrapper .col-md-6:eq(0)');
            }
            else {
                toastr.warning('This candidate only registered his/her profile,not fill application form....!!!');
            }
        }
    });

};
function ViewImg(ImgPath) {

    //document.getElementById("preview").src = ImgPath.substring(1, 50);
    //var NewImagePath = ImgPath.substring(1, 50);
    document.getElementById("preview").src = ImgPath;
    var NewImagePath = ImgPath;
    // jQuery to archive this,
    $("#preview").attr("src", ('' + NewImagePath + ''));
    document.getElementById('preview').style.display = 'block'
    $('#myModalImage').modal('show');

}
function BindFamilyDetail() {

    var table = $('#tblfamilydetails').DataTable();
    table
        .clear()
        .draw();
    destroy: true,
        table.destroy();
    var EmpId = $('#txtemployeeID').val();

    $.ajax({
        url: "../Adminpanel/BindFamilyInfo",
        type: "POST",
        data: '{t_emno :"' + EmpId + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (data.length > 0) {

            }
            var datatableVariable = $('#tblfamilydetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "bDestroy": true,
                "buttons": ["excel", "pdf", "print"],
                data: data,

                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_rela", "name": "Relation" },
                    { "data": "t_nama", "name": "Member Name" },
                    {

                        data: null, render: function (data, type, row, meta) {
                            var dobStatus = "";
                            if (row.t_dobt == '01-01-1900') {
                                dobStatus = "NA";
                                return '<div' + dobStatus + '" class="badge bg-danger">' + dobStatus + '</div>';
                            }
                            else {
                                dobStatus = row.t_dobt;
                                return '<div' + dobStatus + '" class="badge bg-success">' + dobStatus + '</div>';
                            }

                        }
                    },
                    //{ "data": "t_dobt", "name": "Member DOB" },
                    { "data": "t_mema", "name": "Member Mobile No." },
                    { "data": "t_mmob", "name": "Member Email" },
                    //{
                    //    "title": "Action", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick="return getbyFamilyDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="FamilyMemDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                    //    }
                    //},

                ]
            }).buttons().container().appendTo('#tblfamilydetails_wrapper .col-md-6:eq(0)');

        }
    });

};
function BindEducationDetail() {

    var table = $('#tbleducationdetails').DataTable();
    table
        .clear()
        .draw();
    destroy: true,
        table.destroy();

    var EmpId = $('#txtemployeeID').val();
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Adminpanel/BindEducationDetails",
        data: '{t_emno :"' + EmpId + '"}',
        success: function (data) {
            if (data.length > 0) {

            }
            var datatableVariable = $('#tbleducationdetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "bDestroy": true,
                "buttons": ["excel", "pdf", "print"],
                data: data,

                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_educ", "name": "Education" },
                    { "data": "t_boar", "name": "Board" },
                    { "data": "t_poyr", "name": "Passing Out Year" },
                    { "data": "t_scmd", "name": "School Medium" },
                    { "data": "t_crse", "name": "Course" },
                    { "data": "t_spec", "name": "Specialization" },
                    { "data": "t_univ", "name": "University/Institute" },
                    { "data": "t_coty", "name": "Course Type" },
                    { "data": "t_totm", "name": "Total Percentage" },
                    //{
                    //    "title": "Image", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick = "return ViewImg(\'' + row.t_ecpa + '\')" ><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_ecpa + '" width="50" height="50"></li ></a>'
                    //    }

                    //},
                    {
                        data: null, render: function (data, type, row, meta) {
                            return '<a href="' + row.t_ecpa + '" <i class="fas fa-download badge bg-primary" download></i>Download File</a>'
                        }
                    },
                    //{
                    //    "title": "Action", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick="return getbyEducationDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="EducationDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                    //    }
                    //},

                ]
            }).buttons().container().appendTo('#tbleducationdetails_wrapper .col-md-6:eq(0)');

        }
    });

};

function BindDocumentDetail() {

    var table = $('#tbldocumentdetails').DataTable();
    table
        .clear()
        .draw();
    destroy: true,
        table.destroy();
    var EmpId = $('#txtemployeeID').val();

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Adminpanel/BindDocumentDetails",
        data: '{t_emno :"' + EmpId + '"}',
        success: function (data) {
            if (data.length > 0) {

            }
            var datatableVariable = $('#tbldocumentdetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "bDestroy": true,
                "buttons": ["excel", "pdf", "print"],

                data: data,

                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_dtyp", "name": "Document Type" },
                    { "data": "t_docm", "name": "Document No" },

                    //{
                    //    "title": "Image", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick = "return ViewImgDoc(\'' + row.t_dpat + '\')" ><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_dpat + '" width="50" height="50"></li ></a>'
                    //    }

                    //},
                    {
                        data: null, render: function (data, type, row, meta) {
                            return '<a href="' + row.t_dpat + '" <i class="fas fa-download badge bg-primary" download></i>Download File</a>'
                            //<img src="\'' + row.t_path + '\'" alt="" />onclick = "return ViewImg(\'' + row.t_path + '\')"

                        }

                    },
                    //{
                    //    "title": "Action", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick="return getbyDocumenmtDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="DocumentDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                    //    }
                    //},

                ]
            }).buttons().container().appendTo('#tbldocumentdetails_wrapper .col-md-6:eq(0)');

        }
    });

};

function BindCompanyDetails() {

    var table = $('#tblcompanydetails').DataTable();
    table
        .clear()
        .draw();
    destroy: true,
        table.destroy();
    var EmpId = $('#txtemployeeID').val();

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Adminpanel/BindCompanyDetails",
        data: '{t_emno :"' + EmpId + '"}',
        success: function (data) {
            if (data.length > 0) {


            }

            var datatableVariable = $('#tblcompanydetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "bDestroy": true,
                "buttons": ["excel", "pdf", "print"],

                data: data,

                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_orga", "name": "Organization" },
                    { "data": "t_dnam", "name": "Designation" },
                    { "data": "t_expe", "name": "Total Experience" },
                    { "data": "t_cuco", "name": "Current Company" },
                    { "data": "t_year", "name": "From Year" },
                    { "data": "t_mont", "name": "From Month" },
                    { "data": "t_toyr", "name": "To Year" },
                    { "data": "t_tomo", "name": "To Month" },
                    { "data": "t_dyjp", "name": "Job Profile" },
                    //{
                    //    "title": "Image", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick = "return ViewImgCom(\'' + row.t_epat + '\')" ><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_epat + '" width="50" height="50"></li ></a>'
                    //    }

                    //},
                    {
                        data: null, render: function (data, type, row, meta) {
                            return '<a href="' + row.t_epat + '" <i class="fas fa-download badge bg-primary" download></i>Download File</a>'
                            //<img src="\'' + row.t_path + '\'" alt="" />onclick = "return ViewImg(\'' + row.t_path + '\')"

                        }

                    },
                    //{
                    //    "title": "Action", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick="return getbyCompanyDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="CompanyDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                    //    }
                    //},

                ]
            }).buttons().container().appendTo('#tblcompanydetails_wrapper .col-md-6:eq(0)');

        }
    });

};

function BindPayslipDetail() {

    var table = $('#tblpayslipdetails').DataTable();
    table
        .clear()
        .draw();
    destroy: true,
        table.destroy();
    var EmpId = $('#txtemployeeID').val();

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Adminpanel/BindPayslipDetails",
        data: '{t_emno :"' + EmpId + '"}',
        success: function (data) {
            if (data.length > 0) {
            }
            var datatableVariable = $('#tblpayslipdetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "bDestroy": true,
                "buttons": ["excel", "pdf", "print"],

                data: data,
                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_paym", "name": "Payslip Month" },
                    { "data": "t_payy", "name": "Payslip Year" },
                    //{
                    //    "title": "Image", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick = "return ViewImgPay(\'' + row.t_ppat + '\')" ><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_ppat + '" width="50" height="50"></li ></a>'
                    //    }

                    //},
                    {
                        data: null, render: function (data, type, row, meta) {
                            return '<a href="' + row.t_ppat + '" <i class="fas fa-download badge bg-primary" download></i>Download File</a>'
                            //<img src="\'' + row.t_path + '\'" alt="" />onclick = "return ViewImg(\'' + row.t_path + '\')"

                        }

                    },
                    //{
                    //    "title": "Action", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick="return getbyPayslipDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="PayslipDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                    //    }
                    //},

                ]
            }).buttons().container().appendTo('#tblpayslipdetails_wrapper .col-md-6:eq(0)');

        }
    });

};
function BindReferenceDetail() {

    var table = $('#tblreferanancedetails').DataTable();
    table
        .clear()
        .draw();
    destroy: true,
        table.destroy();
    var EmpId = $('#txtemployeeID').val();

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Adminpanel/BindReferenceDetails",
        data: '{t_emno :"' + EmpId + '"}',
        success: function (data) {
            if (data.length > 0) {

            }

            var datatableVariable = $('#tblreferanancedetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "bDestroy": true,
                "buttons": ["excel", "pdf", "print"],

                data: data,
                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_rnam", "name": "Reference name" },
                    { "data": "t_phon", "name": "Reference phone no" },

                    //{
                    //    "title": "Action", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick="return getbyReferenceDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="ReferenceDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                    //    }
                    //},

                ]
            }).buttons().container().appendTo('#tblreferanancedetails_wrapper .col-md-6:eq(0)');

        }
    });

};
function BindCertificationDetail() {

    var table = $('#tblcertificationdetails').DataTable();
    table
        .clear()
        .draw();
    destroy: true,
        table.destroy();
    var EmpId = $('#txtemployeeID').val();

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Adminpanel/BindCertificationDetails",
        data: '{t_emno :"' + EmpId + '"}',
        success: function (data) {
            if (data.length > 0) {

            }
            var datatableVariable = $('#tblcertificationdetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "bDestroy": true,
                "buttons": ["excel", "pdf", "print"],
                data: data,
                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_cnam", "name": "Certification name" },
                    { "data": "t_cema", "name": "Certification Marks" },
                    //{
                    //    "title": "Image", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick = "return ViewImgCer(\'' + row.t_cpat + '\')" ><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_cpat + '" width="50" height="50"></li ></a>'
                    //    }

                    //},
                    {
                        data: null, render: function (data, type, row, meta) {
                            return '<a href="' + row.t_cpat + '" <i class="fas fa-download badge bg-primary" download></i>Download File</a>'
                            //<img src="\'' + row.t_path + '\'" alt="" />onclick = "return ViewImg(\'' + row.t_path + '\')"

                        }

                    },
                    //{
                    //    "title": "Action", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick="return getbyCertificationDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="CertificationDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                    //    }
                    //},

                ]
            }).buttons().container().appendTo('#tblcertificationdetails_wrapper .col-md-6:eq(0)');

        }
    });

};
//function BindEmployeeName() {


//}

function ViewImg(ImgPath) {

    //document.getElementById("preview").src = ImgPath.substring(1, 50);
    //var NewImagePath = ImgPath.substring(1, 50);
    document.getElementById("preview").src = ImgPath;
    var NewImagePath = ImgPath;
    // jQuery to archive this,
    $("#preview").attr("src", ('' + NewImagePath + ''));
    document.getElementById('preview').style.display = 'block'
    $('#myModalImage').modal('show');

}

function FormatJsonDate(jsonDate) {
    var num = jsonDate.match(/\d+/g); //regex to extract numbers 
    var date = new Date(parseFloat(num)); //converting to date
    return (date.getDate() + "-" + (date.getMonth() + 1) + '-' + date.getFullYear());
}
