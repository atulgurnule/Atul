﻿//Load Data in Table when documents is ready  
$(document).ready(function () {
  
    $("#txtPassword2").keyup(passwordvalidate);
});
function passwordvalidate() {
    var password1 = $("#txtPassword1").val();
    var password2 = $("#txtPassword2").val();



    if (password1 == password2) {
        $("#validate-status").text("Valid");
    }
    else {
        $("#validate-status").text("Invalid");
        toastr.warning('The password and confirmation password do not match.');
    }

}



//Load Data function  
function loadData() {
    $.ajax({
        url: "/Employee/List",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            var html = '';
            $.each(result, function (key, item) {
                html += '<tr>';
                html += '<td>' + item.EmployeeID + '</td>';
                html += '<td>' + item.EmployeeName + '</td>';
                html += '<td>' + item.Age + '</td>';
                html += '<td>' + item.State + '</td>';
                html += '<td>' + item.Country + '</td>';
                html += '<td><a href="#" onclick="return getbyID(' + item.EmployeeID + ')">Edit</a> | <a href="#" onclick="Delele(' + item.EmployeeID + ')">Delete</a></td>';
                html += '</tr>';
            });
            $('.tbody').html(html);
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

/
//Function for getting the Data Based upon Employee ID  
function getbyID(EmpID) {
    $('#EmployeeName').css('border-color', 'lightgrey');
    $('#Age').css('border-color', 'lightgrey');
    $('#State').css('border-color', 'lightgrey');
    $('#Country').css('border-color', 'lightgrey');
    $.ajax({
        url: "/Employee/getbyID/" + EmpID,
        typr: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (result) {
            $('#EmployeeID').val(result.EmployeeID);
            $('#EmployeeName').val(result.EmployeeName);
            $('#Age').val(result.Age);
            $('#State').val(result.State);
            $('#Country').val(result.Country);

            $('#myModal').modal('show');
            $('#btnUpdate').show();
            $('#btnAdd').hide();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}

//function for updating employee's record  
function Update() {
    var res = validate();
    if (res == false) {
        return false;
    }
    var empObj = {
        EmployeeID: $('#EmployeeID').val(),
        EmployeeName: $('#EmployeeName').val(),
        Age: $('#Age').val(),
        State: $('#State').val(),
        Country: $('#Country').val(),
    };
    $.ajax({
        url: "/Employee/Update",
        data: JSON.stringify(empObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            loadData();
            $('#myModal').modal('hide');
            $('#EmployeeID').val("");
            $('#EmployeeName').val("");
            $('#Age').val("");
            $('#State').val("");
            $('#Country').val("");
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

//function for deleting employee's record  
function Delele(ID) {
    var ans = confirm("Are you sure you want to delete this Record?");
    if (ans) {
        $.ajax({
            url: "/Employee/Delete/" + ID,
            type: "POST",
            contentType: "application/json;charset=UTF-8",
            dataType: "json",
            success: function (result) {
                loadData();
            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
    }
}

//Function for clearing the textboxes  
function clearTextBox() {
    $('#EmployeeID').val("");
    $('#EmployeeName').val("");
    $('#Age').val("");
    $('#State').val("");
    $('#Country').val("");
    $('#btnUpdate').hide();
    $('#btnAdd').show();
    $('#EmployeeName').css('border-color', 'lightgrey');
    $('#Age').css('border-color', 'lightgrey');
    $('#State').css('border-color', 'lightgrey');
    $('#Country').css('border-color', 'lightgrey');
}
//Valdidation using jquery  
function validate() {
    var isValid = true;
    if ($('#txtfullname').val().trim() == "") {
        $('#txtfullname').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#txtfullname').css('border-color', 'lightgrey');
    }
    if ($('#txtEmail').val().trim() == "") {
        $('#txtEmail').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#txtEmail').css('border-color', 'lightgrey');
    }
    if ($('#txtMobileNo').val().trim() == "") {
        $('#txtMobileNo').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#txtMobileNo').css('border-color', 'lightgrey');
    }
    if ($('#txtPassword1').val().trim() == "") {
        $('#txtPassword1').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#txtPassword1').css('border-color', 'lightgrey');
    }
    if ($('#txtPassword2').val().trim() == "") {
        $('#txtPassword2').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#txtPassword2').css('border-color', 'lightgrey');
    }
    return isValid;
}  