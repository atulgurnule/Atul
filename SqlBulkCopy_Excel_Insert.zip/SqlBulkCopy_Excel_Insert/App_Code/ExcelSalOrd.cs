﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ExcelSalOrd
/// </summary>
public class ExcelSalOrd
{
    //public ExcelSalOrd()
    //{
        //
        // TODO: Add constructor logic here
        //
         public string t_orno { get; set; }
         public string t_btno{ get; set; }
         public DateTime t_btdt { get; set; }
   
        //}
}