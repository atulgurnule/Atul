﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Net;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.Configuration;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.Script.Services;
using System.Data.OleDb;

namespace HumanResourceManagement.Models
{
    public class AddExcelCSVFile
    {
        private string message = string.Empty;
        public string[] saveInputCSV(ttiswc120100CSV[] prodPlanList)
        {

            string i_msg;
            i_msg = "";
            string t_osdt = string.Empty;
            string t_odue = string.Empty;
            string[] output = new string[] { "", "" };
            NBDataAccess NBData = new NBDataAccess();
            NBDataAccess.ErrorAttributes objErr = new NBDataAccess.ErrorAttributes();
            int recordCount = 0;
            foreach (ttiswc120100CSV record in prodPlanList)
            {
                SqlCommand sqlcom = new SqlCommand();

                sqlcom.CommandType = CommandType.StoredProcedure;
                //INSERT record
                //if (prodPlanList[recordCount].t_pdno == "")
                //{
                //  sqlcom.Parameters.AddWithValue("@t_pdno", null);
                //}
                //else
                //{
                //  sqlcom.Parameters.AddWithValue("@t_pdno", prodPlanList[recordCount].t_pdno);
                //}

                sqlcom.Parameters.AddWithValue("@t_mitm", prodPlanList[recordCount].t_mitm);
                //sqlcom.Parameters.AddWithValue("@t_mqty", prodPlanList[recordCount].t_mqty);
                sqlcom.Parameters.AddWithValue("@t_pnam", prodPlanList[recordCount].t_pnam);
                sqlcom.Parameters.AddWithValue("@t_finl", prodPlanList[recordCount].t_finl);
                sqlcom.Parameters.AddWithValue("@t_finb", prodPlanList[recordCount].t_finb);
                sqlcom.Parameters.AddWithValue("@t_fint", prodPlanList[recordCount].t_fint);
                sqlcom.Parameters.AddWithValue("@t_pqty", prodPlanList[recordCount].t_pqty);
                sqlcom.Parameters.AddWithValue("@t_pitm", prodPlanList[recordCount].t_pitm);
                sqlcom.Parameters.AddWithValue("@t_brc1", prodPlanList[recordCount].t_brc1);
                sqlcom.Parameters.AddWithValue("@t_brc2", prodPlanList[recordCount].t_brc2);
                sqlcom.Parameters.AddWithValue("@t_parm", prodPlanList[recordCount].t_parm);
                sqlcom.Parameters.AddWithValue("@t_srft", prodPlanList[recordCount].t_srft);
                sqlcom.Parameters.AddWithValue("@t_srfb", prodPlanList[recordCount].t_srfb);
                sqlcom.Parameters.AddWithValue("@t_ebth", prodPlanList[recordCount].t_ebth);
                sqlcom.Parameters.AddWithValue("@t_ebbt", prodPlanList[recordCount].t_ebbt);
                sqlcom.Parameters.AddWithValue("@t_ebrt", prodPlanList[recordCount].t_ebrt);
                sqlcom.Parameters.AddWithValue("@t_edtp", prodPlanList[recordCount].t_edtp);
                sqlcom.Parameters.AddWithValue("@t_edlf", prodPlanList[recordCount].t_edlf);
                sqlcom.Parameters.AddWithValue("@t_gran", prodPlanList[recordCount].t_gran);
                sqlcom.Parameters.AddWithValue("@t_gdsc", prodPlanList[recordCount].t_gdsc);
                sqlcom.Parameters.AddWithValue("@t_grnp", prodPlanList[recordCount].t_grnp);
                sqlcom.Parameters.AddWithValue("@t_cutl", prodPlanList[recordCount].t_cutl);
                sqlcom.Parameters.AddWithValue("@t_cutb", prodPlanList[recordCount].t_cutb);
                sqlcom.Parameters.AddWithValue("@t_cutt", prodPlanList[recordCount].t_cutt);
                sqlcom.Parameters.AddWithValue("@t_grph", prodPlanList[recordCount].t_grph);
                sqlcom.Parameters.AddWithValue("@t_drln", prodPlanList[recordCount].t_drln);
                sqlcom.Parameters.AddWithValue("@t_crcs", prodPlanList[recordCount].t_crcs);
                sqlcom.Parameters.AddWithValue("@t_venm", prodPlanList[recordCount].t_venm);
                sqlcom.Parameters.AddWithValue("@t_mpid", prodPlanList[recordCount].t_mpid);
                sqlcom.Parameters.AddWithValue("@t_anno", prodPlanList[recordCount].t_anno);
                sqlcom.Parameters.AddWithValue("@t_oref", prodPlanList[recordCount].t_oref);
                sqlcom.Parameters.AddWithValue("@t_orno", prodPlanList[recordCount].t_orno);
                //sqlcom.Parameters.AddWithValue("@t_skuc", prodPlanList[recordCount].t_skuc);
                sqlcom.Parameters.AddWithValue("@t_skuc", "");

                if (prodPlanList[recordCount].t_osdt == "-")
                {
                    t_osdt = "1970-01-01";
                }
                else
                {
                    t_osdt = (prodPlanList[recordCount].t_osdt);
                }

                sqlcom.Parameters.AddWithValue("@t_osdt", t_osdt);

                if (prodPlanList[recordCount].t_odue == "-")
                {
                    t_odue = "1970-01-01";
                }
                else
                {
                    t_odue = prodPlanList[recordCount].t_odue;
                }
                sqlcom.Parameters.AddWithValue("@t_odue", t_odue);
                sqlcom.Parameters.AddWithValue("@t_bpid", prodPlanList[recordCount].t_bpid);
                sqlcom.Parameters.AddWithValue("@t_htyp", prodPlanList[recordCount].t_htyp);
                sqlcom.Parameters.AddWithValue("@t_vhng", prodPlanList[recordCount].t_vhng);
                sqlcom.Parameters.AddWithValue("@t_room", prodPlanList[recordCount].t_room);
                sqlcom.Parameters.AddWithValue("@t_pcnt", prodPlanList[recordCount].t_pcnt);
                sqlcom.Parameters.AddWithValue("@t_shds", prodPlanList[recordCount].t_shds);
                sqlcom.Parameters.AddWithValue("@t_des1", prodPlanList[recordCount].t_des1);
                sqlcom.Parameters.AddWithValue("@t_hsde", prodPlanList[recordCount].t_hsde);
                sqlcom.Parameters.AddWithValue("@t_btno", prodPlanList[recordCount].t_btno);
                sqlcom.Parameters.AddWithValue("@t_wght", prodPlanList[recordCount].t_wght);
                sqlcom.Parameters.AddWithValue("@t_opro", prodPlanList[recordCount].t_opro);
                sqlcom.Parameters.AddWithValue("@t_lyno", prodPlanList[recordCount].t_lyno);
                sqlcom.Parameters.AddWithValue("@t_crte", prodPlanList[recordCount].t_crte);
                sqlcom.Parameters.AddWithValue("@t_pack", prodPlanList[recordCount].t_pack);
                sqlcom.Parameters.AddWithValue("@t_ptyp", prodPlanList[recordCount].t_ptyp);

                sqlcom.Parameters.AddWithValue("@Action", 'I');
                sqlcom.Parameters.Add("@message", SqlDbType.VarChar, 500);
                sqlcom.Parameters["@message"].Direction = ParameterDirection.Output;
                sqlcom.CommandText = "testdb.dbo.[PMS_LoadCSVProductionPlan_New]";

                string result = "", msg1 = "";
                try
                {

                    result = NBData.ExecuteCommand(sqlcom, ref objErr);
                    i_msg = (string)sqlcom.Parameters["@message"].Value.ToString();

                    msg1 = result;

                    string comb = i_msg;
                    output = comb.Split(',');
                    //output = comb.ToString();
                    if (result == "success")
                    {
                        //return output;
                    }
                    else
                    {
                        string comb1 = result;
                        output = comb1.Split(',');
                        //return output;
                    }
                }
                catch (Exception ex)
                {
                    result = ex.Message;
                    //return output;
                }

                recordCount++;
                sqlcom.Dispose();

            }
            return output;
        }
        public  List<ttiswc120100CSV> GetProductionPlan()
        {

            string constr = ConfigurationManager.ConnectionStrings["SqlConn"].ConnectionString;
            try
            {
                List<ttiswc120100CSV> prdLst = new List<ttiswc120100CSV>();

                using (SqlConnection con = new SqlConnection(constr))
                {

                    con.Open();
                    SqlCommand comm = new SqlCommand("testdb.dbo.[PMS_LoadCSVProductionPlan_New]", con);
                    comm.CommandType = CommandType.StoredProcedure;
                    comm.Parameters.AddWithValue("@Action", "S");
                    comm.Parameters.Add("@message", SqlDbType.VarChar, 500);
                    comm.Parameters["@message"].Direction = ParameterDirection.Output;

                    //comm.Parameters.Add(new SqlParameter("@t_orno", SalOrd));
                    SqlDataReader sdr = comm.ExecuteReader();
                    while (sdr.Read())
                    {
                        prdLst.Add(new ttiswc120100CSV
                        {
                            t_link = sdr["t_link"].ToString(),
                            t_orno = sdr["t_orno"].ToString(),
                            t_btno = sdr["t_btno"].ToString(),


                        });
                    }
                    con.Close();
                    message = (string)comm.Parameters["@message"].Value.ToString();
                    return prdLst;
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }

        }
    }
}