﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Data;
using System.Net;
using System.IO;
using HumanResourceManagement.Models;

namespace HumanResourceManagement.Controllers
{
    public class UploadExcelController : Controller
    {
        AddExcelCSVFile addExcel = new AddExcelCSVFile();
        // GET: UploadExcel
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult saveInputCSV(ttiswc120100CSV[] prodPlanList)
        {
            //_salOrd.t_logn = Convert.ToString(Session["uname"]);
            return Json(addExcel.saveInputCSV(prodPlanList), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult  GetProductionPlan()
        {
            return Json(addExcel.GetProductionPlan(), JsonRequestBehavior.AllowGet);

        }

        

    }
}