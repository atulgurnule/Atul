﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HumanResourceManagement.Models
{
    public class ttiswc120100CSV
    {
        public string t_link { get; set; }
        public string t_pdno { get; set; }
        public string t_pnam { get; set; }
        public float t_finl { get; set; }
        public float t_finb { get; set; }
        public float t_fint { get; set; }
        public float t_pqty { get; set; }
        public string t_pitm { get; set; }
        public string t_brc1 { get; set; }
        public string t_brc2 { get; set; }
        public string t_parm { get; set; }
        public string t_srft { get; set; }
        public string t_srfb { get; set; }
        public string t_ebth { get; set; }
        public string t_ebbt { get; set; }
        public string t_ebrt { get; set; }
        public string t_edtp { get; set; }
        public string t_edlf { get; set; }
        public string t_gran { get; set; }
        public string t_gdsc { get; set; }
        public string t_grnp { get; set; }
        public float t_cutl { get; set; }
        public float t_cutb { get; set; }
        public float t_cutt { get; set; }
        public string t_grph { get; set; }
        public string t_drln { get; set; }
        public string t_crcs { get; set; }
        public string t_venm { get; set; }
        public int t_mpid { get; set; }
        public string t_anno { get; set; }
        public string t_oref { get; set; }
        public string t_orno { get; set; }
        public string t_skuc { get; set; }
        public string t_osdt { get; set; }
        public string t_odue { get; set; }
        public string t_bpid { get; set; }
        public string t_htyp { get; set; }
        public string t_vhng { get; set; }
        public string t_room { get; set; }
        public int t_pcnt { get; set; }
        public string t_shds { get; set; }
        public string t_des1 { get; set; }
        public string t_hsde { get; set; }
        public string t_btno { get; set; }
        public float t_wght { get; set; }
        public string t_opro { get; set; }
        public string t_lyno { get; set; }
        public string t_crte { get; set; }
        public string t_pack { get; set; }
        public int t_ptyp { get; set; }
        public string t_mitm { get; set; }
    }
}