﻿//Load Data in Table when documents is ready  
var detailempid;
$(document).ready(function () {

    //var detailempid = '<%= Session["empid"] %>';
    //if (detailempid == "") {

    //    window.location.href = '/Home/Index';
    //}

    //Important Code

    //var enabled = [];
    //var disabled = [];
    //enabled = $('#hfEnabled').val().split(',').map(Number);
    //if ($('#hfDisabled').val() != '') {
    //    disabled = $('#hfDisabled').val().split(',').map(Number);
    //    $("#tabs").tabs({ active: $('#hfEnabled').val(), disabled: disabled });

    //}

    $("#divLoader").show();

    BindState();
    BindAllBank();

    checkMaritalStatus();
    loadPayslipYear();
    loadEduPassingOutYear();
    loadFromYear();
    loadToYear();
    // Added getbyBasicDetails(detailempid) function in BindAllBank() function
    //if (detailempid != "") {
    //    getbyBasicDetails(detailempid);
    //}

    BindFamilyDetail();
    BindEducationDetail();
    BindDocumentDetail();
    BindCompanyDetails();
    BindPayslipDetail();
    BindReferenceDetail();
    BindCertificationDetail();


    //getbyTabExistStatus();
    getbyTabNotExistStatus();

    $("#ddlEmployeeType").change(function () {
        // checkMaritalStatus();
        var EmployeeType = $("#ddlEmployeeType option:selected").text();
        if (EmployeeType == "Fresher") {
            $("#btnpreviouscompanyadd").attr("disabled", "disabled");
            $("#btnaddpayslip").attr("disabled", "disabled");
            $("#ddltotalworkexp").val(0);
            $("#ddltotalworkexp").attr("disabled", "disabled");
        } else {

            $("#btnpreviouscompanyadd").removeAttr("disabled");
            $("#btnaddpayslip").removeAttr("disabled");
            $("#ddltotalworkexp").removeAttr("disabled");
        }
    });
    $("#divLoader").hide();

});


function BindState() {
    $.ajax({
        type: "POST",
        url: "../Employee/BindState",
        //data: '{t_cste :"' + ddlstate + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {

            if (response != null) {

                $("#ddlstate").empty();
                var ddlstate = $("#ddlstate");
                ddlstate.empty().append('<option selected="selected" value="0">--Select--</option>');
                $.each(response, function (key, value) {
                    $("#ddlstate").append($("<option></option>").val(value.t_cste).html(value.t_dsca));
                });
            }

        },
        error: function (response) {
            alert(response.responseText);
        }
    });

}
function BindAllBank() {

    $.ajax({
        type: "POST",
        url: "../Employee/BindBank",
        //data: '{t_cste :"' + ddlstate + '"}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {

            if (response != null) {

                $("#ddlbank").empty();

                var ddlbank = $("#ddlbank");
                ddlbank.empty().append('<option selected="selected" value="0">--Select--</option>');
                $.each(response, function (key, value) {
                    $("#ddlbank").append($("<option></option>").val(value.t_bano).html(value.t_bnam));
                });
                if (detailempid != "") {
                    getbyBasicDetails(detailempid);
                }

            }
        },
        error: function (response) {
            alert(response.responseText);
        }
    });
}

function getbyTabNotExistStatus() {

    $("#divLoader").show();
    $.ajax({
        url: "../Employee/CheckNotExistForTab",
        //data: '{t_emno :"' + detailempid + '"}',
        //data: { t_emno: detailempid},
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {


            //$('#ddlact').empty();
            var result = data;
            if (result == 'BASICNOTEXIST') {
                var enabled = 0;
                var disabled = [1, 2, 3, 4, 5, 6, 7];
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                $('#custom-tabs-basic').addClass('active');
                $('#custom-basic').addClass('active show');
                $("#divLoader").hide();
                //if (result == 'BASICNOTEXIST') {
                //    $('#btnBasicDetails').show();
                //    $('#btnBasicDetailsUpdate').hide();
                //}
                //else {
                //    $('#btnBasicDetailsUpdate').show();
                //    $('#btnBasicDetails').hide();
                //}

            }
            else if (result == 'FAMILYNOTEXIST') {

                var enabled = 1;
                //var disabled = [0, 2, 3, 4, 5, 6, 7];
                var disabled = [2, 3, 4, 5, 6, 7];
                $("#tabs").tabs({ active: enabled, disabled: disabled });

                $('#custom-tabs-basic').removeClass('active');
                $('#custom-basic').removeClass('active show');
                $('#custom-tabs-family').addClass('active');
                $('#custom-family').addClass('active show');
                $("#divLoader").hide();
                //if (result == 'FAMILYNOTEXIST') {
                //    $('#btnAddFamily').show();
                //    $('#btnUpdateFamily').hide();
                //    $('#btnBasicDetailsUpdate').show();
                //    $('#btnBasicDetails').hide();
                //}
                //else {
                //    $('#btnUpdateFamily').show();
                //    $('#btnAddFamily').hide();
                //}
            }
            else if (result == 'EDUCATIONNOTEXIST') {
                var enabled = 2;
                //var disabled = [0, 1, 3, 4, 5, 6, 7];
                var disabled = [3, 4, 5, 6, 7];
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-basic').removeClass('active');
                //$('#custom-tabs-family').removeClass('active');
                //$('#custom-tabs-education').addClass('active show');
                $('#custom-tabs-family').removeClass('active');
                $('#custom-family').removeClass('active show');
                $('#custom-tabs-education').addClass('active');
                $('#custom-education').addClass('active show');
                $("#divLoader").hide();
                //if (result == 'EDUCATIONNOTEXIST') {
                //    $('#btnInsertEducation').show();
                //    $('#btnUpdateEducation').hide();
                //}
                //else {
                //    $('#btnUpdateEducation').show();
                //    $('#btnInsertEducation').hide();
                //}
            }
            else if (result == 'DOCUMENTNOTEXIST') {

                var enabled = 3;
                //var disabled = [0, 1, 2, 4, 5, 6, 7];
                var disabled = [4, 5, 6, 7];
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-education').removeClass('active');
                $('#custom-education').removeClass('active show');
                $('#custom-tabs-document').addClass('active');
                $('#custom-document').addClass('active show');
                $("#divLoader").hide();
                //if (result == 'DOCUMENTNOTEXIST') {
                //    $('#btnInsertDocument').show();
                //    $('#btnUpdateDocument').hide();
                //}
                //else {
                //    $('#btnUpdateDocument').show();
                //    $('#btnInsertDocument').hide();
                //}
            }
            else if (result == 'COMPANYNOTEXIST') {

                var EmployeeType = $("#ddlEmployeeType option:selected").text();
                if (EmployeeType == "Fresher") {
                    $("#btnpreviouscompanyadd").attr("disabled", "disabled");
                    $("#btnaddpayslip").attr("disabled", "disabled");
                    var enabled = 6;
                    //var disabled = [0, 1, 2, 3, 4, 5, 7];
                    var disabled = [4, 5, 7];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });
                    //$('#custom-tabs-payslip').removeClass('active');
                    //$('#custom-tabs-basic').removeClass('active');
                    //$('#custom-tabs-reference').addClass('active show');
                    $('#custom-tabs-document').removeClass('active');
                    $('#custom-document').removeClass('active show');
                    $('#custom-tabs-reference').addClass('active');
                    $('#custom-reference').addClass('active show');
                    $("#divLoader").hide();

                }
                else if ((EmployeeType == "Experienced")) {

                    $("#btnpreviouscompanyadd").removeAttr("disabled");
                    $("#btnaddpayslip").removeAttr("disabled");
                    var enabled = 4;
                    //var disabled = [0, 1, 2, 3, 5, 6, 7];
                    var disabled = [5, 6, 7];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });

                    $('#custom-tabs-document').removeClass('active');
                    $('#custom-document').removeClass('active show');
                    $('#custom-tabs-previous-company').addClass('active');
                    $('#custom-previous-company').addClass('active show');
                    $("#divLoader").hide();
                }
                //else {
                //var enabled = 4;
                //var disabled = [0, 1, 2, 3, 5, 6, 7];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').addClass('active show');
                //}
                //if (result == 'COMPANYNOTEXIST') {
                //    $('#btncompanysubmit').show();
                //    $('#btncompanyupdate').hide();
                //}
                //else {
                //    $('#btncompanyupdate').show();
                //    $('#btncompanysubmit').hide();
                //}
            }
            else if (result == 'PAYSLIPNOTEXIST') {
                var enabled = 5;
                //var disabled = [0, 1, 2, 3, 4, 6, 7];
                var disabled = [6, 7];
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-previous-company').removeClass('active');
                $('#custom-previous-company').removeClass('active show');
                $('#custom-tabs-payslip').addClass('active');
                $('#custom-payslip').addClass('active show');
                $("#divLoader").hide();
                //$('#custom-tabs-basic').removeClass('active');
                //$('#custom-tabs-family').removeClass('active');
                //$('#custom-tabs-education').removeClass('active');
                //$('#custom-tabs-document').removeClass('active');
                //$('#custom-tabs-previous-company').removeClass('active');
                //$('#custom-tabs-payslip').addClass('active show');
                //if (result == 'PAYSLIPNOTEXIST') {
                //    $('#btnPayslipsubmit').show();
                //    $('#btnPayslipupdate').hide();
                //}
                //else {
                //    $('#btnPayslipupdate').show();
                //    $('#btnPayslipsubmit').hide();
                //}
            }
            else if (result == 'REFERENCENOTEXIST') {
                var enabled = 6;
                //var disabled = [0, 1, 2, 3, 4, 5, 7];
                var disabled = [7];
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-payslip').removeClass('active');
                $('#custom-payslip').removeClass('active show');
                $('#custom-tabs-reference').addClass('active');
                $('#custom-reference').addClass('active show');
                $("#divLoader").hide();
                //$('#custom-tabs-basic').removeClass('active');
                //$('#custom-tabs-family').removeClass('active');
                //$('#custom-tabs-education').removeClass('active');
                //$('#custom-tabs-document').removeClass('active');
                //$('#custom-tabs-previous-company').removeClass('active');
                //$('#custom-tabs-payslip').removeClass('active');
                //$('#custom-tabs-reference').addClass('active show');

                //if (result == 'REFERENCENOTEXIST') {
                //    $('#btnreferencesubmit').show();
                //    $('#btnreferenceupdate').hide();
                //}
                //else {
                //    $('#btnreferenceupdate').show();
                //    $('#btnreferencesubmit').hide();
                //}
            }
            //else if (result == 'CERTIFICATIONNOTEXIST') {
            //    var enabled = 7;
            //    //var disabled = [0, 1, 2, 3, 4, 5, 6];
            //    var disabled = [];
            //    $("#tabs").tabs({ active: enabled, disabled: disabled });
            //    $('#custom-tabs-reference').removeClass('active');
            //    $('#custom-reference').removeClass('active show');
            //    $('#custom-tabs-certification').addClass('active');
            //    $('#custom-certification').addClass('active show');
            //    $("#divLoader").hide();
            //    //$('#custom-tabs-basic').removeClass('active');
            //    //$('#custom-tabs-family').removeClass('active');
            //    //$('#custom-tabs-education').removeClass('active');
            //    //$('#custom-tabs-document').removeClass('active');
            //    //$('#custom-tabs-previous-company').removeClass('active');
            //    //$('#custom-tabs-payslip').removeClass('active');
            //    //$('#custom-tabs-reference').removeClass('active');
            //    //$('#custom-tabs-certification').addClass('active show');
            //    //if (result == 'REFERENCENOTEXIST') {
            //    //    $('#btnfinalsubmit').show();
            //    //    $('#btnfinalupdate').hide();
            //    //}
            //    //else {
            //    //    $('#btnfinalupdate').show();
            //    //    $('#btnfinalsubmit').hide();
            //    //}
            //}

            else if (result == 'ALLEXIST') {
                var enabled = 0;
                //var disabled = [1, 2, 3, 4, 5, 6, 7];
                //var disabled = [];
                //$("#tabs").tabs({ active: enabled, disabled: disabled });

                $("#tabs").tabs({ active: enabled });

                //$('#custom-tabs-family').removeClass('active');
                //$('#custom-tabs-education').removeClass('active');
                //$('#custom-tabs-document').removeClass('active');
                //$('#custom-tabs-previous-company').removeClass('active');
                //$('#custom-tabs-payslip').removeClass('active');
                //$('#custom-tabs-reference').removeClass('active');
                //$('#custom-tabs-certification').removeClass('active');

                $('#custom-tabs-basic').addClass('active');
                $('#custom-basic').addClass('active show');
                $("#divLoader").hide();
                //$('#custom-tabs-family').addClass('active');
                //$('#custom-family').addClass('active show');

                $('#btnBasicDetailsUpdate').show();
                $('#btnBasicDetails').hide();
                toastr.warning('You have already submitted form,If you want any change then update form information.');

            }
            //else {
            //    var enabled = 7;
            //    var disabled = [0, 1, 2, 3, 4, 5, 6];
            //    //var disabled = [];
            //    $("#tabs").tabs({ active: enabled, disabled: disabled });
            //    $('#custom-tabs-three-home').removeClass('active');
            //    $('#custom-tabs-three-profile').removeClass('active');
            //    $('#custom-tabs-three-messages').removeClass('active');
            //    $('#document').removeClass('active');
            //    $('#previous_company_details').removeClass('active');
            //    $('#reference_details').removeClass('active');
            //    $('#certification_details').addClass('active show');
            //    toastr.warning('You have not submitted form,Please submit form if you fill all required tab...!!!');
            //}

        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}

function getbyTabExistStatus() {

    $.ajax({
        url: "../Employee/CheckExistForTab",
        //data: '{t_emno :"' + detailempid + '"}',
        //data: { t_emno: detailempid},
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {

            //$('#ddlact').empty();
            var result = data;

            if (result == 'BASICEXIST') {
                //var enabled = 0;
                //var disabled = [1, 2, 3, 4, 5, 6, 7];
                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                ////$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-home').addClass('active show');
                $('#btnBasicDetailsUpdate').show();
                $('#btnBasicDetails').hide();
            }
            else if (result == 'FAMILYEXIST') {
                $('#btnFamilyUpdate').show();
                $('#btnFamilyAdd').hide();
                //var enabled = 1;
                //var disabled = [0, 2, 3, 4, 5, 6, 7];
                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').addClass('active show');
            }
            else if (result == 'EDUCATIONEXIST') {
                $('#btnUpdateEducation').show();
                $('#btnInsertEducation').hide();
                //var enabled = 2;
                //var disabled = [0, 1, 3, 4, 5, 6, 7];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').addClass('active show');
            }
            else if (result == 'DOCUMENTEXIST') {
                $('#btnUpdateDocument').show();
                $('#btnInsertDocument').hide();
                //var enabled = 3;
                //var disabled = [0, 1, 2, 4, 5, 6, 7];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').addClass('active show');
            }
            else if (result == 'COMPANYEXIST') {
                $('#btncompanyupdate').show();
                $('#btncompanysubmit').hide();
                //var enabled = 4;
                //var disabled = [0, 1, 2, 3, 5, 6, 7];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').addClass('active show');
            }
            else if (result == 'PAYSLIPEXIST') {
                $('#btnPayslipupdate').show();
                $('#btnPayslipsubmit').hide();
                //var enabled = 5;
                //var disabled = [0, 1, 2, 3, 4, 6, 7];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').removeClass('active');
                //$('#payslip_details').addClass('active show');
            }
            else if (result == 'REFERENCEEXIST') {
                $('#btnreferenceupdate').show();
                $('#btnreferencesubmit').hide();
                $('#btnfinalupdate').show();
                $('#btnfinalsubmit').hide();
                //var enabled = 6;
                //var disabled = [0, 1, 2, 3, 4, 5, 7];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').removeClass('active');
                //$('#payslip_details').removeClass('active');
                //$('#reference_details').addClass('active show');
            }
            else if (result == 'CERTIFICATIONEXIST') {
                $('#btnfinalupdate').show();
                $('#btnfinalsubmit').hide();
                //var enabled = 7;
                //var disabled = [0, 1, 2, 3, 4, 5, 6];

                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').removeClass('active');
                //$('#reference_details').removeClass('active');
                //$('#certification_details').addClass('active show');
            }

            else if (result == 'ALLNOTEXIST') {
                $('#btnBasicDetails').show();
                $('#btnBasicDetailsUpdate').hide();
                //var enabled = 0;
                //var disabled = [1, 2, 3, 4, 5, 6, 7];
                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').removeClass('active');
                //$('#reference_details').removeClass('active');
                //$('#certification_details').removeClass('active');
                //$('#custom-tabs-three-home').addClass('active show');
                //toastr.warning('You have already submitted form,If you want any change then update form information...!!!');
            }
            else {
                //var enabled = 7;
                //var disabled = [0, 1, 2, 3, 4, 5, 6];
                //$("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').removeClass('active');
                //$('#custom-tabs-three-messages').removeClass('active');
                //$('#document').removeClass('active');
                //$('#previous_company_details').removeClass('active');
                //$('#reference_details').removeClass('active');
                //$('#certification_details').addClass('active show');
                //toastr.warning('You have not submitted form,Please submit form if you fill all required tab...!!!');
            }

        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}

//function GetStateDesc(txtstate) {

//    var txtstate = '';
//    txtstate = $("#txtstate").val();
//    $.ajax({
//        url: "../Employee/BindStatewise",
//        data: '{t_cste : "' + txtstate + '"}',
//        type: "POST",
//        contentType: "application/json;charset=UTF-8",
//        dataType: "json",
//        success: function (response) {

//            if (response.length === 0) {
//                $("#t_cstedesc").html("");
//                $("#txtstate").val("");
//                toastr.error('State does not found.');
//            }
//            else {
//                document.getElementById("t_cstedesc").innerHTML = response[0].t_dsca;
//            }
//        },
//        error: function (errormessage) {
//            alert(errormessage.responseText);
//            $("#divLoader").hide();
//        }
//    });
//    return false;
//}

//function GetBankDesc(txtbname) {

//    var txtbname = '';
//    txtbname = $("#txtbankname").val();
//    $.ajax({
//        url: "../Employee/BindBankwise",
//        data: '{t_bano: "' + txtbname + '"}',
//        type: "POST",
//        contentType: "application/json;charset=UTF-8",
//        dataType: "json",
//        success: function (response) {

//            if (response.length === 0) {
//                $("#t_bankdesc").html("");
//                $("#txtbankname").val("");
//                toastr.error('bank name does not found.!');
//            }
//            else {
//                document.getElementById("t_bankdesc").innerHTML = response[0].t_bnam;
//            }
//        },
//        error: function (errormessage) {
//            alert(errormessage.responseText);
//            $("#divLoader").hide();
//        }
//    });
//    return false;
//}

$("#txtEmail").change(function () {

    var mailid = $("#txtEmail").val();

    //var EmailCheck = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
    var EmailCheck = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (mailid != '') {
        if (mailid.match(EmailCheck)) {
            return true;
        }

        else {
            toastr.error('Enter valid mail address.');
            $("#txtEmail").val('');
            return false;
        }
    }

});

$("#txttotalpercentage").change(function () {

    var totalper = $("#txttotalpercentage").val();
    //var TotalPerCheck = "^0*(?:[1-9][0-9]?(\.\d+)?|100)$";
    if (totalper > 100) {
        toastr.error('You can not enter more than 100%');
        $("#txttotalpercentage").val('');
        $("#txttotalpercentage").focus();
    }
    if (totalper < 35) {
        toastr.error('Below 35% percentage is not eligible');
        $("#txttotalpercentage").val('');
        $("#txttotalpercentage").focus();
    }
});

$("#txtReferencePhoneno").change(function () {

    var txtReferencePhoneno = $("#txtReferencePhoneno").val();
    //var TotalPerCheck = "^0*(?:[1-9][0-9]?(\.\d+)?|100)$";
    var txtReferencePhoneno = /^(\+\d{1,3}[- ]?)?\d{10}$/;
    if (txtReferencePhoneno != '') {
        if (txtReferencePhoneno.match(txtReferencePhoneno)) {
            return true;
        }
        else {
            toastr.error('Enter valid phone no.');
            $("#txtReferencePhoneno").val('');
            return false;

        }
    }
});

$("#txtCertificationMarks").change(function () {

    var totalper = $("#txtCertificationMarks").val();

    //var totalper = $("#txtCertificationMarks").val();
    //var TotalPerCheck = "^0*(?:[1-9][0-9]?(\.\d+)?|100)$";
    if (totalper > 100) {
        toastr.error('You can not enter more than 100%');
        $("#txtCertificationMarks").val('');
        $("#txtCertificationMarks").focus();
    }
    if (totalper < 35) {
        toastr.error('Below 35% percentage is not eligible');
        $("#txtCertificationMarks").val('');
        $("#txtCertificationMarks").focus();
    }
});

$('#checksameaspermanant').change(function () {
    if (this.checked) {
        var peradd = $('#txtPermanant').val();
        $('#txtCorrespondence').val(peradd);
    } else {
        $('#txtCorrespondence').val('');
    }
});

function checkMaritalStatus() {
    var marriedStatus = $("#ddlMarriedStatus option:selected").text();
    if (marriedStatus == "Married") {
        $("#dtpickdom").removeAttr("disabled");
    }
    else {
        $("#dtpickdom").attr("disabled", "disabled");
        $("#dtpickdom").val('');
    }
}

$("#ddlMarriedStatus").change(function () {
    checkMaritalStatus();

});

$(".DOMdtpicker").change(function () {

    var dtpickdom = $("#dtpickdom").val();
    var dtpickdob = $("#dtpickdob").val();


    //var data = $('#date').text();
    var arr = dtpickdom.split('-');
    var FinalDom = (arr[2] + "-" + arr[1] + "-" + arr[0]);
    var arr1 = dtpickdob.split('-');
    var FinalDob = (arr1[2] + "-" + arr1[1] + "-" + arr1[0]);
    if (FinalDom === FinalDob) {
        toastr.error('You can not select date of marriage and date of birth is same!');
        $("#dtpickdom").val('');
        $("#dtpickdom").focus();
    }
    else if (FinalDom <= FinalDob) {
        toastr.error('You can not select date of marriage before your date of birth!');
        $("#dtpickdom").val('');
        $("#dtpickdom").focus();
    }
    else if (FinalDom > FinalDob) {
    }

});

$(".DOBdtpicker").change(function () {

    var today = new Date();
    const _MS_PER_DAY = 1000 * 60 * 60 * 24;
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();

    var FinalToday = mm + '-' + dd + '-' + yyyy;

    var dtpickdob = $("#dtpickdob").val();
    if (dtpickdob != '') {
        var arr1 = dtpickdob.split('-');
        var FinalDob = (arr1[1] + "-" + arr1[0] + "-" + arr1[2]);

        let currentTime = new Date(FinalToday).getTime();
        let birthDateTime = new Date(FinalDob).getTime();
        let difference = (currentTime - birthDateTime)
        var ageInYears = difference / (1000 * 60 * 60 * 24 * 365)
        if (ageInYears < 18) {
            toastr.error('You are not eligible for fill this application form,because your age is lesss than 18 !');
            $("#dtpickdob").val('');
            $("#dtpickdob").focus();

        }

    }

});

function formatJSONDate(jsonDate) {
    //var newDate = dateFormat(jsonDate, "mm/dd/yyyy");
    var newDate = new Date(parseInt(jsonDate.substr(6)));
    return newDate;
}

$("#ddlEducation").change(function () {

    var ddlEducation = $("#ddlEducation option:selected").text();
    if (ddlEducation == "10th" || ddlEducation == "12th") {

        $("#ddlboard").removeAttr("disabled");
        $("#ddlschoolmedium").removeAttr("disabled");

        $("#txtcourse").attr("disabled", "disabled");
        $("#txtSpecialization").attr("disabled", "disabled");
        $("#txtuniversity").attr("disabled", "disabled");
        $("#ddlcoursetype").attr("disabled", "disabled");

        $("#txtcourse").val('');
        $("#txtSpecialization").val('');
        $("#txtuniversity").val('');
        $("#txtcourse").val('');
        $("#ddlcoursetype").val(0);

        $('#txtcourse').css('border-color', 'lightgrey');
        $('#txtSpecialization').css('border-color', 'lightgrey');
        $('#txtuniversity').css('border-color', 'lightgrey');
        $('#ddlcoursetype').css('border-color', 'lightgrey');
        //$("#ddlpassingoutyear option:selected").text("")

    }
    if (ddlEducation == "Graduation/Diploma" || ddlEducation == "Master/PostGraduation") {


        $("#txtcourse").removeAttr("disabled");
        $("#txtSpecialization").removeAttr("disabled");
        $("#txtuniversity").removeAttr("disabled");
        $("#ddlcoursetype").removeAttr("disabled");

        $("#ddlboard").attr("disabled", "disabled");
        $("#ddlboard").val(0);
        $("#ddlschoolmedium").val(0);
        $("#ddlschoolmedium").attr("disabled", "disabled");

        $('#ddlboard').css('border-color', 'lightgrey');
        $('#ddlschoolmedium').css('border-color', 'lightgrey');
        //$("#ddlcoursemedium option:selected").text("--Select--")
    }
});

$("#txtdocumentno").change(function (e) {

    //if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {

    //    toastr.warning('Enter only numbers...!!!');
    //    return false;
    //    e.preventDefault();
    //}
    var ddlDocType = $("#ddlDocType option:selected").text();
    var documentno = $("#txtdocumentno").val();
    //if (ddlDocType == "Address Proof" && documentno != "") {

    //    //var adharcardTwelveDigit = /^\d{12}$^[0-9]{4}[ -]?[0-9]{4}[ -]?[0-9]{4}$/;
    //    var ElectricBillTwelveDigit = "^[2-9]{1}[0-9]{11}$";

    //    if (documentno != '') {
    //        if (documentno.match(ElectricBillTwelveDigit)) {
    //            return true;
    //        }

    //        else {
    //            toastr.error('Enter valid Electric Bill Number.');
    //            $("#txtdocumentno").val('');
    //            return false;
    //        }
    //    }
    //}
    //Change By Aniket User
    if (ddlDocType == "Aadhar Number" && documentno != "") {
        var documentno = $("#txtdocumentno").val();
        //var adharcardTwelveDigit = /^\d{12}$^[0-9]{4}[ -]?[0-9]{4}[ -]?[0-9]{4}$/;
        var adharcardTwelveDigit = "^[2-9]{1}[0-9]{11}$";

        if (documentno != '') {
            if (documentno.match(adharcardTwelveDigit)) {
                return true;
            }

            else {
                toastr.error('Enter valid Aadhar Number.');
                $("#txtdocumentno").val('');
                return false;
            }
        }
    }
    if (ddlDocType == "PAN Number" && documentno != "") {
        var documentno = $("#txtdocumentno").val();
        //var adharcardTwelveDigit = /^\d{12}$^[0-9]{4}[ -]?[0-9]{4}[ -]?[0-9]{4}$/;
        var PANNO = /([A-Z]){5}([0-9]){4}([A-Z]){1}$/;

        if (documentno != '') {
            if (documentno.match(PANNO)) {
                return true;
            }

            else {
                toastr.error('Enter valid PAN Number.');
                $("#txtdocumentno").val('');
                return false;
            }
        }
    }
    //if (ddlDocType == "Driving License No" && documentno != "") {
    //    var documentno = $("#txtdocumentno").val();
    //    //var adharcardTwelveDigit = /^\d{12}$^[0-9]{4}[ -]?[0-9]{4}[ -]?[0-9]{4}$/;
    //    var LicenseNo = "^(([A-Z]{2}[0-9]{2})( )|([A-Z]{2}-[0-9]{2}))((19|20)[0-9][0-9])[0-9]{7}$";

    //    if (documentno != '') {
    //        if (documentno.match(LicenseNo)) {
    //            return true;
    //        }

    //        else {
    //            toastr.error('Enter valid License Number.');
    //            $("#txtdocumentno").val('');
    //            return false;
    //        }
    //    }
    //}
    if (ddlDocType == "Passport Number" && documentno != "") {
        var documentno = $("#txtdocumentno").val();
        //var adharcardTwelveDigit = /^\d{12}$^[0-9]{4}[ -]?[0-9]{4}[ -]?[0-9]{4}$/;
        var PassportNo = "^(?!^0+$)[a-zA-Z0-9]{3,20}$";

        if (documentno != '') {
            if (documentno.match(PassportNo)) {
                return true;
            }

            else {
                toastr.error('Enter valid Passport Number.');
                $("#txtdocumentno").val('');
                return false;
            }
        }
    }
});

$("#txtmobileno").change(function () {
    var txtmobileno = $("#txtmobileno").val();
    if (txtmobileno != "") {

        //var adharcardTwelveDigit = /^\d{12}$^[0-9]{4}[ -]?[0-9]{4}[ -]?[0-9]{4}$/;
        var MobileNo = /^(\+\d{1,3}[- ]?)?\d{10}$/;
        if (txtmobileno.match(MobileNo)) {
            return true;
        }
        else {
            toastr.error('Enter valid 10 digit mobile Number.');
            $("#txtmobileno").val('');
            $("#txtmobileno").focus();
            return false;
        }
    }
});

$("#txtemergencymob").change(function () {
    var txtemergencymob = $("#txtemergencymob").val();
    if (txtemergencymob != "") {

        //var adharcardTwelveDigit = /^\d{12}$^[0-9]{4}[ -]?[0-9]{4}[ -]?[0-9]{4}$/;
        var EmeMobileNo = /^(\+\d{1,3}[- ]?)?\d{10}$/;
        if (txtemergencymob.match(EmeMobileNo)) {
            return true;
        }
        else {
            toastr.error('Enter valid 10 digit emergency mobile Number');
            $("#txtemergencymob").val('');
            $("#txtemergencymob").focus();
            return false;
        }
    }
});


$("#txtmembermobileno").change(function () {
    var txtmembermobileno = $("#txtmembermobileno").val();
    if (txtmembermobileno != "") {
        var MemberMobileNo = /^(\+\d{1,3}[- ]?)?\d{10}$/;
        if (txtmembermobileno.match(MemberMobileNo)) {
            return true;
        }
        else {
            toastr.error('Enter valid 10 digit emergency mobile Number.');
            $("#txtmembermobileno").val('');
            $("#txtmembermobileno").focus();
            return false;
        }
    }
});

$("#txtmemberemail").change(function () {

    var mailid = $("#txtmemberemail").val();

    //var EmailCheck = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
    var EmailCheck = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (mailid != '') {
        if (mailid.match(EmailCheck)) {
            return true;
        }
        else {
            toastr.error('Enter valid mail address.');
            $("#txtmemberemail").val('');
            $("#txtmemberemail").focus();
            return false;
        }
    }

});
function ShowImagePreview(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#imgprofilepic').prop('src', e.target.result);
        };
        reader.readAsDataURL(input.files[0]);
    }
}

function loadEduPassingOutYear() {
    $('#ddlpassingoutyear').each(function () {
        //var ddlpassingoutyear = $("#ddlpassingoutyear");
        //ddlpassingoutyear.empty().append('<option value="0">--Select--</option>');
        var year = (new Date()).getFullYear();
        var current = year;
        year -= 60;
        for (var i = 0; i < 61; i++) {
            if ((year + i) == current)
                $(this).append('<option selected value="' + (year + i) + '">' + (year + i) + '</option>');
            else
                $(this).append('<option value="' + (year + i) + '">' + (year + i) + '</option>');
        }

    })
}
function loadFromYear() {
    $('#ddlfromyear').each(function () {

        var year = (new Date()).getFullYear();
        var current = year;
        year -= 60;
        for (var i = 0; i < 61; i++) {
            if ((year + i) == current)
                $(this).append('<option selected value="' + (year + i) + '">' + (year + i) + '</option>');
            else
                $(this).append('<option value="' + (year + i) + '">' + (year + i) + '</option>');
        }

    })
}
function loadToYear() {
    $('#ddlToyear').each(function () {

        var year = (new Date()).getFullYear();
        var current = year;
        year -= 60;
        for (var i = 0; i < 61; i++) {
            if ((year + i) == current)
                $(this).append('<option selected value="' + (year + i) + '">' + (year + i) + '</option>');
            else
                $(this).append('<option value="' + (year + i) + '">' + (year + i) + '</option>');
        }

    })
}

function loadPayslipYear() {
    $('#ddlPayslipYear').each(function () {

        var year = (new Date()).getFullYear();
        var current = year;

        year -= 1;
        for (var i = 0; i <= 1; i++) {
            if ((year + i) == current)
                $(this).append('<option selected value="' + (year + i) + '">' + (year + i) + '</option>');
            else
                $(this).append('<option value="' + (year + i) + '">' + (year + i) + '</option>');
        }

    })
}

//Load Data function  

//Function for getting the Data Based upon Employee ID
function getbyBasicDetails(detailempid) {

    $("#divLoader").show();
    $('#txtfirstname').css('border-color', 'lightgrey');
    $('#txtmiddlename').css('border-color', 'lightgrey');
    $('#txtlastname').css('border-color', 'lightgrey');
    $('#txtmothername').css('border-color', 'lightgrey');
    $('#ddlgender').css('border-color', 'lightgrey');
    $('#dtpickdob').css('border-color', 'lightgrey');
    $('#txtplaceofbirth').css('border-color', 'lightgrey');
    $('#txtcurrentloc').css('border-color', 'lightgrey');
    $('#txtPermanant').css('border-color', 'lightgrey');
    $('#txtCorrespondence').css('border-color', 'lightgrey');
    $('#txtstate').css('border-color', 'lightgrey');
    $('#txtcity').css('border-color', 'lightgrey');
    $('#txtnationality').css('border-color', 'lightgrey');
    $('#ddlMarriedStatus').css('border-color', 'lightgrey');
    $('#dtpickdom').css('border-color', 'lightgrey');
    $('#txtmobileno').css('border-color', 'lightgrey');
    $('#txtemergencymob').css('border-color', 'lightgrey');
    $('#txtEmail').css('border-color', 'lightgrey');
    $('#txtReligion').css('border-color', 'lightgrey');
    $('#txtcast').css('border-color', 'lightgrey');
    $('#txtmothertongue').css('border-color', 'lightgrey');
    $('#ddlEmployeeType').css('border-color', 'lightgrey');
    $('#ddltotalworkexp').css('border-color', 'lightgrey');
    $('#txtEsiccode').css('border-color', 'lightgrey');
    $('#txtbankaccount').css('border-color', 'lightgrey');
    $('#txtbankname').css('border-color', 'lightgrey');
    $('#txtifsccode').css('border-color', 'lightgrey');
    $('#txtUANno').css('border-color', 'lightgrey');

    $.ajax({
        url: "../Employee/GetBasicDetail",
        //data: '{t_emno :"' + detailempid + '"}',
        data: { t_emno: detailempid },
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {

            $("#divLoader").hide();
            //$('#ddlact').empty();
            var result = data;
            if (result.length != 0) {

                $('#txtfirstname').val(result[0].t_firn);
                $('#txtmiddlename').val(result[0].t_midn);
                $('#txtlastname').val(result[0].t_lasn);
                $('#txtmothername').val(result[0].t_motn);
                $('#ddlgender').val(result[0].t_gend);
                $('#dtpickdob').val(result[0].t_dobt);
                $('#txtplaceofbirth').val(result[0].t_plob);
                $('#txtcurrentloc').val(result[0].t_culo);
                $('#txtPermanant').val(result[0].t_cadr);
                $('#txtCorrespondence').val(result[0].t_coad);

                //$('#ddlstate').val(result[0].t_cste.trim());
                document.getElementById("ddlstate").value = result[0].t_cste;
                //GetStateDesc(result[0].t_cste);
                $('#txtcity').val(result[0].t_city);
                $('#txtnationality').val(result[0].t_nati);
                if (result[0].t_matr == 2) {
                    $("#dtpickdom").removeAttr("disabled");
                }
                else {
                    $("#dtpickdom").attr("disabled", "disabled");
                    $("#dtpickdom").val('');
                }
                $('#ddlMarriedStatus').val(result[0].t_matr);
                //var dateofMarriage = '';
                var retrivedom = result[0].t_datm;

                if (retrivedom === '01-01-1900') {
                    dateofMarriage = '';
                }
                else if (retrivedom === '1-1-2040') {
                    dateofMarriage = '';
                }
                else {
                    dateofMarriage = (result[0].t_datm);
                }
                $('#dtpickdom').val(dateofMarriage);
                //alert(FormatJsonDate(result[0].t_datm));
                $('#txtmobileno').val(result[0].t_mobl);
                $('#txtemergencymob').val(result[0].t_emmo);
                $('#txtEmail').val(result[0].t_emai);
                $('#txtReligion').val(result[0].t_reli);
                $('#txtcast').val(result[0].t_cast);
                $('#txtmothertongue').val(result[0].t_motl);
                $('#ddlEmployeeType').val(result[0].t_etyp);
                $('#ddltotalworkexp').val(result[0].t_woex);
                $('#txtEsiccode').val(result[0].t_esic);
                $('#txtbankaccount').val(result[0].t_bano);
                //document.getElementById("ddlbank").value = result[0].t_bank.trim();
                //$('#ddlbank').val(result[0].t_bank.trim());
                document.getElementById("ddlbank").value = result[0].t_bank;
                //GetBankDesc(result[0].t_bank);
                $('#txtifsccode').val(result[0].t_ifsc);
                $('#txtUANno').val(result[0].t_uanc);
                //document.getElementById("imgprofilepic").src = result[0].t_path;
                var NewImagePath = result[0].t_path;

                //var NewImagePath = 
                $("#imgprofilepic").attr("src", ('' + NewImagePath + ''));
                $('#txtprofileimagname').val(result[0].t_imag);

                $('#lbluploadprofile').html(result[0].t_imag);
                $('#lbluploadresume').html(result[0].t_filn);

                $('#txtprofileimgpath').val(result[0].t_path);
                $('#txtresumeimagname').val(result[0].t_filn);

                $('#txtresumeimgpath').val(result[0].t_rpat);

                var BasicStatus = result[0].t_stat;
                if (BasicStatus == 1 || 2) {
                    $('#btnBasicDetailsUpdate').show();
                    $('#btnBasicDetails').hide();
                }
                else {
                    $('#btnBasicDetails').show();
                    $('#btnBasicDetailsUpdate').hide();
                }

                var EmployeeType = $("#ddlEmployeeType option:selected").text();
                if (EmployeeType == "Fresher") {
                    $("#btnpreviouscompanyadd").attr("disabled", "disabled");
                    $("#btnaddpayslip").attr("disabled", "disabled");
                } else {

                    $("#btnpreviouscompanyadd").removeAttr("disabled");
                    $("#btnaddpayslip").removeAttr("disabled");
                }

            }
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
            $("#divLoader").hide();
        }
    });
    return false;
}

//Add Data Function   

$("#btnBasicDetails").click(function () {

    $("#divLoader").show();
    var res = validateBasicDetails();
    if (res == false) {
        return false;
    }

    var profilephotofiles = $("#postedFiles").get(0).files;
    var data = new FormData();

    for (var i = 0; i < profilephotofiles.length; i++) {
        data.append("postedFiles", profilephotofiles[i]);
    }

    var rusumeFile = $("#uploadresume").get(0).files;
    for (var i = 0; i < rusumeFile.length; i++) {
        data.append("uploadresume", rusumeFile[i]);
    }

    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_firn", $('#txtfirstname').val());
    data.append("t_midn", $('#txtmiddlename').val());
    data.append("t_lasn", $('#txtlastname').val());
    data.append("t_motn", $('#txtmothername').val());
    data.append("t_gend", $('#ddlgender').val());
    data.append("t_dobt", $('#dtpickdob').val());
    data.append("t_plob", $('#txtplaceofbirth').val());
    data.append("t_culo", $('#txtcurrentloc').val());
    data.append("t_cadr", $('#txtPermanant').val());
    data.append("t_coad", $('#txtCorrespondence').val());
    data.append("t_cste", $('#ddlstate').val());
    data.append("t_city", $('#txtcity').val());
    data.append("t_nati", $('#txtnationality').val());
    data.append("t_matr", $('#ddlMarriedStatus').val());
    data.append("t_datm", $('#dtpickdom').val());
    data.append("t_mobl", $('#txtmobileno').val());
    data.append("t_emmo", $('#txtemergencymob').val());
    data.append("t_emai", $('#txtEmail').val());
    data.append("t_reli", $('#txtReligion').val());
    data.append("t_cast", $('#txtcast').val());
    data.append("t_motl", $('#txtmothertongue').val());
    data.append("t_etyp", $('#ddlEmployeeType').val());
    data.append("t_woex", $('#ddltotalworkexp').val());
    data.append("t_esic", $('#txtEsiccode').val());
    //$("#ddlstate option:selected").val();
    if ($("#ddlbank option:selected").text().trim() == "--Select--") {
        //$('#txtbankname').val("");
        $('#txtbankaccount').val("");
        $('#txtifsccode').val("");
    }

    data.append("t_bano", $('#txtbankaccount').val());
    data.append("t_bank", $('#ddlbank').val());
    data.append("t_ifsc", $('#txtifsccode').val());
    data.append("t_uanc", $('#txtUANno').val());

    $.ajax({
        type: "POST",
        url: "../Employee/Add",
        contentType: false,
        processData: false,
        data: data,
        success: function (result) {

            var output = result;

            if (output === "SUCCESS") {

                toastr.success('Record inserted successfully.');
                var enabled = 1;
                //var disabled = [0, 2, 3, 4, 5, 6, 7];
                var disabled = [2, 3, 4, 5, 6, 7];
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                $('#custom-tabs-basic').removeClass('active');
                $('#custom-basic').removeClass('show active');
                $('#custom-tabs-family').addClass('active');
                $('#custom-family').addClass('show active');
                $('#custom-tabs-family').trigger("click");
                $("#divLoader").hide();

            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function (xhr, status, error) {

            var err = eval(xhr.responseText);
            alert(err);
            //alert("There was error uploading files!");
            toastr.error("There is an error");
            $("#divLoader").hide();
        }
    });

});

$("#btnBasicDetailsUpdate").click(function () {

    $("#divLoader").show();
    var res = validateBasicDetails();
    if (res == false) {
        return false;
    }

    var profilephotofiles = $("#postedFiles").get(0).files;
    var data = new FormData();

    for (var i = 0; i < profilephotofiles.length; i++) {
        data.append("postedFiles", profilephotofiles[i]);
    }

    var rusumeFile = $("#uploadresume").get(0).files;
    for (var i = 0; i < rusumeFile.length; i++) {
        data.append("uploadresume", rusumeFile[i]);
    }

    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_firn", $('#txtfirstname').val());
    data.append("t_midn", $('#txtmiddlename').val());
    data.append("t_lasn", $('#txtlastname').val());
    data.append("t_motn", $('#txtmothername').val());
    data.append("t_gend", $('#ddlgender').val());
    data.append("t_dobt", $('#dtpickdob').val());
    data.append("t_plob", $('#txtplaceofbirth').val());
    data.append("t_culo", $('#txtcurrentloc').val());
    data.append("t_cadr", $('#txtPermanant').val());
    data.append("t_coad", $('#txtCorrespondence').val());
    data.append("t_cste", $('#ddlstate').val());
    data.append("t_city", $('#txtcity').val());
    data.append("t_nati", $('#txtnationality').val());
    data.append("t_matr", $('#ddlMarriedStatus').val());
    data.append("t_datm", $('#dtpickdom').val());
    data.append("t_mobl", $('#txtmobileno').val());
    data.append("t_emmo", $('#txtemergencymob').val());
    data.append("t_emai", $('#txtEmail').val());
    data.append("t_reli", $('#txtReligion').val());
    data.append("t_cast", $('#txtcast').val());
    data.append("t_motl", $('#txtmothertongue').val());
    data.append("t_etyp", $('#ddlEmployeeType').val());
    data.append("t_woex", $('#ddltotalworkexp').val());
    data.append("t_esic", $('#txtEsiccode').val());
    //data.append("t_bano", $('#txtbankaccount').val());
    //data.append("t_bank", $('#txtbankname').val());
    //data.append("t_ifsc", $('#txtifsccode').val());
    data.append("t_imag", $('#txtprofileimagname').val());
    data.append("t_path", $('#txtprofileimgpath').val());
    data.append("t_filn", $('#txtresumeimagname').val());
    data.append("t_rpat", $('#txtresumeimgpath').val());
    data.append("t_uanc", $('#txtUANno').val());

    //if ($('#txtbankname').val().trim() == "") {
    //    var bankname = "";
    //    var bankaccount = "";
    //    var ifsccode = "";
    //    $('#txtbankname').val(bankname);
    //    $('#txtbankaccount').val(bankaccount);
    //    $('#txtifsccode').val(ifsccode);
    //}
    if ($("#ddlbank option:selected").text().trim() == "--Select--") {
        //$('#txtbankname').val("");
        $('#txtbankaccount').val("");
        $('#txtifsccode').val("");
    }
    data.append("t_bano", $('#txtbankaccount').val());
    data.append("t_bank", $('#ddlbank').val());
    data.append("t_ifsc", $('#txtifsccode').val());

    $.ajax({
        type: "POST",
        url: "../Employee/UpdateBasic",
        contentType: false,
        processData: false,
        data: data,
        success: function (result) {
            var output = result;
            //detailempid = myArr[0]; 
            //var output = myArr[1]; 
            if (output === "SUCCESS") {

                var enabled = 1;
                //var disabled = [0, 2, 3, 4, 5, 6, 7];
                var disabled = [2, 3, 4, 5, 6, 7];
                $("#tabs").tabs({ active: enabled, disabled: disabled });
                //$('#custom-tabs-three-home').removeClass('active');
                //$('#custom-tabs-three-profile').addClass('active show');

                $('#custom-tabs-basic').removeClass('active');
                $('#custom-basic').removeClass('show active');
                $('#custom-tabs-family').addClass('active');
                $('#custom-family').addClass('show active');
                $('#custom-tabs-family').trigger("click");
                //getbyTabNotExistStatus();
                toastr.success('Record updated successfully.');
                $("#divLoader").hide();
                //getbyTabExistStatus();
            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function (error, element) {

            error.responseText;
            //var err = eval(xhr.responseText);
            //alert(err.Message);
            alert("There is an error");
            $("#divLoader").hide();
            //alert(error.text);
        }
    });

});

$("#btnFamilyBack").click(function () {
    $("#divLoader").show();
    $.ajax({
        url: "../Employee/CheckExistForTab",
        //data: '{t_emno :"' + detailempid + '"}',
        //data: { t_emno: detailempid},
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {
            $("#divLoader").hide();
            //$('#ddlact').empty();
            var result = data;

            if (result == 'BASICEXIST') {

                $('#custom-tabs-family').removeClass('active');
                $('#custom-family').removeClass('show active');
                $('#custom-tabs-basic').addClass('active');
                $('#custom-basic').addClass('show active');
                $('#custom-tabs-basic').trigger("click");

                $('#btnBasicDetailsUpdate').show();
                $('#btnBasicDetails').hide();
                if (detailempid != "") {
                    getbyBasicDetails(detailempid);
                }
            }
            else {

                $('#custom-tabs-family').removeClass('active');
                $('#custom-family').removeClass('show active');
                $('#custom-tabs-basic').addClass('active');
                $('#custom-basic').addClass('show active');
                $('#custom-tabs-basic').trigger("click");
            }

        },
        error: function (errormessage) {
            alert(errormessage.responseText);
            $("#divLoader").hide();
        }
    });
});

$("#btnEducationBack").click(function () {
    //var enabled = 1;
    //var disabled = [0, 2, 3, 4, 5, 6, 7];

    //$("#tabs").tabs({ active: enabled, disabled: disabled });
    //$('#custom-tabs-three-messages').removeClass('active');
    //$('#custom-tabs-three-profile').addClass('active show');
    $('#custom-tabs-education').removeClass('active');
    $('#custom-education').removeClass('show active');
    $('#custom-tabs-family').addClass('active');
    $('#custom-family').addClass('show active');
    $('#custom-tabs-family').trigger("click");

});

$("#btnDocumentBack").click(function () {
    //var enabled = 2;
    //var disabled = [0, 1, 3, 4, 5, 6, 7];

    //$("#tabs").tabs({ active: enabled, disabled: disabled });
    //$('#document').removeClass('active');
    //$('#custom-tabs-three-messages').addClass('active show');
    $('#custom-tabs-document').removeClass('active');
    $('#custom-document').removeClass('show active');
    $('#custom-tabs-education').addClass('active');
    $('#custom-education').addClass('show active');
    $('#custom-tabs-education').trigger("click");
});
$("#btncompanyBack").click(function () {
    //var enabled = 3;
    //var disabled = [0, 1, 2, 4, 5, 6, 7];

    //$("#tabs").tabs({ active: enabled, disabled: disabled });
    //$('#previous_company_details').removeClass('active');
    //$('#document').addClass('active show');
    $('#custom-tabs-previous-company').removeClass('active');
    $('#custom-previous-company').removeClass('show active');
    $('#custom-tabs-document').addClass('active');
    $('#custom-document').addClass('show active');
    $('#custom-tabs-document').trigger("click");
});
$("#btnPayslipBack").click(function () {
    //var enabled = 4;
    //var disabled = [0, 1, 2, 3, 5, 6, 7];

    //$("#tabs").tabs({ active: enabled, disabled: disabled });
    //$('#payslip_details').removeClass('active');
    //$('#previous_company_details').addClass('active show');
    $('#custom-tabs-payslip').removeClass('active');
    $('#custom-payslip').removeClass('show active');
    $('#custom-tabs-previous-company').addClass('active');
    $('#custom-previous-company').addClass('show active');
    $('#custom-tabs-previous-company').trigger("click");
});
$("#btnreferenceBack").click(function () {

    var EmployeeType = $("#ddlEmployeeType option:selected").text();
    if (EmployeeType == "Fresher") {
        //$("#btnpreviouscompanyadd").attr("disabled", "disabled");
        //$("#btnaddpayslip").attr("disabled", "disabled");
        //var enabled = 3;
        //var disabled = [0, 1, 2, 4, 5, 6, 7];

        //$("#tabs").tabs({ active: enabled, disabled: disabled });
        //$('#reference_details').removeClass('active');
        //$('#document').addClass('active show');
        $('#custom-tabs-reference').removeClass('active');
        $('#custom-reference').removeClass('show active');
        $('#custom-tabs-document').addClass('active');
        $('#custom-document').addClass('show active');
        $('#custom-tabs-document').trigger("click");

    } else {

        //$("#btnpreviouscompanyadd").removeAttr("disabled");
        //$("#btnaddpayslip").removeAttr("disabled");

        //var enabled = 5;
        //var disabled = [0, 1, 2, 3, 4, 6, 7];

        //$("#tabs").tabs({ active: enabled, disabled: disabled });
        //$('#reference_details').removeClass('active');
        //$('#payslip_details').addClass('active show');
        $('#custom-tabs-reference').removeClass('active');
        $('#custom-reference').removeClass('show active');
        $('#custom-tabs-payslip').addClass('active');
        $('#custom-payslip').addClass('show active');
        $('#custom-tabs-payslip').trigger("click");
    }


});
$("#btnfinalsubmitBack").click(function () {

    //var enabled = 6;
    //var disabled = [0, 1, 2, 3, 4, 5, 7];
    ////enabled = $('#hfEnabled').val().split(',').map(Number);
    ////if ($('#hfDisabled').val() != '') {
    ////disabled = $('#hfDisabled').val().split(',').map(Number);
    //$("#tabs").tabs({ active: enabled, disabled: disabled });
    //$('#certification_details').removeClass('active');
    //$('#reference_details').addClass('active show');
    $('#custom-tabs-certification').removeClass('active');
    $('#custom-certification').removeClass('show active');
    $('#custom-tabs-reference').addClass('active');
    $('#custom-reference').addClass('show active');
    $('#custom-tabs-reference').trigger("click");

});

$("#btnfamilyAdd").click(function () {
    $("#divLoader").show();
    var res = validateFamilyDetails();
    if (res == false) {
        return false;
    }

    var ddlRelation = $("#ddlRelation option:selected").text();
    //$("#ddlRelation").append($("<option></option>").html(value.text));  
    var famObj = {
        t_emno: detailempid,
        t_rela: ddlRelation,
        t_nama: $('#txtmembername').val(),
        t_dobt: $('#dtpickrelativedob').val(),
        t_mema: $('#txtmemberemail').val(),
        t_mmob: $('#txtmembermobileno').val()
    };

    $.ajax({

        url: "../Employee/AddEmployeeFamily",
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        data: '{ family : ' + JSON.stringify(famObj) + '}',

        success: function (result) {
            var output = result;
            if (output === "SUCCESS") {

                toastr.success('Record inserted successfully.');
                BindFamilyDetail();
                clearTextBoxFamily();
                $("#divLoader").hide();
                $('#myModalFamily').modal('hide');
            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There is an error while inserting data!");
            $("#divLoader").hide();
        }
    });
});

$("#btnEducationAdd").click(function () {


    var res = validateEducationDetails();
    if (res == false) {
        return false;
    }

    var ddlEducation = $("#ddlEducation option:selected").text();
    if (ddlEducation == "10th" || ddlEducation == "12th") {
        $("#divLoader").show();
        var ddlBoard = $("#ddlboard option:selected").text();
        var ddlschoolmedium = $("#ddlschoolmedium option:selected").text();
        if (ddlBoard == '(--All India--)') {
            toastr.error('Please select board...!!!');
        }
        else if (ddlBoard == '(--State Board--)') {
            toastr.error('Please select board.');
        }
        else if (ddlschoolmedium == '--Select--') {
            toastr.error('Please select school medium.');
        }
        else {
            var educertificate = $("#uploadEduCertificate").get(0).files;
            var data = new FormData();

            for (var i = 0; i < educertificate.length; i++) {
                data.append("uploadEduCertificate", educertificate[i]);
            }
            var ddlEducation = $("#ddlEducation option:selected").text();
            if (ddlEducation == '--Select--') {
                ddlEducation = "";
            }
            else {
                ddlEducation = $("#ddlEducation option:selected").text();
            }
            var ddlBoard = $("#ddlboard option:selected").text();
            if (ddlBoard == '(--All India--)') {
                ddlBoard = "";
            }
            else {
                ddlBoard = $("#ddlboard option:selected").text();
            }
            var ddlPassoutYr = $("#ddlpassingoutyear option:selected").text();
            var ddlschoolmedium = $("#ddlschoolmedium option:selected").text();
            if (ddlschoolmedium == '--Select--') {
                ddlschoolmedium = "";
            }
            else {
                ddlschoolmedium = $("#ddlschoolmedium option:selected").text();
            }
            var ddlCourseType = $("#ddlcoursetype option:selected").val();
            var CourseType;
            if (ddlCourseType = '--Select--') {
                CourseType = '';
            } else {
                CourseType = ddlCourseType;
            }

            //Add the input element values
            data.append("t_emno", detailempid);
            data.append("t_educ", ddlEducation),
            data.append("t_boar", ddlBoard);
            data.append("t_poyr", ddlPassoutYr),
            data.append("t_scmd", ddlschoolmedium);
            data.append("t_crse", $('#txtcourse').val());
            data.append("t_spec", $('#txtSpecialization').val());
            data.append("t_univ", $('#txtuniversity').val());
            data.append("t_coty", CourseType);
            data.append("t_totm", $('#txttotalpercentage').val());

            $.ajax({

                url: "../Employee/AddEmployeeEducation",
                type: "POST",
                contentType: false,
                processData: false,
                //contentType: "application/json;charset=utf-8",
                //dataType: "json",
                data: data,

                success: function (result) {
                    $("#divLoader").hide();
                    var output = result;

                    if (output === "SUCCESS") {

                        BindEducationDetail();
                        $('#myModalEducation').modal('hide');
                        ClearEducation();
                        toastr.success('Record inserted successfully.');
                    }

                    else {
                        toastr.error(result);
                        $("#divLoader").hide();
                    }

                },
                error: function () {
                    toastr.error("There is an error while inserting data!");
                    $("#divLoader").hide();
                }
            });

        }
    }
    if (ddlEducation == "Graduation/Diploma" || ddlEducation == "Master/PostGraduation") {

        $("#divLoader").show();
        var txtcourse = $("#txtcourse").val();
        var txtSpecialization = $("#txtSpecialization").val();
        var txtuniversity = $("#txtuniversity").val();

        var ddlcoursetype = $("#ddlcoursetype option:selected").text();
        if (txtcourse == "") {
            toastr.error('Please enter course.');
        }
        else if (txtSpecialization == "") {
            toastr.error('Please enter Specialization.');
        }
        else if (txtuniversity == "") {
            toastr.error('Please enter University.');
        }
        else if (ddlcoursetype == "--Select--") {
            toastr.error('Please select course type.');
        }
        else {


            var educertificate = $("#uploadEduCertificate").get(0).files;
            var data = new FormData();
            for (var i = 0; i < educertificate.length; i++) {
                data.append("uploadEduCertificate", educertificate[i]);
            }
            var ddlEducation = $("#ddlEducation option:selected").text();
            if (ddlEducation == '--Select--') {
                ddlEducation = "";
            }
            else {
                ddlEducation = $("#ddlEducation option:selected").text();
            }
            var ddlBoard = $("#ddlboard option:selected").text();
            if (ddlBoard == '(--All India--)') {
                ddlBoard = "";
            }
            else {
                ddlBoard = $("#ddlboard option:selected").text();
            }
            var ddlPassoutYr = $("#ddlpassingoutyear option:selected").text();
            var ddlschoolmedium = $("#ddlschoolmedium option:selected").text();
            if (ddlschoolmedium == '--Select--') {
                ddlschoolmedium = "";
            }
            else {
                ddlschoolmedium = $("#ddlschoolmedium option:selected").text();
            }
            var ddlCourseType = $("#ddlcoursetype option:selected").val();

            var CourseType = '';
            if (ddlCourseType == '--Select--') {
                CourseType = '';
            } else {
                CourseType = ddlCourseType;
            }


            //Add the input element values
            data.append("t_emno", detailempid);
            data.append("t_educ", ddlEducation),
            data.append("t_boar", ddlBoard);
            data.append("t_poyr", ddlPassoutYr),
            data.append("t_scmd", ddlschoolmedium);
            data.append("t_crse", $('#txtcourse').val());
            data.append("t_spec", $('#txtSpecialization').val());
            data.append("t_univ", $('#txtuniversity').val());
            data.append("t_coty", CourseType);
            data.append("t_totm", $('#txttotalpercentage').val());

            $.ajax({

                url: "../Employee/AddEmployeeEducation",
                type: "POST",
                contentType: false,
                processData: false,
                //contentType: "application/json;charset=utf-8",
                //dataType: "json",
                data: data,
                success: function (result) {
                    var output = result;

                    if (output === "SUCCESS") {
                        $("#divLoader").hide();
                        $('#myModalEducation').modal('hide');
                        ClearEducation();
                        BindEducationDetail();
                        toastr.success('Record inserted successfully.');
                    }

                    else {
                        toastr.error(result);
                        $("#divLoader").hide();
                    }

                },
                error: function () {
                    toastr.error("There was an error while inserting data!");
                    $("#divLoader").hide();
                }
            });

        }
    }


});

$("#btnEducationUpdate").click(function () {
    $("#divLoader").show();
    var res = validateEducationDetails();
    if (res == false) {
        return false;
    }
    var educertificate = $("#uploadEduCertificate").get(0).files;
    var data = new FormData();


    for (var i = 0; i < educertificate.length; i++) {
        data.append("uploadEduCertificate", educertificate[i]);
    }
    var ddlEducation = $("#ddlEducation option:selected").text();
    if (ddlEducation == '--Select--') {
        ddlEducation = "";
    }
    else {
        ddlEducation = $("#ddlEducation option:selected").text();
    }
    var ddlBoard = $("#ddlboard option:selected").text();
    if (ddlBoard == '(--All India--)') {
        ddlBoard = "";
    }
    else {
        ddlBoard = $("#ddlboard option:selected").text();
    }
    var ddlPassoutYr = $("#ddlpassingoutyear option:selected").text();
    var ddlschoolmedium = $("#ddlschoolmedium option:selected").text();
    if (ddlschoolmedium == '--Select--') {
        ddlschoolmedium = "";
    }
    else {
        ddlschoolmedium = $("#ddlschoolmedium option:selected").text();
    }
    var ddlCourseType = $("#ddlcoursetype option:selected").val();
    var CourseType;
    if (ddlCourseType == '--Select--') {
        CourseType = '';
    } else {
        CourseType = ddlCourseType;
    }
    var positionno = $('#txteduposition').val();
    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_pono", positionno);
    data.append("t_educ", ddlEducation),
    data.append("t_boar", ddlBoard);
    data.append("t_poyr", ddlPassoutYr),
    data.append("t_scmd", ddlschoolmedium);
    data.append("t_crse", $('#txtcourse').val());
    data.append("t_spec", $('#txtSpecialization').val());
    data.append("t_univ", $('#txtuniversity').val());
    data.append("t_coty", CourseType);
    data.append("t_totm", $('#txttotalpercentage').val());
    //data.append("t_coty", ddlCourseType);
    data.append("t_cena", $('#txteduimagename').val());
    data.append("t_ecpa", $('#txteduimagepath').val());

    $.ajax({

        url: "../Employee/UpdateEmployeeEducation",
        type: "POST",
        contentType: false,
        processData: false,
        //contentType: "application/json;charset=utf-8",
        //dataType: "json",
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;
            if (output === "SUCCESS") {

                $('#myModalEducation').modal('hide');
                ClearEducation();
                BindEducationDetail();
                toastr.success('Record updated successfully.');

            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There was an error while inserting data!");
            $("#divLoader").hide();
        }
    });
});

function AddDocument() {
    $("#divLoader").show();
    var res = validateDocumentDetails();
    if (res == false) {
        return false;
    }
    var uploadDocument = $("#uploadDocument").get(0).files;
    var data = new FormData();


    for (var i = 0; i < uploadDocument.length; i++) {
        data.append("uploadDocument", uploadDocument[i]);
    }
    var ddlDocType = $("#ddlDocType option:selected").text();

    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_docm", $('#txtdocumentno').val());
    data.append("t_dtyp", ddlDocType);

    $.ajax({

        url: "../Employee/AddEmployeeDocument",
        type: "POST",
        contentType: false,
        processData: false,
        //contentType: "application/json;charset=utf-8",
        //dataType: "json",
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;

            if (output === "SUCCESS") {

                BindDocumentDetail();
                clearDocument();
                $('#myModalDocument').modal('hide');
                toastr.success('Record inserted successfully.');
            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There is an error while inserting data!");
            $("#divLoader").hide();
        }
    });
}

function AddCompany() {
    $("#divLoader").show();
    var res = validateCompanyDetails();
    if (res == false) {
        return false;
    }
    var uploadExpCertificate = $("#uploadExpCertificate").get(0).files;
    var data = new FormData();


    for (var i = 0; i < uploadExpCertificate.length; i++) {
        data.append("uploadExpCertificate", uploadExpCertificate[i]);
    }
    var ddlfromyear = $("#ddlfromyear option:selected").text();
    var ddlfrommonth = $("#ddlfrommonth option:selected").text();
    var ddlToyear = $("#ddlToyear option:selected").text();
    var ddlTomonth = $("#ddlTomonth option:selected").text();
    var ddlcurcompany = $("#ddlcurcompany option:selected").text();
    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_orga", $('#txtOrganization').val());
    data.append("t_dnam", $('#txtDesignation').val());
    data.append("t_expe", $('#txtTotalExp').val());
    data.append("t_cuco", ddlcurcompany);
    data.append("t_year", ddlfromyear);
    data.append("t_mont", ddlfrommonth);
    data.append("t_toyr", ddlToyear);
    data.append("t_tomo", ddlTomonth);
    data.append("t_dyjp", $('#txtdescribejobprofile').val());


    $.ajax({

        url: "../Employee/AddEmployeeCompany",
        type: "POST",
        contentType: false,
        processData: false,
        //contentType: "application/json;charset=utf-8",
        //dataType: "json",
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;

            if (output === "SUCCESS") {

                BindCompanyDetails();
                ClearCompany();
                $('#myModalCompanyDetails').modal('hide');
                toastr.success('Record inserted successfully.');
            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There is an error while inserting data!");
            $("#divLoader").hide();
        }
    });
}

function AddPayslip() {
    $("#divLoader").show();
    var res = validatePayslipDetails();
    if (res == false) {
        return false;
    }

    var uploadPayslip = $("#uploadPayslip").get(0).files;
    var data = new FormData();


    for (var i = 0; i < uploadPayslip.length; i++) {
        data.append("uploadPayslip", uploadPayslip[i]);
    }
    var ddlPayslipMonth = $("#ddlPayslipMonth option:selected").text();
    var ddlPayslipYear = $("#ddlPayslipYear option:selected").text();


    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_paym", ddlPayslipMonth);
    data.append("t_payy", ddlPayslipYear);

    $.ajax({

        url: "../Employee/AddEmployeePayslip",
        type: "POST",
        contentType: false,
        processData: false,
        //contentType: "application/json;charset=utf-8",
        //dataType: "json",
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;

            if (output === "SUCCESS") {

                BindPayslipDetail();
                //ClearCompany();
                $('#myModalPayslipDetails').modal('hide');
                toastr.success('Record inserted successfully.');
            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There was an error while inserting data!");
            $("#divLoader").hide();
        }
    });
}

function AddReference() {
    $("#divLoader").show();
    var res = validateReferenceDetails();
    if (res == false) {
        return false;
    }
    var data = new FormData();
    var txtReferenceName = $('#txtReferenceName').val();
    var txtReferencePhoneno = $('#txtReferencePhoneno').val();


    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_rnam", txtReferenceName);
    data.append("t_phon", txtReferencePhoneno);

    $.ajax({

        url: "../Employee/AddEmployeeReference",
        type: "POST",
        contentType: false,
        processData: false,
        //contentType: "application/json;charset=utf-8",
        //dataType: "json",
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;

            if (output === "SUCCESS") {

                BindReferenceDetail();
                //ClearCompany();
                $('#myModalReferenceDetails').modal('hide');
                toastr.success('Record inserted successfully.');
            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There was an error while inserting data!");
            $("#divLoader").hide();
        }
    });
}

function AddCertification() {
    $("#divLoader").show();
    var res = validateCertificationDetails();
    if (res == false) {
        return false;
    }

    var uploadCertification = $("#uploadCertification").get(0).files;
    var data = new FormData();


    for (var i = 0; i < uploadCertification.length; i++) {
        data.append("uploadCertification", uploadCertification[i]);
    }
    var txtCertificationName = $('#txtCertificationName').val();
    var txtCertificationMarks = $('#txtCertificationMarks').val();


    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_cnam", txtCertificationName);
    data.append("t_cema", txtCertificationMarks);


    $.ajax({

        url: "../Employee/AddEmployeeCertification",
        type: "POST",
        contentType: false,
        processData: false,
        //contentType: "application/json;charset=utf-8",
        //dataType: "json",
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;

            if (output === "SUCCESS") {

                BindCertificationDetail();
                clearCertification();
                $('#myModalCertificationDetails').modal('hide');
                toastr.success('Record inserted successfully.');
            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There is an error while inserting data!");
            $("#divLoader").hide();
        }
    });
}

$("#btnfamilyUpdate").click(function () {
    $("#divLoader").show();
    var res = validateFamilyDetails();
    if (res == false) {
        return false;
    }

    var data = new FormData();
    var ddlRelation = $("#ddlRelation option:selected").text();
    var positionno = $('#txtfamposition').val();

    data.append("t_emno", detailempid);
    data.append("t_pono", positionno);
    data.append("t_rela", ddlRelation),
    data.append("t_nama", $('#txtmembername').val());
    data.append("t_dobt", $('#dtpickrelativedob').val()),
    data.append("t_mema", $('#txtmemberemail').val());
    data.append("t_mmob", $('#txtmembermobileno').val());

    $.ajax({

        url: "../Employee/UpdateEmployeeFamily",
        type: "POST",
        contentType: false,
        processData: false,
        //contentType: "application/json;charset=utf-8",
        //dataType: "json",
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;
            if (output === "SUCCESS") {

                BindFamilyDetail();
                clearTextBoxFamily();
                $('#myModalFamily').modal('hide');
                toastr.success('Record updated successfully.');

            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There was an error while inserting data!");
            $("#divLoader").hide();
        }
    });
});


function familyInsertConfirm() {
    if (detailempid != "") {
        $("#divLoader").show();
        $.ajax({

            url: "../Employee/familyInsertConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            data: "{'t_emno': '" + detailempid + "'}",
            //data: data,

            success: function (result) {
                $("#divLoader").hide();
                var output = result;
                if (output === "SUCCESS") {

                    toastr.success('Record inserted successfully.');
                    //getbyTabExistStatus();
                    var enabled = 2;
                    var disabled = [0, 1, 3, 4, 5, 6, 7];
                    //var disabled = [3, 4, 5, 6, 7];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });
                    //$('#custom-tabs-three-profile').removeClass('active');
                    //$('#custom-tabs-three-messages').addClass('active show');
                    $('#custom-tabs-family').removeClass('active');
                    $('#custom-family').removeClass('show active');
                    $('#custom-tabs-education').addClass('active');
                    $('#custom-education').addClass('show active');
                    $('#custom-tabs-education').trigger("click");

                }

                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There is an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again...!!!');
        $("#divLoader").hide();
    }
}

function familyUpdateConfirm() {
    if (detailempid != "") {
        $("#divLoader").show();
        $.ajax({

            url: "../Employee/familyUpdateConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            //data: data,
            data: "{'t_emno': '" + detailempid + "'}",
            success: function (result) {
                var output = result;
                BindEducationDetail();
                if (output === "SUCCESS") {
                    $("#divLoader").hide();
                    var enabled = 2;
                    //var disabled = [0, 1, 3, 4, 5, 6, 7];
                    var disabled = [3, 4, 5, 6, 7];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });
                    //$("#tabs").tabs({ active: $('#hfSelected').val(), enabled: enabled, disabled: disabled });
                    //$('#custom-tabs-basic').removeClass('active');
                    //$('#custom-basic').removeClass('show active');

                    $('#custom-tabs-family').removeClass('active');
                    $('#custom-family').removeClass('show active');
                    $('#custom-tabs-education').addClass('active');
                    $('#custom-education').addClass('show active');
                    $('#custom-tabs-education').trigger("click");
                    toastr.success('Family details updated successfully.');

                }
                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There is an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again...!!!');
        $("#divLoader").hide();
    }
}

function EducationInsertConfirm() {
    if (detailempid != "") {
        $.ajax({

            url: "../Employee/EductionInsertConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            //data: data,
            data: "{'t_emno': '" + detailempid + "'}",
            success: function (result) {
                var output = result;
                if (output === "SUCCESS") {

                    toastr.success('Education details inserted successfully.');
                    var enabled = 3;
                    //var disabled = [0, 1, 2, 4, 5, 6, 7];
                    var disabled = [4, 5, 6, 7];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });
                    $('#custom-tabs-education').removeClass('active');
                    $('#custom-education').removeClass('show active');
                    $('#custom-tabs-document').addClass('active');
                    $('#custom-document').addClass('show active');
                    $('#custom-tabs-document').trigger("click");
                }

                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There is an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again.');
        $("#divLoader").hide();
    }
}

function EducationUpdateConfirm() {
    if (detailempid != "") {
        $("#divLoader").show();
        $.ajax({

            url: "../Employee/EductionUpdateConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            //data: data,
            data: "{'t_emno': '" + detailempid + "'}",
            success: function (result) {
                var output = result;
                if (output === "SUCCESS") {
                    $("#divLoader").hide();

                    toastr.success('Education details updated successfully.');

                    var enabled = 3;
                    //var disabled = [0, 1, 2, 4, 5, 6, 7];
                    var disabled = [4, 5, 6, 7];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });
                    $('#custom-tabs-education').removeClass('active');
                    $('#custom-education').removeClass('show active');
                    $('#custom-tabs-document').addClass('active');
                    $('#custom-document').addClass('show active');
                    $('#custom-tabs-document').trigger("click");

                }

                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There is an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again...!!!');
        $("#divLoader").hide();
    }
}

function DocumentInsertConfirm() {
    if (detailempid != "") {
        $("#divLoader").show();
        $.ajax({

            url: "../Employee/DocumentInsertConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            //data: data,
            data: "{'t_emno': '" + detailempid + "'}",
            success: function (result) {
                var output = result;
                if (output === "SUCCESS") {
                    $("#divLoader").hide();
                    var EmployeeType = $("#ddlEmployeeType option:selected").text();
                    if (EmployeeType == "Fresher") {
                        $("#btnpreviouscompanyadd").attr("disabled", "disabled");
                        $("#btnaddpayslip").attr("disabled", "disabled");
                        var enabled = 6;
                        //var disabled = [0, 1, 2, 3, 4, 5, 7];
                        var disabled = [4, 5, 7];
                        $("#tabs").tabs({ active: enabled, disabled: disabled });
                        $('#custom-tabs-document').removeClass('active');
                        $('#custom-document').removeClass('show active');
                        $('#custom-tabs-reference').addClass('active');
                        $('#custom-reference').addClass('show active');
                        $('#custom-tabs-reference').trigger("click");

                    }
                    else {

                        $("#btnpreviouscompanyadd").removeAttr("disabled");
                        $("#btnaddpayslip").removeAttr("disabled");
                        var enabled = 4;
                        //var disabled = [0, 1, 2, 3, 5, 6, 7];
                        var disabled = [5, 6, 7];
                        $("#tabs").tabs({ active: enabled, disabled: disabled });
                        $('#custom-tabs-document').removeClass('active');
                        $('#custom-document').removeClass('show active');
                        $('#custom-tabs-previous-company').addClass('active');
                        $('#custom-previous-company').addClass('show active');
                        $('#custom-tabs-previous-company').trigger("click");
                    }
                    toastr.success('Document details inserted successfully.');
                }

                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There is an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again...!!!');
        $("#divLoader").hide();
    }
}

function DocumentUpdateConfirm() {
    if (detailempid != "") {
        $("#divLoader").show();
        $.ajax({

            url: "../Employee/DocumentUpdateConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            //data: data,
            data: "{'t_emno': '" + detailempid + "'}",
            success: function (result) {
                var output = result;
                if (output === "SUCCESS") {
                    $("#divLoader").hide();

                    var EmployeeType = $("#ddlEmployeeType option:selected").text();
                    if (EmployeeType == "Fresher") {
                        $("#btnpreviouscompanyadd").attr("disabled", "disabled");
                        $("#btnaddpayslip").attr("disabled", "disabled");
                        var enabled = 6;
                        //var disabled = [0, 1, 2, 3, 4, 5, 7];
                        var disabled = 7;
                        $("#tabs").tabs({ active: enabled, disabled: disabled });
                        //$('#payslip_details').removeClass('active');
                        $('#custom-tabs-document').removeClass('active');
                        $('#custom-document').removeClass('show active');
                        $('#custom-tabs-reference').addClass('active');
                        $('#custom-reference').addClass('show active');
                        $('#custom-tabs-reference').trigger("click");

                    } else {

                        $("#btnpreviouscompanyadd").removeAttr("disabled");
                        $("#btnaddpayslip").removeAttr("disabled");
                    }
                    var enabled = 4;
                    //var disabled = [0, 1, 2, 3, 5, 6, 7];
                    var disabled = [5, 6, 7];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });
                    $('#custom-tabs-document').removeClass('active');
                    $('#custom-document').removeClass('show active');
                    $('#custom-tabs-previous-company').addClass('active');
                    $('#custom-previous-company').addClass('show active');
                    $('#custom-tabs-previous-company').trigger("click");

                    toastr.error('Document details updated successfully.');
                }

                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There is an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again...!!!');
        $("#divLoader").hide();
    }
}

function CompanyInsertConfirm() {
    if (detailempid != "") {
        $("#divLoader").show();
        $.ajax({

            url: "../Employee/CompanyInsertConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            //data: data,
            data: "{'t_emno': '" + detailempid + "'}",
            success: function (result) {
                $("#divLoader").hide();
                var output = result;
                if (output === "SUCCESS") {

                    toastr.success('Company details inserted successfully.');
                    var enabled = 5;
                    //var disabled = [0, 1, 2, 3, 4, 6, 7];
                    var disabled = [6, 7];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });
                    $('#custom-tabs-previous-company').removeClass('active');
                    $('#custom-previous-company').removeClass('show active');
                    $('#custom-tabs-payslip').addClass('active');
                    $('#custom-payslip').addClass('show active');
                    $('#custom-tabs-payslip').trigger("click");

                }

                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There is an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again.');
        $("#divLoader").hide();
    }
}

function CompanyUpdateConfirm() {
    if (detailempid != "") {
        $("#divLoader").show();
        $.ajax({

            url: "../Employee/CompanyUpdateConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            //data: data,
            data: "{'t_emno': '" + detailempid + "'}",
            success: function (result) {
                $("#divLoader").hide();
                var output = result;
                if (output === "SUCCESS") {

                    toastr.success('Company details updated successfully.');
                    var enabled = 5;
                    //var disabled = [0, 1, 2, 3, 4, 6, 7];
                    var disabled = [6, 7];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });
                    $('#custom-tabs-previous-company').removeClass('active');
                    $('#custom-previous-company').removeClass('show active');
                    $('#custom-tabs-payslip').addClass('active');
                    $('#custom-payslip').addClass('show active');
                    $('#custom-tabs-payslip').trigger("click");

                }

                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There is an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again.');
        $("#divLoader").hide();
    }
}

function PayslipInsertConfirm() {
    if (detailempid != "") {
        $("#divLoader").show();
        $.ajax({

            url: "../Employee/PayslipInsertConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            //data: data,
            data: "{'t_emno': '" + detailempid + "'}",
            success: function (result) {
                $("#divLoader").hide();
                var output = result;
                if (output === "SUCCESS") {

                    toastr.success('Payslip details inserted successfully.');
                    var enabled = 6;
                    //var disabled = [0, 1, 2, 3, 4, 5, 7];
                    var disabled = [7];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });
                    $('#custom-tabs-payslip').removeClass('active');
                    $('#custom-payslip').removeClass('show active');
                    $('#custom-tabs-reference').addClass('active');
                    $('#custom-reference').addClass('show active');
                    $('#custom-tabs-reference').trigger("click");

                }

                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There was an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again.');
        $("#divLoader").hide();
    }
}

function PayslipUpdateConfirm() {
    if (detailempid != "") {
        $("#divLoader").show();
        $.ajax({

            url: "../Employee/PayslipUpdateConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            //data: data,
            data: "{'t_emno': '" + detailempid + "'}",
            success: function (result) {
                $("#divLoader").hide();
                var output = result;
                if (output === "SUCCESS") {

                    toastr.success('Payslip details updated successfully.');
                    var enabled = 6;
                    //var disabled = [0, 1, 2, 3, 4, 5, 7];
                    var disabled = [7];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });
                    $('#custom-tabs-payslip').removeClass('active');
                    $('#custom-payslip').removeClass('show active');
                    $('#custom-tabs-reference').addClass('active');
                    $('#custom-reference').addClass('show active');
                    $('#custom-tabs-reference').trigger("click");

                }

                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There was an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again.');
        $("#divLoader").hide();
    }
}

function ReferenceInsertConfirm() {
    if (detailempid != "") {
        $("#divLoader").show();
        $.ajax({

            url: "../Employee/ReferenceInsertConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            //data: data,
            data: "{'t_emno': '" + detailempid + "'}",
            success: function (result) {
                var output = result;
                if (output === "SUCCESS") {
                    $("#divLoader").hide();
                    toastr.error('Reference details inserted successfully.');
                    var enabled = 7;
                    //var disabled = [0, 1, 2, 3, 4, 5, 6];

                    var disabled = [];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });
                    $('#custom-tabs-reference').removeClass('active');
                    $('#custom-reference').removeClass('show active');
                    $('#custom-tabs-certification').addClass('active');
                    $('#custom-certification').addClass('show active');
                    $('#custom-tabs-certification').trigger("click");

                }

                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There is an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again.');
        $("#divLoader").hide();
    }
}

function ReferenceUpdateConfirm() {
    if (detailempid != "") {
        $("#divLoader").show();
        $.ajax({

            url: "../Employee/ReferenceUpdateConfirm",
            type: "POST",
            //contentType: false,
            //processData: false,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            //data: data,
            data: "{'t_emno': '" + detailempid + "'}",
            success: function (result) {
                var output = result;
                if (output === "SUCCESS") {
                    $("#divLoader").hide();
                    toastr.success('Reference details updated successfully.');
                    var enabled = 7;
                    //var disabled = [0, 1, 2, 3, 4, 5, 6];
                    var disabled = [];
                    $("#tabs").tabs({ active: enabled, disabled: disabled });

                    //var disabled = [];

                    $('#custom-tabs-reference').removeClass('active');
                    $('#custom-reference').removeClass('show active');
                    $('#custom-tabs-certification').addClass('active');
                    $('#custom-certification').addClass('show active');
                    $('#custom-tabs-certification').trigger("click");

                }

                else {
                    toastr.error(result);
                    $("#divLoader").hide();
                }

            },
            error: function () {
                toastr.error("There was an error while inserting data!");
                $("#divLoader").hide();
            }
        });
    }
    else {
        toastr.error('Session Timeout,Please Login again.');
        $("#divLoader").hide();
    }
}


function UpdateDocument() {
    $("#divLoader").show();
    var res = validateDocumentDetails();
    if (res == false) {
        return false;
    }

    var uploadDocument = $("#uploadDocument").get(0).files;
    var data = new FormData();


    for (var i = 0; i < uploadDocument.length; i++) {
        data.append("uploadDocument", uploadDocument[i]);
    }
    var ddlDocType = $("#ddlDocType option:selected").text();
    var docpositionno = $('#txtdocposition').val();

    data.append("t_emno", detailempid);
    data.append("t_pono", docpositionno);
    data.append("t_dtyp", ddlDocType),
        data.append("t_docm", $('#txtdocumentno').val());
    data.append("t_imag", $('#txtdocimagname').val()),
        data.append("t_dpat", $('#txtdocimgpath').val());

    $.ajax({

        url: "../Employee/UpdateEmployeeDocument",
        type: "POST",
        contentType: false,
        processData: false,
        //contentType: "application/json;charset=utf-8",
        //dataType: "json",
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;
            if (output === "SUCCESS") {

                clearDocument();
                $('#myModalDocument').modal('hide');
                BindDocumentDetail();
                toastr.success('Record updated successfully.');

            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There is an error while inserting data!");
            $("#divLoader").hide();
        }
    });
}

function UpdateCompany() {
    $("#divLoader").show();
    var res = validateCompanyDetails();
    if (res == false) {
        return false;
    }

    var uploadExpCertificate = $("#uploadExpCertificate").get(0).files;
    var data = new FormData();


    for (var i = 0; i < uploadExpCertificate.length; i++) {
        data.append("uploadExpCertificate", uploadExpCertificate[i]);
    }
    var ddlfromyear = $("#ddlfromyear option:selected").text();
    var ddlfrommonth = $("#ddlfrommonth option:selected").text();
    var ddlToyear = $("#ddlToyear option:selected").text();
    var ddlTomonth = $("#ddlTomonth option:selected").text();
    var ddlcurcompany = $("#ddlcurcompany option:selected").text();
    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_orga", $('#txtOrganization').val());
    data.append("t_dnam", $('#txtDesignation').val());
    data.append("t_expe", $('#txtTotalExp').val());
    data.append("t_cuco", ddlcurcompany);
    data.append("t_year", ddlfromyear);
    data.append("t_mont", ddlfrommonth);
    data.append("t_toyr", ddlToyear);
    data.append("t_tomo", ddlTomonth);
    data.append("t_dyjp", $('#txtdescribejobprofile').val());
    data.append("t_pono", $('#txtcomposition').val());
    data.append("t_cena", $('#txtcomimagname').val());
    data.append("t_epat", $('#txtcomimgpath').val());


    $.ajax({

        url: "../Employee/UpdateEmployeeCompany",
        type: "POST",
        contentType: false,
        processData: false,
        //contentType: "application/json;charset=utf-8",
        //dataType: "json",
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;
            if (output === "SUCCESS") {

                ClearCompany();
                $('#myModalCompanyDetails').modal('hide');
                BindCompanyDetails();
                toastr.success('Record updated successfully.');

            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There is an error while inserting data!");
            $("#divLoader").hide();
        }
    });
}

function UpdatePayslip() {
    $("#divLoader").show();
    var res = validatePayslipDetails();
    if (res == false) {
        return false;
    }
    var uploadExpCertificate = $("#uploadPayslip").get(0).files;
    var data = new FormData();


    for (var i = 0; i < uploadExpCertificate.length; i++) {
        data.append("uploadPayslip", uploadExpCertificate[i]);
    }
    var ddlPayslipMonth = $("#ddlPayslipMonth option:selected").text();
    var ddlPayslipYear = $("#ddlPayslipYear option:selected").text();


    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_paym", ddlPayslipMonth);
    data.append("t_payy", ddlPayslipYear);
    data.append("t_pono", $('#txtpayposition').val());
    data.append("t_psna", $('#txtpayimagname').val());
    data.append("t_ppat", $('#txtpayimgpath').val());


    $.ajax({

        url: "../Employee/UpdateEmployeePayslip",
        type: "POST",
        contentType: false,
        processData: false,
        //contentType: "application/json;charset=utf-8",
        //dataType: "json",
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;

            if (output === "SUCCESS") {

                ClearPayslip();
                $('#myModalPayslipDetails').modal('hide');
                BindPayslipDetail();
                toastr.success('Record updated successfully.');

            }

            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There was an error while inserting data!");
            $("#divLoader").hide();
        }
    });
}

function UpdateReference() {
    $("#divLoader").show();
    var res = validateReferenceDetails();
    if (res == false) {
        return false;
    }

    var data = new FormData();
    var txtReferenceName = $('#txtReferenceName').val();
    var txtReferencePhoneno = $('#txtReferencePhoneno').val();
    var txtrefposition = $('#txtrefposition').val();

    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_pono", txtrefposition);
    data.append("t_rnam", txtReferenceName);
    data.append("t_phon", txtReferencePhoneno);
    $.ajax({

        url: "../Employee/UpdateEmployeeReference",
        type: "POST",
        contentType: false,
        processData: false,
        //contentType: "application/json;charset=utf-8",
        //dataType: "json",
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;

            if (output === "SUCCESS") {
                BindReferenceDetail();
                $('#myModalReferenceDetails').modal('hide');
                ClearReference()();
                toastr.success('Record updated successfully.');
            }
            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There was an error while inserting data!");
            $("#divLoader").hide();
        }
    });
}

function UpdateCertification() {
    $("#divLoader").show();
    var res = validateCertificationDetails();
    if (res == false) {
        return false;
    }

    var uploadCertification = $("#uploadCertification").get(0).files;
    var data = new FormData();


    for (var i = 0; i < uploadCertification.length; i++) {
        data.append("uploadCertification", uploadCertification[i]);
    }
    var txtCertificationName = $('#txtCertificationName').val();
    var txtCertificationMarks = $('#txtCertificationMarks').val();
    var txtcerposition = $('#txtcerposition').val();
    var txtcerimagname = $('#txtcerimagname').val();
    var txtcerimgpath = $('#txtcerimgpath').val();
    //Add the input element values
    data.append("t_emno", detailempid);
    data.append("t_pono", txtcerposition);
    data.append("t_cnam", txtCertificationName);
    data.append("t_cema", txtCertificationMarks);
    data.append("t_cena", txtcerimagname);
    data.append("t_cpat", txtcerimgpath);

    $.ajax({

        url: "../Employee/UpdateEmployeeCertification",
        type: "POST",
        contentType: false,
        processData: false,
        data: data,

        success: function (result) {
            $("#divLoader").hide();
            var output = result;

            if (output === "SUCCESS") {

                BindCertificationDetail();
                $('#myModalCertificationDetails').modal('hide');
                clearCertification();
                toastr.success('Record updated successfully.');
            }
            else {
                toastr.error(result);
                $("#divLoader").hide();
            }

        },
        error: function () {
            toastr.error("There was an error while inserting data!");
            $("#divLoader").hide();
        }
    });
}

function BindFamilyDetail() {
    $("#divLoader").show();
    //var table = $('#tblfamilydetails').DataTable();
    //table
    //    .clear()
    //    .draw();
    //destroy: true,
    //    table.destroy();


    $.ajax({
        url: "../Employee/BindFamily",
        type: "POST",
        data: '{t_emno :"' + detailempid + '"}',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            $("#divLoader").hide();
            if (data.length > 0) {
                var FamilyStatus = data[0].t_stat;
                if (FamilyStatus == 2 || 3) {
                    $('#btnUpdateFamily').show();
                    $('#btnAddFamily').hide();
                }
                else {
                    $('#btnAddFamily').show();
                    $('#btnUpdateFamily').hide();
                }
            }
            var datatableVariable = $('#tblfamilydetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "buttons": [],
                "bDestroy": true,

                data: data,

                columns: [
                    { "data": "t_emno", "title": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "title": "Position", "bVisible": false },
                    { "data": "t_rela", "title": "Relation" },
                    { "data": "t_nama", "title": "Member Name" },
                    {

                        data: null, "title": "Member DOB", render: function (data, type, row, meta) {
                            var dobStatus = "";
                            if (row.t_dobt == '01-01-1900') {
                                dobStatus = "NA";
                                return '<div' + dobStatus + '" class="badge bg-danger">' + dobStatus + '</div>';
                            }
                            else {
                                dobStatus = row.t_dobt;
                                return '<div' + dobStatus + '" class="badge bg-success">' + dobStatus + '</div>';
                            }

                        }
                    },
                    //{ "data": "t_dobt", "name": "Member DOB" },
                    { "data": "t_mema", "title": "Member Mobile No." },
                    { "data": "t_mmob", "title": "Member Email" },
                    {
                        "title": "Action", data: null, render: function (data, type, row, meta) {
                            return '<a href="#" onclick="return getbyFamilyDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="FamilyMemDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                        }
                    },

                ]
            }).buttons().container().appendTo('#tblfamilydetails_wrapper .col-md-6:eq(0)');

        }
    });

};
function BindEducationDetail() {

    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Employee/BindEducationDetails",
        data: '{t_emno :"' + detailempid + '"}',
        success: function (data) {
            $("#divLoader").hide();
            if (data.length > 0) {
                var EducationStatus = data[0].t_stat;
                if (EducationStatus == 2 || 3) {
                    $('#btnUpdateEducation').show();
                    $('#btnInsertEducation').hide();
                }
                else {
                    $('#btnInsertEducation').show();
                    $('#btnUpdateEducation').hide();
                }
            }

            var datatableVariable = $('#tbleducationdetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "buttons": [],
                "bDestroy": true,
                data: data,

                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_educ", "name": "Education" },
                    { "data": "t_boar", "name": "Board" },
                    { "data": "t_poyr", "name": "Passing Out Year" },
                    { "data": "t_scmd", "name": "School Medium" },
                    { "data": "t_crse", "name": "Course" },
                    { "data": "t_spec", "name": "Specialization" },
                    { "data": "t_univ", "name": "University/Institute" },
                    //{ "data": "t_coty", "name": "Course Type" },
                    {

                        data: null, "name": "Course Type", render: function (data, type, row, meta) {

                            var courseStatus = "";
                            if (row.t_coty == 1) {
                                courseStatus = "Part Time";
                                return '<div' + courseStatus + '" class="badge bg-success">' + courseStatus + '</div>';
                            }
                            else if (row.t_coty == 2) {
                                courseStatus = "Full Time";
                                return '<div' + courseStatus + '" class="badge bg-success">' + courseStatus + '</div>';
                            }
                            else if (row.t_coty == 3) {
                                courseStatus = "Correspondence";
                                return '<div' + courseStatus + '" class="badge bg-success">' + courseStatus + '</div>';
                            }
                            else if (row.t_coty == 4) {
                                courseStatus = "Distance Learning";
                                return '<div' + courseStatus + '" class="badge bg-success">' + courseStatus + '</div>';
                            }
                            else {
                                return '<div' + courseStatus + '" class="badge bg-success">' + courseStatus + '</div>'
                            }

                        }
                    },
                    { "data": "t_totm", "name": "Total Percentage" },
                    //{
                    //    "title": "Image", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick = "return ViewImg(\'' + row.t_ecpa + '\')" ><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_ecpa + '" width="50" height="50"></li ></a>'
                    //    }

                    //},
                    {
                        data: null, render: function (data, type, row, meta) {
                            return '<a href="' + row.t_ecpa + '" <i class="fas fa-download badge bg-primary" download></i>Download File</a>'
                        }
                    },
                    {
                        "title": "Action", data: null, render: function (data, type, row, meta) {
                            return '<a href="#" onclick="return getbyEducationDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="EducationDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                        }
                    },

                ]
            }).buttons().container().appendTo('#tbleducationdetails_wrapper .col-md-6:eq(0)');

        }
    });

};

function BindDocumentDetail() {
    $("#divLoader").show();

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Employee/BindDocumentDetails",
        data: '{t_emno :"' + detailempid + '"}',
        success: function (data) {
            $("#divLoader").hide();
            if (data.length > 0) {

                var DocumentStatus = data[0].t_stat;
                if (DocumentStatus == 2 || 3) {
                    $('#btnUpdateDocument').show();
                    $('#btnInsertDocument').hide();
                }
                else {
                    $('#btnInsertDocument').show();
                    $('#btnUpdateDocument').hide();
                }
            }
            var datatableVariable = $('#tbldocumentdetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "buttons": [],
                "bDestroy": true,
                data: data,

                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_dtyp", "name": "Document Type" },
                    { "data": "t_docm", "name": "Document No" },

                    //{
                    //    "title": "Image", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick = "return ViewImgDoc(\'' + row.t_dpat + '\')" ><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_dpat + '" width="50" height="50"></li ></a>'
                    //    }

                    //},
                    {
                        data: null, render: function (data, type, row, meta) {
                            return '<a href="' + row.t_dpat + '" <i class="fas fa-download badge bg-primary" download></i>Download File</a>'
                            //<img src="\'' + row.t_path + '\'" alt="" />onclick = "return ViewImg(\'' + row.t_path + '\')"

                        }

                    },
                    {
                        "title": "Action", data: null, render: function (data, type, row, meta) {
                            return '<a href="#" onclick="return getbyDocumenmtDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="DocumentDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                        }
                    },

                ]
            }).buttons().container().appendTo('#tbldocumentdetails_wrapper .col-md-6:eq(0)');

        }
    });

};

function BindCompanyDetails() {
    $("#divLoader").show();

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Employee/BindCompanyDetails",
        data: '{t_emno :"' + detailempid + '"}',
        success: function (data) {
            $("#divLoader").hide();
            if (data.length > 0) {
                var CompanyStatus = data[0].t_stat;
                if (CompanyStatus == 2 || 3) {
                    $('#btncompanyupdate').show();
                    $('#btncompanysubmit').hide();
                }
                else {
                    $('#btncompanysubmit').show();
                    $('#btncompanyupdate').hide();
                }
            }

            var datatableVariable = $('#tblcompanydetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "buttons": [],
                "bDestroy": true,
                data: data,

                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_orga", "name": "Organization" },
                    { "data": "t_dnam", "name": "Designation" },
                    { "data": "t_expe", "name": "Total Experience" },
                    { "data": "t_cuco", "name": "Current Company" },
                    { "data": "t_year", "name": "From Year" },
                    { "data": "t_mont", "name": "From Month" },
                    { "data": "t_toyr", "name": "To Year" },
                    { "data": "t_tomo", "name": "To Month" },
                    { "data": "t_dyjp", "name": "Job Profile" },
                    //{
                    //    "title": "Image", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick = "return ViewImgCom(\'' + row.t_epat + '\')" ><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_epat + '" width="50" height="50"></li ></a>'
                    //    }

                    //},
                    {
                        data: null, render: function (data, type, row, meta) {
                            return '<a href="' + row.t_epat + '" <i class="fas fa-download badge bg-primary" download></i>Download File</a>'
                            //<img src="\'' + row.t_path + '\'" alt="" />onclick = "return ViewImg(\'' + row.t_path + '\')"

                        }

                    },
                    {
                        "title": "Action", data: null, render: function (data, type, row, meta) {
                            return '<a href="#" onclick="return getbyCompanyDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="CompanyDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                        }
                    },

                ]
            }).buttons().container().appendTo('#tblcompanydetails_wrapper .col-md-6:eq(0)');

        }
    });

};

function BindPayslipDetail() {
    $("#divLoader").show();
    //var table = $('#tblpayslipdetails').DataTable();
    //table
    //    .clear()
    //    .draw();
    //destroy: true,
    //    table.destroy();

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Employee/BindPayslipDetails",
        data: '{t_emno :"' + detailempid + '"}',
        success: function (data) {
            $("#divLoader").hide();
            if (data.length > 0) {
                var PayslipStatus = data[0].t_stat;
                if (PayslipStatus == 2 || 3) {
                    $('#btnPayslipupdate').show();
                    $('#btnPayslipsubmit').hide();
                }
                else {
                    $('#btnPayslipsubmit').show();
                    $('#btnPayslipupdate').hide();
                }
            }
            var datatableVariable = $('#tblpayslipdetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "buttons": [],
                "bDestroy": true,
                data: data,
                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_paym", "name": "Payslip Month" },
                    { "data": "t_payy", "name": "Payslip Year" },
                    //{
                    //    "title": "Image", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick = "return ViewImgPay(\'' + row.t_ppat + '\')" ><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_ppat + '" width="50" height="50"></li ></a>'
                    //    }

                    //},
                    {
                        data: null, render: function (data, type, row, meta) {
                            return '<a href="' + row.t_ppat + '" <i class="fas fa-download badge bg-primary" download></i>Download File</a>'
                            //<img src="\'' + row.t_path + '\'" alt="" />onclick = "return ViewImg(\'' + row.t_path + '\')"

                        }

                    },
                    {
                        "title": "Action", data: null, render: function (data, type, row, meta) {
                            return '<a href="#" onclick="return getbyPayslipDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="PayslipDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                        }
                    },

                ]
            }).buttons().container().appendTo('#tblpayslipdetails_wrapper .col-md-6:eq(0)');

        }
    });

};
function BindReferenceDetail() {

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Employee/BindReferenceDetails",
        data: '{t_emno :"' + detailempid + '"}',
        success: function (data) {
            if (data.length > 0) {
                var ReferenceStatus = data[0].t_stat;
                if (ReferenceStatus == 2 || 3) {
                    $('#btnreferenceupdate').show();
                    $('#btnreferencesubmit').hide();
                    $('#btnfinalupdate').show();
                    $('#btnfinalsubmit').hide();
                }
                else {
                    $('#btnreferencesubmit').show();
                    $('#btnreferenceupdate').hide();
                    $('#btnfinalsubmit').show();
                    $('#btnfinalupdate').hide();
                }
            }

            var datatableVariable = $('#tblreferanancedetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "buttons": [],
                "bDestroy": true,
                data: data,
                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_rnam", "name": "Reference name" },
                    { "data": "t_phon", "name": "Reference phone no" },

                    {
                        "title": "Action", data: null, render: function (data, type, row, meta) {
                            return '<a href="#" onclick="return getbyReferenceDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="ReferenceDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                        }
                    },

                ]
            }).buttons().container().appendTo('#tblreferanancedetails_wrapper .col-md-6:eq(0)');

        }
    });

};
function BindCertificationDetail() {

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        url: "../Employee/BindCertificationDetails",
        data: '{t_emno :"' + detailempid + '"}',
        success: function (data) {
            if (data.length > 0) {
                var CertificationStatus = data[0].t_stat;
                if (CertificationStatus == 2 || 3) {
                    $('#btnfinalupdate').show();
                    $('#btnfinalsubmit').hide();
                }
                else {
                    $('#btnfinalsubmit').show();
                    $('#btnfinalupdate').hide();
                }
            }
            var datatableVariable = $('#tblcertificationdetails').DataTable({
                "responsive": true, "lengthChange": false, "autoWidth": false,
                "dom": 'Bfrtip',
                "buttons": [],
                "bDestroy": true,
                data: data,
                columns: [
                    { "data": "t_emno", "name": "Employee No.", "bVisible": false },
                    { "data": "t_pono", "name": "Position", "bVisible": false },
                    { "data": "t_cnam", "name": "Certification name" },
                    { "data": "t_cema", "name": "Certification Marks" },
                    //{
                    //    "title": "Image", data: null, render: function (data, type, row, meta) {
                    //        return '<a href="#" onclick = "return ViewImgCer(\'' + row.t_cpat + '\')" ><li class="list-inline-item"><img alt = "Avatar" class="table-avatar" src = "' + row.t_cpat + '" width="50" height="50"></li ></a>'
                    //    }

                    //},
                    {
                        data: null, render: function (data, type, row, meta) {
                            return '<a href="' + row.t_cpat + '" <i class="fas fa-download badge bg-primary" download></i>Download File</a>'
                            //<img src="\'' + row.t_path + '\'" alt="" />onclick = "return ViewImg(\'' + row.t_path + '\')"

                        }

                    },
                    {
                        "title": "Action", data: null, render: function (data, type, row, meta) {
                            return '<a href="#" onclick="return getbyCertificationDetails(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-primary"><i class="fa fa-pen"></i>Edit</a> | <a href="#" onclick="CertificationDelele(\'' + row.t_emno + '\',\'' + row.t_pono + '\')" class="badge bg-danger toastrDefaultWarning">Delete</a>';

                        }
                    },

                ]
            }).buttons().container().appendTo('#tblcertificationdetails_wrapper .col-md-6:eq(0)');

        }
    });

};

//function ViewImg(ImgPath) {

//    //document.getElementById("preview").src = ImgPath.substring(1, 50);
//    //var NewImagePath = ImgPath.substring(1, 50);
//    document.getElementById("preview").src = ImgPath;
//    var NewImagePath = ImgPath;
//    // jQuery to archive this,
//    $("#preview").attr("src", ('' + NewImagePath + ''));
//    document.getElementById('preview').style.display = 'block'
//    $('#myModalImage').modal('show');

//}

function getbyFamilyDetails(EmpId, PonoNo) {
    clearTextBoxFamily();
    $("#divLoader").show();
    $('#ddlRelation').css('border-color', 'lightgrey');
    $('#txtmembername').css('border-color', 'lightgrey');
    $('#dtpickrelativedob').css('border-color', 'lightgrey');
    $('#txtmemberemail').css('border-color', 'lightgrey');
    $('#txtmembermobileno').css('border-color', 'lightgrey');

    $.ajax({
        url: "../Employee/GetFamilyDetails",
        //data: '{t_emno :"' + detailempid + '"}',
        data: { t_emno: EmpId, t_pono: PonoNo },
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {

            $("#divLoader").hide();
            //$('#ddlact').empty();
            var result = data;
            var ddlRelati = result[0].t_rela;
            if (ddlRelati == "Father") {
                $("#ddlRelation").val(1);
            }
            else if (ddlRelati == "Mother") {
                $("#ddlRelation").val(2);
            }
            else if (ddlRelati == "Husaband") {
                $("#ddlRelation").val(3);
            }
            else if (ddlRelati == "Wife") {
                $("#ddlRelation").val(4);
            }
            else if (ddlRelati == "Son") {
                $("#ddlRelation").val(5);
            }
            else if (ddlRelati == "Daughter") {
                $("#ddlRelation").val(6);
            }
            //$("#ddlRelation option:contains(" + ddlRelati + ")").attr('selected', 'selected');
            //$("#ddlEducation option:contains(" + ddlEducation + ")").attr('selected', 'selected');
            //$('#ddlRelation').val(result[0].t_rela);
            $('#txtmembername').val(result[0].t_nama);
            var dateofbirthrel = '';
            var retrivedob = result[0].t_dobt;
            if (retrivedob === '01-01-1900') {
                dateofbirthrel = '';
            }
            else {
                dateofbirthrel = result[0].t_dobt;
            }
            $('#dtpickrelativedob').val(dateofbirthrel);
            $('#txtmemberemail').val(result[0].t_mema);
            $('#txtmembermobileno').val(result[0].t_mmob);
            $('#txtfamposition').val(result[0].t_pono);


            $('#myModalFamily').modal('show');
            $('#btnfamilyUpdate').show();
            $('#btnfamilyAdd').hide();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
            $("#divLoader").hide();
        }
    });
    return false;
}
function getbyEducationDetails(EmpId, PonoNo) {
    ClearEducation();
    //$('#custom-tabs-education').addClass('active');
    //$('#custom-education').addClass('show active');
    //$('#custom-tabs-education').trigger("click");

    $('#ddlEducation').css('border-color', 'lightgrey');
    $('#ddlboard').css('border-color', 'lightgrey');
    $('#ddlschoolmedium').css('border-color', 'lightgrey');
    $('#txtcourse').css('border-color', 'lightgrey');
    $('#txtSpecialization').css('border-color', 'lightgrey');
    $('#txtuniversity').css('border-color', 'lightgrey');
    $('#ddlcoursetype').css('border-color', 'lightgrey');
    $('#txttotalpercentage').css('border-color', 'lightgrey');
    $('#ddlpassingoutyear').css('border-color', 'lightgrey');

    $.ajax({
        url: "../Employee/GetEducationDetails",
        //data: '{t_emno :"' + detailempid + '"}',
        data: { t_emno: EmpId, t_pono: PonoNo },
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {


            var result = data;
            var ddlEducation = result[0].t_educ;

            if (ddlEducation == "10th" || ddlEducation == "12th") {

                $("#ddlboard").removeAttr("disabled");
                $("#ddlschoolmedium").removeAttr("disabled");

                $("#txtcourse").attr("disabled", "disabled");
                $("#txtSpecialization").attr("disabled", "disabled");
                $("#txtuniversity").attr("disabled", "disabled");
                $("#ddlcoursetype").attr("disabled", "disabled");

                $("#txtcourse").val('');
                $("#txtSpecialization").val('');
                $("#txtuniversity").val('');
                //$("#ddlcoursetype option:selected").text("--Select--")

            }
            if (ddlEducation == "Graduation/Diploma" || ddlEducation == "Master/PostGraduation") {


                $("#txtcourse").removeAttr("disabled");
                $("#txtSpecialization").removeAttr("disabled");
                $("#txtuniversity").removeAttr("disabled");
                $("#ddlcoursetype").removeAttr("disabled");

                $("#ddlboard").attr("disabled", "disabled");
                //$("#ddlboard option:selected").text("--Select--")
                $("#ddlschoolmedium").attr("disabled", "disabled");

                //$("#ddlcoursemedium option:selected").text("--Select--")
            }


            var ddlboard = result[0].t_boar;
            var ddlschollmedium = result[0].t_scmd;
            //var ddlcoursetype = result[0].t_coty;

            if (ddlEducation == "10th") {
                $("#ddlEducation").val(1);
            }
            else if (ddlEducation == "12th") {
                $("#ddlEducation").val(2);
            }
            else if (ddlEducation == "Graduation/Diploma") {
                $("#ddlEducation").val(3);
            }
            else if (ddlEducation == "Master/PostGraduation") {
                $("#ddlEducation").val(4);
            }
            //$("#ddlEducation option:contains(" + ddlEducation + ")").attr('selected', 'selected');

            if (ddlboard == "CBSE") {
                $("#ddlboard").val(1);
            }
            else if (ddlboard == "CISCE(ICSE/ISC)") {
                $("#ddlboard").val(2);
            }
            else if (ddlboard == "Diploma") {
                $("#ddlboard").val(3);
            }
            else if (ddlboard == "National Open School") {
                $("#ddlboard").val(4);
            }
            else if (ddlboard == "IB(Internation Baccalureate)") {
                $("#ddlboard").val(5);
            }
            else if (ddlboard == "Andaman & Nicobar") {
                $("#ddlboard").val(7);
            }
            else if (ddlboard == "Andhra Pradesh") {
                $("#ddlboard").val(8);
            }
            else if (ddlboard == "Arunachal Pradesh") {
                $("#ddlboard").val(9);
            }
            else if (ddlboard == "Assam") {
                $("#ddlboard").val(10);
            }
            else if (ddlboard == "Bihar") {
                $("#ddlboard").val(11);
            }
            else if (ddlboard == "Chandigarh") {
                $("#ddlboard").val(12);
            }
            else if (ddlboard == "Chhattisgarh") {
                $("#ddlboard").val(13);
            }
            else if (ddlboard == "Dadra & Nagar Haveli") {
                $("#ddlboard").val(14);
            }
            else if (ddlboard == "Daman & Diu") {
                $("#ddlboard").val(15);
            }
            else if (ddlboard == "Delhi") {
                $("#ddlboard").val(16);
            }
            else if (ddlboard == "Goa") {
                $("#ddlboard").val(17);
            }
            else if (ddlboard == "Gujarat") {
                $("#ddlboard").val(18);
            }
            else if (ddlboard == "Haryana") {
                $("#ddlboard").val(19);
            }
            else if (ddlboard == "Himachal Pradesh") {
                $("#ddlboard").val(20);
            }
            else if (ddlboard == "Jammu & Kashmir") {
                $("#ddlboard").val(21);
            }
            else if (ddlboard == "Jharkhand") {
                $("#ddlboard").val(22);
            }
            else if (ddlboard == "Karnataka") {
                $("#ddlboard").val(23);
            }
            else if (ddlboard == "Kerala") {
                $("#ddlboard").val(24);
            }
            else if (ddlboard == "Lakshadweep") {
                $("#ddlboard").val(25);
            }
            else if (ddlboard == "Madhya Pradesh") {
                $("#ddlboard").val(26);
            }
            else if (ddlboard == "Maharashtra") {
                $("#ddlboard").val(27);
            }
            else if (ddlboard == "Manipur") {
                $("#ddlboard").val(28);
            }
            else if (ddlboard == "Meghalaya") {
                $("#ddlboard").val(29);
            }
            else if (ddlboard == "Mizoram") {
                $("#ddlboard").val(30);
            }
            else if (ddlboard == "Nagaland") {
                $("#ddlboard").val(31);
            }
            else if (ddlboard == "Orissa") {
                $("#ddlboard").val(32);
            }
            else if (ddlboard == "Pondicherry") {
                $("#ddlboard").val(33);
            }
            else if (ddlboard == "Punjab") {
                $("#ddlboard").val(34);
            }
            else if (ddlboard == "Rajasthan") {
                $("#ddlboard").val(35);
            }
            else if (ddlboard == "Sikkim") {
                $("#ddlboard").val(36);
            }
            else if (ddlboard == "Tamil Nadu") {
                $("#ddlboard").val(37);
            }
            else if (ddlboard == "Tripura") {
                $("#ddlboard").val(38);
            }
            else if (ddlboard == "Uttar Pradesh") {
                $("#ddlboard").val(39);
            }
            else if (ddlboard == "Uttaranchal") {
                $("#ddlboard").val(40);
            }
            else if (ddlboard == "West Bengal") {
                $("#ddlboard").val(41);
            }
            else if (ddlboard == "Other") {
                $("#ddlboard").val(42);
            }


            //$("#ddlboard option:contains(" + ddlboard + ")").attr('selected', 'selected');
            if (ddlschollmedium == "Assamese / Asomiya") {
                $("#ddlschoolmedium").val(1);
            }
            else if (ddlschollmedium == "Bengali / Bangla") {
                $("#ddlschoolmedium").val(2);
            }
            else if (ddlschollmedium == "English") {
                $("#ddlschoolmedium").val(3);
            }
            else if (ddlschollmedium == "Gujarati") {
                $("#ddlschoolmedium").val(4);
            }
            else if (ddlschollmedium == "Hindi") {
                $("#ddlschoolmedium").val(5);
            }
            else if (ddlschollmedium == "Kannada") {
                $("#ddlschoolmedium").val(6);
            }
            else if (ddlschollmedium == "Kashmiri") {
                $("#ddlschoolmedium").val(7);
            }
            else if (ddlschollmedium == "Konkani") {
                $("#ddlschoolmedium").val(8);
            }
            else if (ddlschollmedium == "Malayalam / Asomiya") {
                $("#ddlschoolmedium").val(9);
            }
            else if (ddlschollmedium == "Manipuri / Bangla") {
                $("#ddlschoolmedium").val(10);
            }
            else if (ddlschollmedium == "Marathi") {
                $("#ddlschoolmedium").val(11);
            }
            else if (ddlschollmedium == "Oriya") {
                $("#ddlschoolmedium").val(12);
            }
            else if (ddlschollmedium == "Punjabi / Asomiya") {
                $("#ddlschoolmedium").val(13);
            }
            else if (ddlschollmedium == "Sanskrit / Bangla") {
                $("#ddlschoolmedium").val(14);
            }
            else if (ddlschollmedium == "Tamil") {
                $("#ddlschoolmedium").val(15);
            }
            else if (ddlschollmedium == "Telugu") {
                $("#ddlschoolmedium").val(16);
            }
            else if (ddlschollmedium == "Urdu") {
                $("#ddlschoolmedium").val(17);
            }
            else if (ddlschollmedium == "Other") {
                $("#ddlschoolmedium").val(18);
            }

            //$("#ddlschoolmedium option:contains(" + ddlschollmedium + ")").attr('selected', 'selected');
            //$('#txtcourse').val(result[0].t_crse);
            //$("#ddlEducation option:contains(" + ddlEducation + ")").attr('selected', 'selected');
            $('#txtcourse').val(result[0].t_crse);
            $('#txtSpecialization').val(result[0].t_spec);
            $('#txtuniversity').val(result[0].t_univ);
            //if (ddlcoursetype == "") {
            //    $('#ddlcoursetype').val('');
            //}
            //else {
            //$("#ddlcoursetype option:contains(" + ddlcoursetype + ")").attr('selected', 'selected');
            $("#ddlcoursetype").val(result[0].t_coty);
            //}
            $('#txttotalpercentage').val(result[0].t_totm);
            //$("#ddlpassingoutyear option:contains(" + ddlpassingoutyear + ")").attr('selected', 'selected');
            var ddlpassingoutyear = result[0].t_poyr;
            $("#ddlpassingoutyear").val(ddlpassingoutyear);
            $('#txteduposition').val(result[0].t_pono);
            $('#lblEducationCer').html(result[0].t_cena);
            $('#txteduimagename').val(result[0].t_cena);
            $('#txteduimagepath').val(result[0].t_ecpa);


            $('#myModalEducation').modal('show');
            $('#btnEducationUpdate').show();
            $('#btnEducationAdd').hide();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
            $("#divLoader").hide();
        }
    });
    return false;
}
function getbyDocumenmtDetails(EmpId, PonoNo) {
    clearDocument();

    $('#ddlDocType').css('border-color', 'lightgrey');
    $('#txtdocumentno').css('border-color', 'lightgrey');


    $.ajax({
        url: "../Employee/GetDocumentDetails",
        //data: '{t_emno :"' + detailempid + '"}',
        data: { t_emno: EmpId, t_pono: PonoNo },
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {
            var result = data;
            var ddlDocType = result[0].t_dtyp;
            $('#txtdocposition').val(result[0].t_pono);
            $("#ddlDocType option:contains(" + ddlDocType + ")").attr('selected', 'selected');
            $('#txtdocumentno').val(result[0].t_docm);
            $('#lbluploadDocument').html(result[0].t_imag);
            $('#txtdocimagname').val(result[0].t_imag);
            $('#txtdocimgpath').val(result[0].t_dpat);


            $('#myModalDocument').modal('show');
            $('#btnDocUpdate').show();
            $('#btnDocAdd').hide();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}
function getbyCompanyDetails(EmpId, PonoNo) {
    ClearCompany();
    $('#ddlfromyear').css('border-color', 'lightgrey');
    $('#ddlfrommonth').css('border-color', 'lightgrey');
    $('#ddlToyear').css('border-color', 'lightgrey');
    $('#ddlTomonth').css('border-color', 'lightgrey');

    $('#txtOrganization').css('border-color', 'lightgrey');
    $('#txtDesignation').css('border-color', 'lightgrey');
    $('#txtTotalExp').css('border-color', 'lightgrey');
    $('#ddlcurcompany').css('border-color', 'lightgrey');
    $('#txtdescribejobprofile').css('border-color', 'lightgrey');

    $.ajax({
        url: "../Employee/GetCompanyDetails",
        //data: '{t_emno :"' + detailempid + '"}',
        data: { t_emno: EmpId, t_pono: PonoNo },
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {
            var result = data;
            var ddlfromyear = result[0].t_year;
            var ddlfrommonth = result[0].t_mont;
            var ddlToyear = result[0].t_toyr;
            var ddlTomonth = result[0].t_tomo;

            $('#txtcomposition').val(result[0].t_pono);
            $('#txtOrganization').val(result[0].t_orga);
            $('#txtDesignation').val(result[0].t_dnam);
            $('#txtTotalExp').val(result[0].t_expe);
            $("#ddlcurcompany option:selected").text(result[0].t_cuco);
            $('#txtdescribejobprofile').val(result[0].t_dyjp);
            $("#ddlfromyear option:selected").text(ddlfromyear);
            $("#ddlfrommonth option:selected").val(ddlfrommonth);
            $("#ddlToyear option:selected").text(ddlToyear);
            $("#ddlTomonth option:selected").val(ddlTomonth);

            $('#lbluploadExpCertificate').html(result[0].t_cena);
            $('#txtcomimagname').val(result[0].t_cena);
            $('#txtcomimgpath').val(result[0].t_epat);

            $('#myModalCompanyDetails').modal('show');
            $('#btnCompanyUpdate').show();
            $('#btnCompanyAdd').hide();


        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}
function getbyPayslipDetails(EmpId, PonoNo) {
    ClearPayslip();
    $('#ddlPayslipMonth').css('border-color', 'lightgrey');
    $('#ddlPayslipYear').css('border-color', 'lightgrey');

    $.ajax({
        url: "../Employee/GetPayslipDetails",
        //data: '{t_emno :"' + detailempid + '"}',
        data: { t_emno: EmpId, t_pono: PonoNo },
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {
            var result = data;
            var ddlPayslipMonth = result[0].t_paym;
            var ddlPayslipYear = result[0].t_payy;

            $("#ddlPayslipMonth option:selected").text(ddlPayslipMonth);
            $("#ddlPayslipYear option:selected").text(ddlPayslipYear);
            $('#txtpayposition').val(result[0].t_pono);

            $('#lbluploadPayslip').html(result[0].t_psna);
            $('#txtpayimagname').val(result[0].t_psna);
            $('#txtpayimgpath').val(result[0].t_ppat);
            //$('#uploadPayslip').innerHTML(result[0].t_psna);
            // $('input[type=file]').val(result[0].t_psna);

            $('#myModalPayslipDetails').modal('show');
            $('#btnPayslipUpdate').show();
            $('#btnPayslipAdd').hide();


        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}
function getbyReferenceDetails(EmpId, PonoNo) {
    ClearReference();
    $('#txtReferenceName').css('border-color', 'lightgrey');
    $('#txtReferencePhoneno').css('border-color', 'lightgrey');

    $.ajax({
        url: "../Employee/GetReferenceDetails",
        //data: '{t_emno :"' + detailempid + '"}',
        data: { t_emno: EmpId, t_pono: PonoNo },
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {
            var result = data;


            $('#txtrefposition').val(result[0].t_pono);
            $('#txtReferenceName').val(result[0].t_rnam);
            $('#txtReferencePhoneno').val(result[0].t_phon);

            $('#myModalReferenceDetails').modal('show');
            $('#btnRefUpdate').show();
            $('#btnRefAdd').hide();


        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}

function getbyCertificationDetails(EmpId, PonoNo) {
    clearCertification();
    $('#txtCertificationName').css('border-color', 'lightgrey');
    $('#txtCertificationMarks').css('border-color', 'lightgrey');

    $.ajax({
        url: "../Employee/GetCertificationDetails",
        data: { t_emno: EmpId, t_pono: PonoNo },
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (data) {
            var result = data;


            $('#txtcerposition').val(result[0].t_pono);
            $('#txtCertificationName').val(result[0].t_cnam);
            $('#txtCertificationMarks').val(result[0].t_cema);
            $('#lbluploadCertification').html(result[0].t_cena);

            $('#txtcerimagname').val(result[0].t_cena);
            $('#txtcerimgpath').val(result[0].t_cpat);
            //$('#uploadCertification').val(result[0].t_cena);

            $('#myModalCertificationDetails').modal('show');
            $('#btnCertificationUpdate').show();
            $('#btnCertificationAdd').hide();

        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}
function clearTextBoxFamily() {

    //$("#ddlRelation option:selected").text("");
    $("#ddlRelation").val(0);
    $('#txtmembername').val("");
    $('#dtpickrelativedob').val("");
    $('#txtmemberemail').val("");
    $('#txtmembermobileno').val("");

    $('#btnfamilyUpdate').hide();
    $('#btnfamilyAdd').show();

    $('#ddlRelation').css('border-color', 'lightgrey');
    $('#txtmembername').css('border-color', 'lightgrey');
    $('#dtpickrelativedob').css('border-color', 'lightgrey');
    $('#txtmemberemail').css('border-color', 'lightgrey');
    $('#txtmembermobileno').css('border-color', 'lightgrey');
}

function ClearEducation() {

    $("#ddlboard").removeAttr("disabled");
    $("#ddlcoursemedium").removeAttr("disabled");
    $("#txtcourse").removeAttr("disabled");
    $("#txtSpecialization").removeAttr("disabled");
    $("#ddlcoursetype").removeAttr("disabled");

    //$("#ddlEducation").val(0);
    //$("#ddlboard").val(0);
    //$("#ddlcoursetype").val(0);
    //$("#ddlcoursemedium").val(0);
    //$("#ddlpassingoutyear").val(0);
    $('#uploadEduCertificate').val('');
    $('#btnEducationUpdate').hide();
    $('#btnEducationAdd').show();


    $('#txtcourse').val('');
    $("#txtSpecialization").val('');
    $('#txtuniversity').val('');
    $('#txttotalpercentage').val('');
    $('#txteduimagename').val('');
    $('#txteduimagepath').val('');
    $('#txteduposition').val('');
    // $('#uploadEduCertificate').val('');
    $("#uploadEduCertificate").val("");
    $("#ddlboard").val(0);
    $("#ddlEducation").val(0);
    $("#ddlschoolmedium").val(0);
    $("#ddlcoursetype").val(0);
    $("#ddlpassingoutyear").val('');
    $("#txttotalpercentage").val('');
    $('#lblEducationCer').html('');


}

function clearDocument() {

    $('#txtdocumentno').val('');
    //$("#ddlDocType option:selected").text("");
    $('#uploadDocument').val('');
    $('#btnDocUpdate').hide();
    $('#btnDocAdd').show();
    $('#uploadDocument').val('');
    $('#lbluploadDocument').html('');

}
function ClearCompany() {


    //$("#ddlfromyear option:selected").text('');
    //$("#ddlfrommonth option:selected").text('');
    //$("#ddlToyear option:selected").text('');
    //$("#ddlTomonth option:selected").text('');
    //$("#ddlcurcompany option:selected").text('');
    //Add the input element value
    $('#txtOrganization').val('');
    $('#txtDesignation').val('');
    $('#txtTotalExp').val('');
    $('#txtdescribejobprofile').val('');
    $('#uploadExpCertificate').val('');
    $('#btnCompanyUpdate').hide();
    $('#btnCompanyAdd').show();
    $('#lbluploadExpCertificate').html('');
}
function ClearPayslip() {
    $("#ddlPayslipMonth option:selected").val(0);
    $("#ddlPayslipYear option:selected").val(0);
    $('#btnPayslipUpdate').hide();
    $('#btnPayslipAdd').show();
    $('#uploadPayslip').val('');
    $('#lbluploadPayslip').html('');
}
function ClearReference() {

    $('#txtReferenceName').val('');
    $('#txtReferencePhoneno').val('');
    $('#btnRefUpdate').hide();
    $('#btnRefAdd').show();
}

function clearCertification() {

    $('#txtCertificationName').val('');
    $('#txtCertificationMarks').val('');
    $('#btnCertificationUpdate').hide();
    $('#btnCertificationAdd').show();
    $('#uploadCertification').val('');
    $('#lbluploadCertification').html('');
}
//function for deleting family record  
function FamilyMemDelele(EmpId, PonoNo) {
    //var ans = confirm("Are you sure you want to delete this Record?");
    //if (ans) {
    Swal.fire({
        title: 'Do you want to delete the record?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        denyButtonText: `Don't delete`,
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "../Employee/FamilyDelete",
                //data: { t_emno: EmpId, t_pono: PonoNo },
                data: '{t_emno:"' + EmpId + '",t_pono:"' + PonoNo + '"}',
                type: "POST",
                contentType: "application/json;charset=UTF-8",
                dataType: "json",
                success: function (result) {
                    var output = result;
                    if (output === "SUCCESS") {
                        BindFamilyDetail();
                        toastr.success('Record deleted successfully.');
                    }
                },
                error: function (errormessage) {
                    alert(errormessage.responseText);
                }
            });
            Swal.fire('Deleted!', '', 'success')
        } else if (result.isDenied) {
            Swal.fire('Records are not deleted', '', 'info')
        }
    })
}
//function for deleting education record  
function EducationDelele(EmpId, PonoNo) {

    //var ans = confirm("Are you sure you want to delete this Record?");
    //if (ans) {
    Swal.fire({
        title: 'Do you want to delete the record?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        denyButtonText: `Don't delete`,
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "../Employee/EducationDelele",
                data: '{t_emno:"' + EmpId + '",t_pono:"' + PonoNo + '"}',
                type: "POST",
                contentType: "application/json;charset=UTF-8",
                dataType: "json",
                success: function (result) {

                    var output = result;
                    if (output === "SUCCESS") {
                        BindEducationDetail();
                        //toastr.warning('Record deleted successfully...!!!');
                    }
                },
                error: function (errormessage) {
                    alert(errormessage.responseText);
                }
            });
            Swal.fire('Deleted!', '', 'success')
        } else if (result.isDenied) {
            Swal.fire('Records are not deleted', '', 'info')
        }
    })
    //}
}

function DocumentDelele(EmpId, PonoNo) {
    //var ans = confirm("Are you sure you want to delete this Record?");
    //if (ans) {
    Swal.fire({
        title: 'Do you want to delete the record?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        denyButtonText: `Don't delete`,
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "../Employee/DocumentDelele",
                data: '{t_emno:"' + EmpId + '",t_pono:"' + PonoNo + '"}',
                type: "POST",
                contentType: "application/json;charset=UTF-8",
                dataType: "json",
                success: function (result) {
                    var output = result;
                    if (output === "SUCCESS") {

                        BindDocumentDetail();
                        //toastr.warning('Record deleted successfully...!!!');
                    }
                },
                error: function (errormessage) {
                    alert(errormessage.responseText);
                }
            });
            Swal.fire('Deleted!', '', 'success')
        } else if (result.isDenied) {
            Swal.fire('Records are not deleted', '', 'info')
        }
    })
    //}
}


function CompanyDelele(EmpId, PonoNo) {
    //var ans = confirm("Are you sure you want to delete this Record?");
    //if (ans) {
    Swal.fire({
        title: 'Do you want to delete the record?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        denyButtonText: `Don't delete`,
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "../Employee/CompanyDelele",
                data: '{t_emno:"' + EmpId + '",t_pono:"' + PonoNo + '"}',
                type: "POST",
                contentType: "application/json;charset=UTF-8",
                dataType: "json",
                success: function (result) {
                    var output = result;
                    if (output === "SUCCESS") {

                        BindCompanyDetails();
                        //toastr.warning('Record deleted successfully...!!!');
                    }
                },
                error: function (errormessage) {
                    alert(errormessage.responseText);
                }
            });
            Swal.fire('Deleted!', '', 'success')
        } else if (result.isDenied) {
            Swal.fire('Records are not deleted', '', 'info')
        }
    })
    //}
}
function PayslipDelele(EmpId, PonoNo) {
    //var ans = confirm("Are you sure you want to delete this Record?");
    //if (ans) {
    Swal.fire({
        title: 'Do you want to delete the record?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        denyButtonText: `Don't delete`,
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "../Employee/PayslipDelele",
                data: '{t_emno:"' + EmpId + '",t_pono:"' + PonoNo + '"}',
                type: "POST",
                contentType: "application/json;charset=UTF-8",
                dataType: "json",
                success: function (result) {
                    var output = result;
                    if (output === "SUCCESS") {

                        BindPayslipDetail();
                        //toastr.warning('Record deleted successfully...!!!');
                    }
                },
                error: function (errormessage) {
                    alert(errormessage.responseText);
                }
            });
            Swal.fire('Deleted!', '', 'success')
        } else if (result.isDenied) {
            Swal.fire('Records are not deleted', '', 'info')
        }
    })
    //}
}

function ReferenceDelele(EmpId, PonoNo) {
    //var ans = confirm("Are you sure you want to delete this Record?");
    //if (ans) {
    Swal.fire({
        title: 'Do you want to delete the record?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        denyButtonText: `Don't delete`,
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "../Employee/ReferenceDelele",
                data: '{t_emno:"' + EmpId + '",t_pono:"' + PonoNo + '"}',
                type: "POST",
                contentType: "application/json;charset=UTF-8",
                dataType: "json",
                success: function (result) {
                    var output = result;
                    if (output === "SUCCESS") {

                        BindReferenceDetail();
                        toastr.success('Record deleted successfully...!!!');
                    }
                },
                error: function (errormessage) {
                    alert(errormessage.responseText);
                }
            });
            Swal.fire('Deleted!', '', 'success')
        } else if (result.isDenied) {
            Swal.fire('Records are not deleted', '', 'info')
        }
    })
    //}
}


function CertificationDelele(EmpId, PonoNo) {
    //var ans = confirm("Are you sure you want to delete this Record?");
    //if (ans) { Swal.fire('Deleted!', '', 'success')
    Swal.fire({
        title: 'Do you want to delete the record?',
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        denyButtonText: `Don't delete`,
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "../Employee/CertificationDelele",
                data: '{t_emno:"' + EmpId + '",t_pono:"' + PonoNo + '"}',
                type: "POST",
                contentType: "application/json;charset=UTF-8",
                dataType: "json",
                success: function (result) {
                    var output = result;
                    if (output === "SUCCESS") {

                        BindCertificationDetail();
                        //toastr.warning('Record deleted successfully...!!!');
                    }
                },
                error: function (errormessage) {
                    alert(errormessage.responseText);
                }
            });
            Swal.fire('Deleted!', '', 'success')
        } else if (result.isDenied) {
            Swal.fire('Records are not deleted', '', 'info')
        }
    })
    //}
}

//Valdidation using jquery  
function validateBasicDetails() {
    var isValid = true;
    if ($('#txtfirstname').val().trim() == "") {
        $('#txtfirstname').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtfirstname').css('border-color', 'lightgrey');
    }
    if ($('#txtmiddlename').val().trim() == "") {
        $('#txtmiddlename').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtmiddlename').css('border-color', 'lightgrey');
    }
    if ($('#txtlastname').val().trim() == "") {
        $('#txtlastname').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();

    }
    else {
        $('#txtlastname').css('border-color', 'lightgrey');
    }
    if ($('#txtmothername').val().trim() == "") {
        $('#txtmothername').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtmothername').css('border-color', 'lightgrey');
    }

    if ($("#ddlgender option:selected").text() == "") {
        $('#ddlgender').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlgender').css('border-color', 'lightgrey');
    }

    if ($('#dtpickdob').val().trim() == "") {
        $('#dtpickdob').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#dtpickdob').css('border-color', 'lightgrey');
    }
    if ($('#txtplaceofbirth').val().trim() == "") {
        $('#txtplaceofbirth').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtplaceofbirth').css('border-color', 'lightgrey');
    }
    if ($('#txtcurrentloc').val().trim() == "") {
        $('#txtcurrentloc').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtcurrentloc').css('border-color', 'lightgrey');
    }
    if ($('#txtPermanant').val().trim() == "") {
        $('#txtPermanant').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtPermanant').css('border-color', 'lightgrey');
    }
    if ($('#txtCorrespondence').val().trim() == "") {
        $('#txtCorrespondence').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtCorrespondence').css('border-color', 'lightgrey');
    }
    if ($('#txtmobileno').val().trim() == "") {
        $('#txtmobileno').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtmobileno').css('border-color', 'lightgrey');
    }
    if ($('#txtemergencymob').val().trim() == "") {
        $('#txtemergencymob').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtemergencymob').css('border-color', 'lightgrey');
    }

    if ($("#ddlMarriedStatus option:selected").text() == "") {
        $('#ddlMarriedStatus').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlMarriedStatus').css('border-color', 'lightgrey');
    }
    //if ($('#dtpickdom').val().trim() == "") {
    //    $('#dtpickdom').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#dtpickdom').css('border-color', 'lightgrey');
    //}
    if ($('#txtEmail').val().trim() == "") {
        $('#txtEmail').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtEmail').css('border-color', 'lightgrey');
    }
    if ($("#ddlstate option:selected").text().trim() == "--Select--") {
        $('#ddlstate').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtstate').css('border-color', 'lightgrey');
    }
    if ($('#txtcity').val().trim() == "") {
        $('#txtcity').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtcity').css('border-color', 'lightgrey');
    }
    if ($('#txtnationality').val().trim() == "") {
        $('#txtnationality').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtnationality').css('border-color', 'lightgrey');
    }
    //var imgVal = $('#postedFiles').val(); 
    ////this.classList.add('sel');
    //if (imgVal.trim() == '') {
    //    $('#postedFiles').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#postedFiles').css('border-color', 'lightgrey');
    //} 
    //if ($('#uploadresume').val().trim() == "") {
    //    $('#uploadresume').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#uploadresume').css('border-color', 'lightgrey');
    //} 
    //if ($('#txtmothertongue').val().trim() == "") {
    //    $('#txtmothertongue').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#txtmothertongue').css('border-color', 'lightgrey');
    //}
    //if ($('#txtReligion').val().trim() == "") {
    //    $('#txtReligion').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#txtReligion').css('border-color', 'lightgrey');
    //}
    //if ($('#txtcast').val().trim() == "") {
    //    $('#txtcast').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#txtcast').css('border-color', 'lightgrey');
    //}

    if ($("#ddlEmployeeType option:selected").text() == "--Select--") {
        $('#ddlEmployeeType').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlEmployeeType').css('border-color', 'lightgrey');
    }
    if ($("#ddltotalworkexp option:selected").text() == "") {
        $('#ddltotalworkexp').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddltotalworkexp').css('border-color', 'lightgrey');
    }

    //if ($('#txtEsiccode').val().trim() == "") {
    //    $('#txtEsiccode').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#txtEsiccode').css('border-color', 'lightgrey');
    //}

    //if ($('#txtbankaccount').val().trim() == "") {
    //    $('#txtbankaccount').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#txtbankaccount').css('border-color', 'lightgrey');
    //}
    //if ($('#txtbankname').val().trim() == "") {
    //    $('#txtbankname').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#txtbankname').css('border-color', 'lightgrey');
    //}
    //if ($('#txtifsccode').val().trim() == "") {
    //    $('#txtifsccode').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#txtifsccode').css('border-color', 'lightgrey');
    //}
    return isValid;
}
function validateFamilyDetails() {
    var isValid = true;

    if ($("#ddlRelation option:selected").text() == "") {
        $('#ddlRelation').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlRelation').css('border-color', 'lightgrey');
    }
    if ($('#txtmembername').val().trim() == "") {
        $('#txtmembername').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtmembername').css('border-color', 'lightgrey');
    }
    return isValid;
}
function validateDocumentDetails() {
    var isValid = true;

    if ($("#ddlDocType option:selected").text() == "--Select--") {
        $('#ddlDocType').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlDocType').css('border-color', 'lightgrey');
    }
    if ($('#txtdocumentno').val().trim() == "") {
        $('#txtdocumentno').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtdocumentno').css('border-color', 'lightgrey');
    }

    return isValid;
}
function validateCompanyDetails() {
    var isValid = true;
    if ($('#txtOrganization').val().trim() == "") {
        $('#txtOrganization').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtOrganization').css('border-color', 'lightgrey');
    }
    if ($('#txtDesignation').val().trim() == "") {
        $('#txtDesignation').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtDesignation').css('border-color', 'lightgrey');
    }
    if ($('#txtTotalExp').val().trim() == "") {
        $('#txtTotalExp').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtTotalExp').css('border-color', 'lightgrey');
    }
    if ($("#ddlcurcompany option:selected").text() == "") {
        $('#ddlcurcompany').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlcurcompany').css('border-color', 'lightgrey');
    }

    if ($("#ddlfromyear option:selected").text() == "") {
        $('#ddlfromyear').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlfromyear').css('border-color', 'lightgrey');
    }
    if ($("#ddlfrommonth option:selected").text() == "") {
        $('#ddlfrommonth').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlfrommonth').css('border-color', 'lightgrey');
    }
    if ($("#ddlToyear option:selected").text() == "") {
        $('#ddlToyear').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlToyear').css('border-color', 'lightgrey');
    }
    if ($("#ddlTomonth option:selected").text() == "") {
        $('#ddlTomonth').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlTomonth').css('border-color', 'lightgrey');
    }

    //if ($('#txtCurrentCom').val().trim() == "") {
    //    $('#txtCurrentCom').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#txtCurrentCom').css('border-color', 'lightgrey');
    //}
    if ($('#txtdescribejobprofile').val().trim() == "") {
        $('#txtdescribejobprofile').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtdescribejobprofile').css('border-color', 'lightgrey');
    }
    return isValid;

}
function validateEducationDetails() {
    var isValid = true;

    if ($("#ddlEducation option:selected").text() == "--Select--") {
        $('#ddlEducation').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlEducation').css('border-color', 'lightgrey');
    }
    var ddlEducation = $("#ddlEducation option:selected").text();
    if (ddlEducation == "10th" || ddlEducation == "12th") {

        var ddlBoard = $("#ddlboard option:selected").text();
        var ddlschoolmedium = $("#ddlschoolmedium option:selected").text();
        if (ddlBoard == '(--All India--)') {
            //toastr.warning('Please select board...!!!');
            $('#ddlboard').css('border-color', 'Red');
            isValid = false;
            $("#divLoader").hide();
        }
        else {
            $('#ddlboard').css('border-color', 'lightgrey');
        }
        //if (ddlBoard == '(--State Board--)') {
        //    $('#ddlboard').css('border-color', 'Red');
        //    isValid = false;
        //    //toastr.warning('Please select board...!!!');
        //}
        //else {
        //    $('#ddlboard').css('border-color', 'lightgrey');
        //}
        if (ddlschoolmedium == '--Select--') {
            //toastr.warning('Please select school medium...!!!');
            $('#ddlschoolmedium').css('border-color', 'Red');
            isValid = false;
            $("#divLoader").hide();
        }
        else {
            $('#ddlschoolmedium').css('border-color', 'lightgrey');
        }

    }
    if (ddlEducation == "Graduation/Diploma" || ddlEducation == "Master/PostGraduation") {
        var txtcourse = $("#txtcourse").val();
        var txtSpecialization = $("#txtSpecialization").val();
        var txtuniversity = $("#txtuniversity").val();
        var ddlcoursetype = $("#ddlcoursetype option:selected").text();

        if (txtcourse == "") {
            //toastr.warning('Please enter course...!!!');
            $('#txtcourse').css('border-color', 'Red');
            isValid = false;
            $("#divLoader").hide();
        }
        else {
            $('#txtcourse').css('border-color', 'lightgrey');
        }
        if (txtSpecialization == "") {
            //toastr.warning('Please enter Specialization...!!!');
            $('#txtSpecialization').css('border-color', 'Red');
            isValid = false;
            $("#divLoader").hide();
        }
        else {
            $('#txtSpecialization').css('border-color', 'lightgrey');
        }
        if (txtuniversity == "") {
            //toastr.warning('Please enter University...!!!');
            $('#txtuniversity').css('border-color', 'Red');
            isValid = false;
            $("#divLoader").hide();
        }
        else {
            $('#txtuniversity').css('border-color', 'lightgrey');
        }
        if (ddlcoursetype == "--Select--") {
            //toastr.warning('Please select course type...!!!');
            $('#ddlcoursetype').css('border-color', 'Red');
            isValid = false;
            $("#divLoader").hide();
        }
        else {
            $('#ddlcoursetype').css('border-color', 'lightgrey');
        }

    }

    if ($("#ddlpassingoutyear option:selected").text() == "") {
        $('#ddlpassingoutyear').css('border-color', 'Red');
        //$(this).css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlpassingoutyear').css('border-color', 'lightgrey');
    }
    if ($('#txttotalpercentage').val().trim() == "") {
        $('#txttotalpercentage').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txttotalpercentage').css('border-color', 'lightgrey');
    }
    //if ($("#ddlpassingoutyear option:selected").text() == "--Select--") {
    //    $('#ddlpassingoutyear').css('border-color', 'Red');
    //    isValid = false;
    //}
    //else {
    //    $('#ddlpassingoutyear').css('border-color', 'lightgrey');
    //} 
    return isValid;
}
function validatePayslipDetails() {
    var isValid = true;

    if ($("#ddlPayslipMonth option:selected").text() == "") {
        $('#ddlPayslipMonth').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlPayslipMonth').css('border-color', 'lightgrey');
    }
    if ($("#ddlPayslipYear option:selected").text() == "") {
        $('#ddlPayslipYear').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#ddlPayslipYear').css('border-color', 'lightgrey');
    }

    return isValid;
}
function validateReferenceDetails() {
    var isValid = true;

    if ($('#txtReferenceName').val().trim() == "") {
        $('#txtReferenceName').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtReferenceName').css('border-color', 'lightgrey');
    }
    if ($('#txtReferencePhoneno').val().trim() == "") {
        $('#txtReferencePhoneno').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtReferencePhoneno').css('border-color', 'lightgrey');
    }

    return isValid;
}
function validateCertificationDetails() {
    var isValid = true;


    if ($('#txtCertificationName').val().trim() == "") {
        $('#txtCertificationName').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtCertificationName').css('border-color', 'lightgrey');
    }
    if ($('#txtCertificationMarks').val().trim() == "") {
        $('#txtCertificationMarks').css('border-color', 'Red');
        isValid = false;
        $("#divLoader").hide();
    }
    else {
        $('#txtCertificationMarks').css('border-color', 'lightgrey');
    }

    return isValid;
}

//function FormatJsonDate(jsonDate) {
//    var num = jsonDate.match(/\d+/g); //regex to extract numbers 
//    var date = new Date(parseFloat(num)); //converting to date
//    return (date.getDate() + "-" + (date.getMonth() + 1) + '-' + date.getFullYear());
//}

//function formatDate(date) {
//    //var date = new Date(parseInt(jsonDate.substr(6)));
//    var d = new Date(date),
//        month = '' + (d.getMonth() + 1),
//        day = '' + d.getDate(),
//        year = d.getFullYear();

//    if (month.length < 2)
//        month = '0' + month;
//    if (day.length < 2)
//        day = '0' + day;

//    return [year, month, day].join('-');
//}
